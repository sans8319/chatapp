import { Component } from '@angular/core';

@Component({ selector: 'app-message-bubble', template: '<ng-content></ng-content>' })
export class MessageBubbleComponent {}
