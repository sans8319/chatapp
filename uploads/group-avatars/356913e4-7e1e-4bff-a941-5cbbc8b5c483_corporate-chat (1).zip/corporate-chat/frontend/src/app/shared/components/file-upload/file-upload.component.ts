import { Component, Output, EventEmitter } from '@angular/core';
import { APP_CONFIG } from '../../../config/app.config';

@Component({
  selector: 'app-file-upload',
  template: `
<div class="file-upload-area" (click)="fileInput.click()" (dragover)="onDragOver($event)"
     (drop)="onDrop($event)">
  <mat-icon>cloud_upload</mat-icon>
  <p>Click or drop a file here</p>
  <input #fileInput type="file" hidden (change)="onFileChange($event)"
         accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip" />
</div>`,
  styles: [`
.file-upload-area {
  border: 2px dashed var(--border); border-radius: 8px;
  padding: 24px; text-align: center; cursor: pointer; transition: border-color 0.2s;
}
.file-upload-area:hover { border-color: var(--primary); }
`],
})
export class FileUploadComponent {
  @Output() fileSelected = new EventEmitter<File>();

  onFileChange(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) this.fileSelected.emit(file);
  }

  onDragOver(event: DragEvent): void { event.preventDefault(); }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    const file = event.dataTransfer?.files[0];
    if (file) this.fileSelected.emit(file);
  }
}
