import { Component, Input, OnChanges } from '@angular/core';
import { User, ChatMember } from '../../../shared/models';

@Component({
  selector: 'app-user-avatar',
  template: `
<div class="avatar-container" [style.width.px]="size" [style.height.px]="size"
     [style.fontSize.px]="fontSize">
  <img *ngIf="avatarUrl" [src]="avatarUrl" [alt]="initials"
       class="avatar-img" [style.width.px]="size" [style.height.px]="size" />
  <div *ngIf="!avatarUrl" class="avatar-initials"
       [style.background]="bgColor" [style.width.px]="size" [style.height.px]="size">
    {{ initials }}
  </div>
</div>`,
  styles: [`
.avatar-container { border-radius: 50%; overflow: hidden; flex-shrink: 0; display: inline-block; }
.avatar-img { border-radius: 50%; object-fit: cover; display: block; }
.avatar-initials {
  border-radius: 50%; display: flex; align-items: center; justify-content: center;
  color: white; font-weight: 600; letter-spacing: 0.5px; user-select: none;
}
`],
})
export class UserAvatarComponent implements OnChanges {
  @Input() user?: User | any | null;
  @Input() userName?: string;
  @Input() chatName?: string;
  @Input() size = 40;

  avatarUrl = '';
  initials = '';
  bgColor = '';
  fontSize = 14;

  private COLORS = [
    '#e53935','#d81b60','#8e24aa','#5e35b1','#3949ab',
    '#1e88e5','#039be5','#00acc1','#00897b','#43a047',
    '#7cb342','#f4511e','#f6bf26','#fb8c00','#6d4c41',
  ];

  ngOnChanges(): void {
    this.fontSize = Math.max(10, Math.floor(this.size * 0.38));
    if (this.user?.avatarUrl) {
      this.avatarUrl = this.user.avatarUrl;
    } else {
      this.avatarUrl = '';
    }
    const name = this.user?.displayName || this.user?.username || this.userName || this.chatName || '?';
    this.initials = this.getInitials(name);
    this.bgColor = this.getColor(name);
  }

  private getInitials(name: string): string {
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.substring(0, 2).toUpperCase();
  }

  private getColor(name: string): string {
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return this.COLORS[Math.abs(hash) % this.COLORS.length];
  }
}
