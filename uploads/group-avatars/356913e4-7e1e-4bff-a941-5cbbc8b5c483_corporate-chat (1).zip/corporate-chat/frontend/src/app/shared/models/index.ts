// =============================================
// SHARED MODELS - mirrors backend DTOs exactly
// =============================================

export interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatarUrl?: string;
  bio?: string;
  role: 'ADMIN' | 'EMPLOYEE';
  active: boolean;
  presenceStatus: 'ONLINE' | 'OFFLINE' | 'AWAY' | 'BUSY';
  lastSeenAt?: string;
  createdAt?: string;
  deactivatedAt?: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  expiresIn: number;
  user: User;
}

export interface Chat {
  id: string;
  type: 'DIRECT' | 'GROUP';
  name: string;
  description?: string;
  avatarUrl?: string;
  createdBy: string;
  active: boolean;
  createdAt: string;
  lastMessageAt?: string;
  lastMessage?: Message;
  members: ChatMember[];
  unreadCount: number;
  muted: boolean;
  memberRole: 'OWNER' | 'ADMIN' | 'MEMBER';
}

export interface ChatMember {
  userId: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
  memberRole: 'OWNER' | 'ADMIN' | 'MEMBER';
  active: boolean;
  userActive: boolean;
  presenceStatus: string;
  joinedAt: string;
  lastReadAt?: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  senderActive: boolean;
  content?: string;
  messageType: 'TEXT' | 'IMAGE' | 'VIDEO' | 'DOCUMENT' | 'AUDIO' | 'SYSTEM';
  parentMessageId?: string;
  parentMessage?: Message;
  forwardedFromId?: string;
  edited: boolean;
  editedAt?: string;
  deleted: boolean;
  deletedForEveryone: boolean;
  linkPreviewUrl?: string;
  linkPreviewTitle?: string;
  linkPreviewDescription?: string;
  linkPreviewImage?: string;
  sequenceNumber?: number;
  createdAt: string;
  updatedAt?: string;
  mentions?: string[];
  attachments?: Attachment[];
  reactions?: Record<string, string[]>;
  statuses?: MessageStatus[];
  pinned?: boolean;
  starred?: boolean;
  deliveryStatus?: 'SENT' | 'DELIVERED' | 'SEEN';
  clientTempId?: string;
  // UI state
  _pending?: boolean;
  _failed?: boolean;
}

export interface Attachment {
  id: string;
  fileName: string;
  originalName: string;
  fileUrl: string;
  mimeType?: string;
  fileSize?: number;
  attachmentType?: 'IMAGE' | 'VIDEO' | 'DOCUMENT';
  width?: number;
  height?: number;
  thumbnailUrl?: string;
}

export interface MessageStatus {
  userId: string;
  status: 'SENT' | 'DELIVERED' | 'SEEN';
  deliveredAt?: string;
  seenAt?: string;
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  chatId?: string;
  messageId?: string;
  senderId?: string;
  senderName?: string;
  senderAvatar?: string;
  read: boolean;
  createdAt: string;
}

export interface TypingEvent {
  chatId: string;
  userId: string;
  userName: string;
  typing: boolean;
}

export interface PresenceEvent {
  userId: string;
  status: string;
  timestamp: string;
}

export interface SeenEvent {
  chatId: string;
  userId: string;
  messageIds: string[];
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
}

// WS event envelope
export interface WsEvent {
  type: 'NEW_MESSAGE' | 'MESSAGE_EDIT' | 'MESSAGE_DELETE' | 'REACTION_UPDATE'
      | 'PIN_UPDATE' | 'SEEN_STATUS' | 'TYPING' | 'PRESENCE' | 'NEW_CHAT';
  payload: any;
}
