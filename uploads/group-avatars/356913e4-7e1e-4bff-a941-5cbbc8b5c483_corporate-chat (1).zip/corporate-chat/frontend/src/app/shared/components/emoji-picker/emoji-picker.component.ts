import { Component, Output, EventEmitter, HostListener } from '@angular/core';

@Component({
  selector: 'app-emoji-picker',
  template: `
<div class="emoji-picker" (click)="$event.stopPropagation()">
  <div class="emoji-categories">
    <button *ngFor="let cat of categories; let i=index"
            class="cat-btn" [class.active]="activeCategory===i"
            (click)="activeCategory=i">{{ cat.icon }}</button>
  </div>
  <div class="emoji-grid">
    <button *ngFor="let e of currentEmojis"
            class="emoji-btn" (click)="select(e)">{{ e }}</button>
  </div>
</div>`,
  styles: [`
.emoji-picker {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.15);
  padding: 8px; width: 320px;
}
.emoji-categories { display: flex; gap: 4px; margin-bottom: 8px; }
.cat-btn { background: none; border: none; cursor: pointer; padding: 4px 8px;
           border-radius: 6px; font-size: 16px; }
.cat-btn.active { background: var(--primary-light); }
.emoji-grid { display: grid; grid-template-columns: repeat(8, 1fr); gap: 2px; max-height: 200px; overflow-y: auto; }
.emoji-btn { background: none; border: none; cursor: pointer; font-size: 22px;
             padding: 4px; border-radius: 4px; transition: background 0.1s; }
.emoji-btn:hover { background: var(--hover); }
`],
})
export class EmojiPickerComponent {
  @Output() emojiSelected = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  activeCategory = 0;

  categories = [
    { icon: '😀', emojis: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','😟','🙁','☹️','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖'] },
    { icon: '👍', emojis: ['👍','👎','👊','✊','🤛','🤜','🤞','✌️','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','🖕','✍️','💪','🦾','🖐','👏','🙌','🤲','🤝','🙏'] },
    { icon: '❤️', emojis: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❤️‍🔥','❤️‍🩹','❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️','✝️','☪️','🕉️','✡️','🔯','🕎','☯️','☦️'] },
    { icon: '🎉', emojis: ['🎉','🎊','🎈','🎁','🎀','🎗','🎟','🎫','🏆','🥇','🥈','🥉','🏅','🎖','🎯','🎲','🎮','🕹️','🃏','🀄','🎴','🎭','🎨','🖼️','🎪','🤹','🎤','🎧','🎼','🎵','🎶','🎹','🥁','🎷','🎺','🎸','🪕','🎻','🎬','🎥','📷','📸'] },
    { icon: '🌟', emojis: ['⭐','🌟','💫','✨','🔥','🌈','☀️','🌤','⛅','🌦','🌧','⛈','🌩','🌨','❄️','☃️','⛄','🌬','💨','💧','💦','☔','⚡','🌊','🌀','🌈','🌂','☂️','🌡','⛱','🌍','🌎','🌏','🪐','🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘','🌙','🌚','🌛','🌜','🌝','🌞'] },
    { icon: '🍕', emojis: ['🍕','🍔','🍟','🌭','🍿','🧂','🥓','🥚','🍳','🥞','🧇','🥐','🥖','🍞','🥨','🥯','🧀','🥗','🥙','🥪','🌮','🌯','🫔','🧆','🥫','🍱','🍛','🍜','🍝','🍠','🍢','🍣','🍤','🍙','🍚','🍘','🍥','🥮','🍡','🧁','🍰','🎂','🍮','🍭','🍬','🍫','🍿','🍩','🍪','🌰','🥜','🍯'] },
  ];

  get currentEmojis(): string[] {
    return this.categories[this.activeCategory]?.emojis ?? [];
  }

  select(emoji: string): void {
    this.emojiSelected.emit(emoji);
  }

  @HostListener('document:click')
  onDocClick(): void { this.close.emit(); }
}
