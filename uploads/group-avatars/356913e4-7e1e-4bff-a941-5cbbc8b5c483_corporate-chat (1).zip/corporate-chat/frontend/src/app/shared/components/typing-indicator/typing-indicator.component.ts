import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-typing-indicator',
  template: `
<div class="typing-indicator">
  <span class="dots"><span></span><span></span><span></span></span>
  <span class="typing-text">{{ text }}</span>
</div>`,
  styles: [`
.typing-indicator {
  display: flex; align-items: center; gap: 8px;
  padding: 4px 12px; color: var(--text-secondary); font-size: 13px;
}
.dots span {
  display: inline-block; width: 6px; height: 6px;
  border-radius: 50%; background: var(--text-secondary);
  margin-right: 2px; animation: bounce 1.4s infinite ease-in-out both;
}
.dots span:nth-child(1) { animation-delay: -0.32s; }
.dots span:nth-child(2) { animation-delay: -0.16s; }
@keyframes bounce { 0%,80%,100%{transform:scale(0)} 40%{transform:scale(1)} }
`],
})
export class TypingIndicatorComponent {
  @Input() text = '';
}
