import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Chat, Message } from '../../shared/models';

@Injectable({ providedIn: 'root' })
export class ChatStateService {
  private _chats = new BehaviorSubject<Chat[]>([]);
  private _activeChatId = new BehaviorSubject<string | null>(null);
  private _messages = new Map<string, BehaviorSubject<Message[]>>();
  private _loadingMessages = new BehaviorSubject<boolean>(false);
  private _typingUsers = new Map<string, BehaviorSubject<Map<string, string>>>();

  chats$ = this._chats.asObservable();
  activeChatId$ = this._activeChatId.asObservable();
  loadingMessages$ = this._loadingMessages.asObservable();

  get chats(): Chat[] { return this._chats.value; }
  get activeChatId(): string | null { return this._activeChatId.value; }
  get activeChat(): Chat | undefined {
    return this._chats.value.find(c => c.id === this._activeChatId.value);
  }

  setChats(chats: Chat[]): void {
    this._chats.next([...chats]);
  }

  upsertChat(chat: Chat): void {
    const list = [...this._chats.value];
    const idx = list.findIndex(c => c.id === chat.id);
    if (idx >= 0) list[idx] = chat;
    else list.unshift(chat);
    // Sort by lastMessageAt desc
    list.sort((a, b) => {
      const ta = a.lastMessageAt ? new Date(a.lastMessageAt).getTime() : 0;
      const tb = b.lastMessageAt ? new Date(b.lastMessageAt).getTime() : 0;
      return tb - ta;
    });
    this._chats.next(list);
  }

  removeChat(chatId: string): void {
    this._chats.next(this._chats.value.filter(c => c.id !== chatId));
  }

  setActiveChat(chatId: string | null): void {
    this._activeChatId.next(chatId);
  }

  // ---- Messages ----
  getMessages$(chatId: string): BehaviorSubject<Message[]> {
    if (!this._messages.has(chatId)) {
      this._messages.set(chatId, new BehaviorSubject<Message[]>([]));
    }
    return this._messages.get(chatId)!;
  }

  getMessages(chatId: string): Message[] {
    return this._messages.get(chatId)?.value ?? [];
  }

  setMessages(chatId: string, messages: Message[]): void {
    const sorted = [...messages].sort((a, b) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    this.getMessages$(chatId).next(sorted);
  }

  prependMessages(chatId: string, messages: Message[]): void {
    const current = this.getMessages(chatId);
    const combined = [...messages, ...current].sort((a, b) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    // Deduplicate
    const seen = new Set<string>();
    const deduped = combined.filter(m => {
      if (seen.has(m.id)) return false;
      seen.add(m.id);
      return true;
    });
    this.getMessages$(chatId).next(deduped);
  }

  addMessage(chatId: string, message: Message): void {
    const messages = this.getMessages(chatId);
    // Deduplicate: remove any pending/temp message with same clientTempId
    let list = message.clientTempId
      ? messages.filter(m => m.clientTempId !== message.clientTempId)
      : [...messages];
    // Also avoid real duplicate by id
    if (!list.find(m => m.id === message.id)) {
      list = [...list, message];
    }
    // Ensure order
    list.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    this.getMessages$(chatId).next(list);
  }

  updateMessage(chatId: string, updated: Message): void {
    const messages = this.getMessages(chatId).map(m => m.id === updated.id ? updated : m);
    this.getMessages$(chatId).next(messages);
  }

  removeMessage(chatId: string, messageId: string, forEveryone: boolean): void {
    const messages = this.getMessages(chatId).map(m => {
      if (m.id !== messageId) return m;
      return { ...m, deleted: true, deletedForEveryone: forEveryone, content: '[Deleted]' };
    });
    this.getMessages$(chatId).next(messages);
  }

  markPendingMessage(chatId: string, tempId: string, failed: boolean): void {
    const messages = this.getMessages(chatId).map(m =>
      m.clientTempId === tempId ? { ...m, _pending: false, _failed: failed } : m);
    this.getMessages$(chatId).next(messages);
  }

  setLoading(loading: boolean): void {
    this._loadingMessages.next(loading);
  }

  // ---- Typing ----
  getTyping$(chatId: string): BehaviorSubject<Map<string, string>> {
    if (!this._typingUsers.has(chatId)) {
      this._typingUsers.set(chatId, new BehaviorSubject(new Map()));
    }
    return this._typingUsers.get(chatId)!;
  }

  setTyping(chatId: string, userId: string, userName: string, typing: boolean): void {
    const map = new Map(this.getTyping$(chatId).value);
    if (typing) map.set(userId, userName);
    else map.delete(userId);
    this.getTyping$(chatId).next(map);
  }

  // ---- Unread ----
  incrementUnread(chatId: string): void {
    const chat = this.chats.find(c => c.id === chatId);
    if (chat) this.upsertChat({ ...chat, unreadCount: chat.unreadCount + 1 });
  }

  resetUnread(chatId: string): void {
    const chat = this.chats.find(c => c.id === chatId);
    if (chat) this.upsertChat({ ...chat, unreadCount: 0 });
  }

  updateChatLastMessage(chatId: string, message: Message): void {
    const chat = this.chats.find(c => c.id === chatId);
    if (chat) this.upsertChat({ ...chat, lastMessage: message, lastMessageAt: message.createdAt });
  }
}
