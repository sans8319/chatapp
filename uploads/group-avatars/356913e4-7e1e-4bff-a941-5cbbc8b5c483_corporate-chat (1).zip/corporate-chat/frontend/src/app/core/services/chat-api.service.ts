import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { APP_CONFIG } from '../../config/app.config';
import { ApiResponse, Chat, ChatMember, Message, PageResponse, User } from '../../shared/models';

@Injectable({ providedIn: 'root' })
export class ChatApiService {
  private base = APP_CONFIG.API_URL;

  constructor(private http: HttpClient) {}

  // ---- Chats ----
  createChat(payload: { type: string; name?: string; description?: string; memberIds: string[] }): Observable<ApiResponse<Chat>> {
    return this.http.post<ApiResponse<Chat>>(`${this.base}/chats`, payload);
  }

  getMyChats(): Observable<ApiResponse<Chat[]>> {
    return this.http.get<ApiResponse<Chat[]>>(`${this.base}/chats`);
  }

  getChat(chatId: string): Observable<ApiResponse<Chat>> {
    return this.http.get<ApiResponse<Chat>>(`${this.base}/chats/${chatId}`);
  }

  updateChat(chatId: string, payload: { name?: string; description?: string }): Observable<ApiResponse<Chat>> {
    return this.http.put<ApiResponse<Chat>>(`${this.base}/chats/${chatId}`, payload);
  }

  deleteForMe(chatId: string): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.base}/chats/${chatId}`);
  }

  addMembers(chatId: string, userIds: string[]): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/chats/${chatId}/members`, { userIds });
  }

  removeMember(chatId: string, memberId: string): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.base}/chats/${chatId}/members/${memberId}`);
  }

  leaveChat(chatId: string): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/chats/${chatId}/leave`, {});
  }

  muteChat(chatId: string, mute: boolean): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/chats/${chatId}/mute?mute=${mute}`, {});
  }

  getChatMembers(chatId: string): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.base}/chats/${chatId}/members`);
  }

  // ---- Messages ----
  sendMessage(payload: {
    chatId: string; content?: string; messageType?: string;
    parentMessageId?: string; forwardedFromId?: string;
    clientTempId?: string; mentions?: string[];
  }): Observable<ApiResponse<Message>> {
    return this.http.post<ApiResponse<Message>>(`${this.base}/messages`, payload);
  }

  sendFile(chatId: string, file: File): Observable<ApiResponse<Message>> {
    const form = new FormData();
    form.append('chatId', chatId);
    form.append('file', file);
    return this.http.post<ApiResponse<Message>>(`${this.base}/messages/upload`, form);
  }

  getMessages(chatId: string, page = 0, size = 50): Observable<ApiResponse<PageResponse<Message>>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<ApiResponse<PageResponse<Message>>>(`${this.base}/messages/chat/${chatId}`, { params });
  }

  editMessage(messageId: string, content: string): Observable<ApiResponse<Message>> {
    return this.http.put<ApiResponse<Message>>(`${this.base}/messages/${messageId}`, { content });
  }

  deleteMessage(messageId: string, forEveryone: boolean): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.base}/messages/${messageId}?forEveryone=${forEveryone}`);
  }

  toggleReaction(messageId: string, emoji: string): Observable<ApiResponse<Message>> {
    return this.http.post<ApiResponse<Message>>(`${this.base}/messages/${messageId}/reactions`, { emoji });
  }

  pinMessage(chatId: string, messageId: string, pin: boolean): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/messages/chat/${chatId}/pin/${messageId}?pin=${pin}`, {});
  }

  getPinnedMessages(chatId: string): Observable<ApiResponse<Message[]>> {
    return this.http.get<ApiResponse<Message[]>>(`${this.base}/messages/chat/${chatId}/pinned`);
  }

  starMessage(messageId: string, star: boolean): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/messages/${messageId}/star?star=${star}`, {});
  }

  getStarredMessages(): Observable<ApiResponse<Message[]>> {
    return this.http.get<ApiResponse<Message[]>>(`${this.base}/messages/starred`);
  }

  markAsSeen(chatId: string): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/messages/chat/${chatId}/seen`, {});
  }

  searchMessages(chatId: string, q: string, page = 0, size = 20): Observable<ApiResponse<PageResponse<Message>>> {
    const params = new HttpParams().set('q', q).set('page', page).set('size', size);
    return this.http.get<ApiResponse<PageResponse<Message>>>(`${this.base}/messages/chat/${chatId}/search`, { params });
  }

  getEditHistory(messageId: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.base}/messages/${messageId}/history`);
  }
}
