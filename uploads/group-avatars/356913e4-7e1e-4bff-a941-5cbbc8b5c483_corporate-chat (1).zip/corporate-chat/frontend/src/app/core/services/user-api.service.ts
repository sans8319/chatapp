import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { APP_CONFIG } from '../../config/app.config';
import { ApiResponse, Notification, PageResponse, User } from '../../shared/models';

@Injectable({ providedIn: 'root' })
export class UserApiService {
  private base = APP_CONFIG.API_URL;

  constructor(private http: HttpClient) {}

  getMe(): Observable<ApiResponse<User>> {
    return this.http.get<ApiResponse<User>>(`${this.base}/users/me`);
  }

  updateProfile(payload: { displayName?: string; bio?: string }): Observable<ApiResponse<User>> {
    return this.http.put<ApiResponse<User>>(`${this.base}/users/me`, payload);
  }

  uploadAvatar(file: File): Observable<ApiResponse<User>> {
    const form = new FormData();
    form.append('file', file);
    return this.http.post<ApiResponse<User>>(`${this.base}/users/me/avatar`, form);
  }

  getUserById(userId: string): Observable<ApiResponse<User>> {
    return this.http.get<ApiResponse<User>>(`${this.base}/users/${userId}`);
  }

  getAllActiveUsers(): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.base}/users`);
  }

  searchUsers(q: string, page = 0, size = 20, activeOnly = true): Observable<ApiResponse<PageResponse<User>>> {
    const params = new HttpParams().set('q', q).set('page', page).set('size', size).set('activeOnly', activeOnly);
    return this.http.get<ApiResponse<PageResponse<User>>>(`${this.base}/users/search`, { params });
  }

  getOnlineUsers(): Observable<ApiResponse<string[]>> {
    return this.http.get<ApiResponse<string[]>>(`${this.base}/users/online`);
  }

  sendHeartbeat(): Observable<any> {
    return this.http.post(`${this.base}/users/heartbeat`, {});
  }

  // ---- Admin ----
  adminGetUsers(page = 0, size = 20): Observable<ApiResponse<PageResponse<User>>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<ApiResponse<PageResponse<User>>>(`${this.base}/admin/users`, { params });
  }

  adminSearchUsers(q: string, page = 0, size = 20): Observable<ApiResponse<PageResponse<User>>> {
    const params = new HttpParams().set('q', q).set('page', page).set('size', size);
    return this.http.get<ApiResponse<PageResponse<User>>>(`${this.base}/admin/users/search`, { params });
  }

  adminDeactivateUser(userId: string): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.base}/admin/users/${userId}`);
  }

  adminReactivateUser(userId: string): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/admin/users/${userId}/reactivate`, {});
  }

  // ---- Notifications ----
  getNotifications(page = 0, size = 20): Observable<ApiResponse<PageResponse<Notification>>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<ApiResponse<PageResponse<Notification>>>(`${this.base}/notifications`, { params });
  }

  getUnreadNotificationCount(): Observable<ApiResponse<number>> {
    return this.http.get<ApiResponse<number>>(`${this.base}/notifications/unread-count`);
  }

  markAllNotificationsRead(): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/notifications/read-all`, {});
  }

  markNotificationRead(id: string): Observable<ApiResponse<void>> {
    return this.http.post<ApiResponse<void>>(`${this.base}/notifications/${id}/read`, {});
  }
}
