import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { APP_CONFIG } from '../../config/app.config';
import { ApiResponse, AuthResponse, User } from '../../shared/models';

const TOKEN_KEY = 'cc_access_token';
const REFRESH_KEY = 'cc_refresh_token';
const USER_KEY = 'cc_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _currentUser = new BehaviorSubject<User | null>(this.loadUser());
  currentUser$ = this._currentUser.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  get currentUser(): User | null {
    return this._currentUser.value;
  }

  register(payload: { username: string; email: string; password: string; displayName?: string; role?: string }): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(`${APP_CONFIG.API_URL}/auth/register`, payload)
      .pipe(tap(res => { if (res.success && res.data) this.storeSession(res.data); }));
  }

  login(usernameOrEmail: string, password: string): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(`${APP_CONFIG.API_URL}/auth/login`, { usernameOrEmail, password })
      .pipe(tap(res => { if (res.success && res.data) this.storeSession(res.data); }));
  }

  refreshToken(refreshToken: string): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(`${APP_CONFIG.API_URL}/auth/refresh`, { refreshToken })
      .pipe(tap(res => {
        if (res.success && res.data) {
          localStorage.setItem(TOKEN_KEY, res.data.accessToken);
          localStorage.setItem(REFRESH_KEY, res.data.refreshToken);
        }
      }));
  }

  logout(): void {
    this.http.post(`${APP_CONFIG.API_URL}/auth/logout`, {}).subscribe({ error: () => {} });
    this.clearSession();
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return !!this.getAccessToken();
  }

  getAccessToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  getRefreshToken(): string | null {
    return localStorage.getItem(REFRESH_KEY);
  }

  updateCurrentUser(user: User): void {
    this._currentUser.next(user);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  private storeSession(auth: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, auth.accessToken);
    localStorage.setItem(REFRESH_KEY, auth.refreshToken);
    localStorage.setItem(USER_KEY, JSON.stringify(auth.user));
    this._currentUser.next(auth.user);
  }

  clearSession(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
    localStorage.removeItem(USER_KEY);
    this._currentUser.next(null);
  }

  private loadUser(): User | null {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  }
}
