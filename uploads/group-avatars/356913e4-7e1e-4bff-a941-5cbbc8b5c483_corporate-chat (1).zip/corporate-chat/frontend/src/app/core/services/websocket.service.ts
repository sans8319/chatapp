import { Injectable, OnDestroy } from '@angular/core';
import { Client, IMessage, StompSubscription } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { APP_CONFIG } from '../../config/app.config';
import { AuthService } from './auth.service';
import { Message, TypingEvent, PresenceEvent, SeenEvent, Chat, Notification } from '../../shared/models';

export type WsConnectionState = 'CONNECTED' | 'DISCONNECTED' | 'CONNECTING';

@Injectable({ providedIn: 'root' })
export class WebSocketService implements OnDestroy {
  private client!: Client;
  private subscriptions = new Map<string, StompSubscription>();
  private connectionState = new BehaviorSubject<WsConnectionState>('DISCONNECTED');
  connectionState$ = this.connectionState.asObservable();

  // Streams
  private messageSubject = new Subject<Message>();
  private messageEditSubject = new Subject<Message>();
  private messageDeleteSubject = new Subject<{ chatId: string; messageId: string; forEveryone: boolean }>();
  private reactionSubject = new Subject<Message>();
  private pinSubject = new Subject<{ chatId: string; messageId: string; pinned: boolean }>();
  private seenSubject = new Subject<SeenEvent>();
  private typingSubject = new Subject<TypingEvent>();
  private presenceSubject = new Subject<PresenceEvent>();
  private newChatSubject = new Subject<Chat>();
  private notificationSubject = new Subject<Notification>();

  message$ = this.messageSubject.asObservable();
  messageEdit$ = this.messageEditSubject.asObservable();
  messageDelete$ = this.messageDeleteSubject.asObservable();
  reaction$ = this.reactionSubject.asObservable();
  pin$ = this.pinSubject.asObservable();
  seen$ = this.seenSubject.asObservable();
  typing$ = this.typingSubject.asObservable();
  presence$ = this.presenceSubject.asObservable();
  newChat$ = this.newChatSubject.asObservable();
  notification$ = this.notificationSubject.asObservable();

  constructor(private authService: AuthService) {}

  connect(): void {
    if (this.client?.active) return;
    this.connectionState.next('CONNECTING');
    const token = this.authService.getAccessToken();

    this.client = new Client({
      webSocketFactory: () => new SockJS(APP_CONFIG.WS_URL) as any,
      connectHeaders: { Authorization: `Bearer ${token}` },
      heartbeatIncoming: APP_CONFIG.WS_HEARTBEAT_INCOMING,
      heartbeatOutgoing: APP_CONFIG.WS_HEARTBEAT_OUTGOING,
      reconnectDelay: APP_CONFIG.WS_RECONNECT_DELAY,
      onConnect: () => {
        this.connectionState.next('CONNECTED');
        this.subscribeToGlobalTopics();
      },
      onDisconnect: () => {
        this.connectionState.next('DISCONNECTED');
      },
      onStompError: (frame) => {
        console.error('STOMP error', frame);
        this.connectionState.next('DISCONNECTED');
      },
    });

    this.client.activate();
  }

  disconnect(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
    this.subscriptions.clear();
    this.client?.deactivate();
    this.connectionState.next('DISCONNECTED');
  }

  subscribeToChat(chatId: string): void {
    if (!this.client?.connected) return;
    const topics = [
      { key: `chat.${chatId}.messages`, dest: `/topic/chat.${chatId}.messages`, handler: (m: IMessage) => {
        const msg: Message = JSON.parse(m.body);
        this.messageSubject.next(msg);
      }},
      { key: `chat.${chatId}.messages.edit`, dest: `/topic/chat.${chatId}.messages.edit`, handler: (m: IMessage) => {
        this.messageEditSubject.next(JSON.parse(m.body));
      }},
      { key: `chat.${chatId}.messages.delete`, dest: `/topic/chat.${chatId}.messages.delete`, handler: (m: IMessage) => {
        this.messageDeleteSubject.next(JSON.parse(m.body));
      }},
      { key: `chat.${chatId}.reactions`, dest: `/topic/chat.${chatId}.reactions`, handler: (m: IMessage) => {
        this.reactionSubject.next(JSON.parse(m.body));
      }},
      { key: `chat.${chatId}.pins`, dest: `/topic/chat.${chatId}.pins`, handler: (m: IMessage) => {
        this.pinSubject.next(JSON.parse(m.body));
      }},
      { key: `chat.${chatId}.seen`, dest: `/topic/chat.${chatId}.seen`, handler: (m: IMessage) => {
        this.seenSubject.next(JSON.parse(m.body));
      }},
      { key: `chat.${chatId}.typing`, dest: `/topic/chat.${chatId}.typing`, handler: (m: IMessage) => {
        this.typingSubject.next(JSON.parse(m.body));
      }},
    ];
    topics.forEach(({ key, dest, handler }) => {
      if (!this.subscriptions.has(key)) {
        const sub = this.client.subscribe(dest, handler);
        this.subscriptions.set(key, sub);
      }
    });
  }

  unsubscribeFromChat(chatId: string): void {
    const prefixes = [`chat.${chatId}`];
    this.subscriptions.forEach((sub, key) => {
      if (prefixes.some(p => key.startsWith(p))) {
        sub.unsubscribe();
        this.subscriptions.delete(key);
      }
    });
  }

  private subscribeToGlobalTopics(): void {
    // Global presence
    const presSub = this.client.subscribe('/topic/presence', (m: IMessage) => {
      this.presenceSubject.next(JSON.parse(m.body));
    });
    this.subscriptions.set('global.presence', presSub);

    // User-specific queues (notifications, new chats)
    const notifSub = this.client.subscribe('/user/queue/notifications', (m: IMessage) => {
      this.notificationSubject.next(JSON.parse(m.body));
    });
    this.subscriptions.set('user.notifications', notifSub);

    const newChatSub = this.client.subscribe('/user/queue/chats.new', (m: IMessage) => {
      this.newChatSubject.next(JSON.parse(m.body));
    });
    this.subscriptions.set('user.chats.new', newChatSub);
  }

  sendTyping(chatId: string, typing: boolean): void {
    if (!this.client?.connected) return;
    this.client.publish({
      destination: '/app/typing',
      body: JSON.stringify({ chatId, typing }),
    });
  }

  sendHeartbeat(): void {
    if (!this.client?.connected) return;
    this.client.publish({ destination: '/app/presence.heartbeat', body: '{}' });
  }

  isConnected(): boolean {
    return this.client?.connected ?? false;
  }

  messagesForChat$(chatId: string): Observable<Message> {
    return this.message$.pipe(filter(m => m.chatId === chatId));
  }

  ngOnDestroy(): void {
    this.disconnect();
  }
}
