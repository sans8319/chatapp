import { Injectable } from '@angular/core';
import {
  HttpRequest, HttpHandler, HttpEvent,
  HttpInterceptor, HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private snackBar: MatSnackBar) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        // Let 401 be handled by AuthInterceptor
        if (error.status === 401) return throwError(() => error);

        let msg = 'An error occurred';
        if (error.error?.error) msg = error.error.error;
        else if (error.error?.message) msg = error.error.message;
        else if (error.message) msg = error.message;

        if (error.status !== 0) {
          this.snackBar.open(msg, 'Close', { duration: 4000, panelClass: ['error-snack'] });
        }
        return throwError(() => error);
      })
    );
  }
}
