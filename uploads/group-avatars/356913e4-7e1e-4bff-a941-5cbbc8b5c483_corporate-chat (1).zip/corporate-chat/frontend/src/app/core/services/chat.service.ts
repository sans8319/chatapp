import { Injectable, OnDestroy } from '@angular/core';
import { Subject, Subscription, interval } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ChatApiService } from './chat-api.service';
import { WebSocketService } from './websocket.service';
import { ChatStateService } from './chat-state.service';
import { AuthService } from './auth.service';
import { UserApiService } from './user-api.service';
import { APP_CONFIG } from '../../config/app.config';
import { Message, Chat, PresenceEvent } from '../../shared/models';
import { v4 as uuidv4 } from 'uuid';

// Simple UUID shim since we won't install uuid
function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

@Injectable({ providedIn: 'root' })
export class ChatService implements OnDestroy {
  private destroy$ = new Subject<void>();
  private heartbeatSub?: Subscription;

  constructor(
    private api: ChatApiService,
    private ws: WebSocketService,
    private state: ChatStateService,
    private auth: AuthService,
    private userApi: UserApiService,
  ) {}

  init(): void {
    this.ws.connect();
    this.subscribeToWsEvents();
    this.loadChats();
    this.startHeartbeat();
  }

  shutdown(): void {
    this.heartbeatSub?.unsubscribe();
    this.ws.disconnect();
    this.destroy$.next();
  }

  loadChats(): void {
    this.api.getMyChats().subscribe(res => {
      if (res.success && res.data) this.state.setChats(res.data);
    });
  }

  openChat(chatId: string): void {
    const prev = this.state.activeChatId;
    if (prev && prev !== chatId) this.ws.unsubscribeFromChat(prev);
    this.state.setActiveChat(chatId);
    this.ws.subscribeToChat(chatId);
    this.loadMessages(chatId, 0, true);
    this.markSeen(chatId);
  }

  loadMessages(chatId: string, page = 0, reset = false): void {
    this.state.setLoading(true);
    this.api.getMessages(chatId, page, APP_CONFIG.MESSAGES_PAGE_SIZE).subscribe({
      next: res => {
        if (res.success && res.data) {
          if (reset || page === 0) {
            this.state.setMessages(chatId, res.data.content);
          } else {
            this.state.prependMessages(chatId, res.data.content);
          }
        }
        this.state.setLoading(false);
      },
      error: () => this.state.setLoading(false),
    });
  }

  sendMessage(chatId: string, content: string, options: {
    parentMessageId?: string; mentions?: string[]; forwardedFromId?: string;
  } = {}): void {
    const tempId = genId();
    const currentUser = this.auth.currentUser!;
    // Optimistic update
    const tempMsg: Message = {
      id: tempId,
      chatId,
      senderId: currentUser.id,
      senderName: currentUser.displayName || currentUser.username,
      senderAvatar: currentUser.avatarUrl,
      senderActive: true,
      content,
      messageType: 'TEXT',
      edited: false,
      deleted: false,
      deletedForEveryone: false,
      createdAt: new Date().toISOString(),
      deliveryStatus: 'SENT',
      _pending: true,
      clientTempId: tempId,
      ...options,
    };
    this.state.addMessage(chatId, tempMsg);

    this.api.sendMessage({ chatId, content, clientTempId: tempId, ...options }).subscribe({
      next: res => {
        if (res.success && res.data) {
          // Replace optimistic message with real one (addMessage handles dedup by clientTempId)
          this.state.addMessage(chatId, { ...res.data, clientTempId: tempId });
          this.state.updateChatLastMessage(chatId, res.data);
        }
      },
      error: () => {
        this.state.markPendingMessage(chatId, tempId, true);
      },
    });
  }

  sendFile(chatId: string, file: File): void {
    const tempId = genId();
    const currentUser = this.auth.currentUser!;
    const tempMsg: Message = {
      id: tempId, chatId,
      senderId: currentUser.id,
      senderName: currentUser.displayName || currentUser.username,
      senderAvatar: currentUser.avatarUrl,
      senderActive: true,
      content: file.name,
      messageType: file.type.startsWith('image/') ? 'IMAGE' : file.type.startsWith('video/') ? 'VIDEO' : 'DOCUMENT',
      edited: false, deleted: false, deletedForEveryone: false,
      createdAt: new Date().toISOString(),
      deliveryStatus: 'SENT', _pending: true, clientTempId: tempId,
    };
    this.state.addMessage(chatId, tempMsg);

    this.api.sendFile(chatId, file).subscribe({
      next: res => {
        if (res.success && res.data) {
          this.state.addMessage(chatId, { ...res.data, clientTempId: tempId });
          this.state.updateChatLastMessage(chatId, res.data);
        }
      },
      error: () => this.state.markPendingMessage(chatId, tempId, true),
    });
  }

  editMessage(chatId: string, messageId: string, content: string): void {
    this.api.editMessage(messageId, content).subscribe(res => {
      if (res.success && res.data) this.state.updateMessage(chatId, res.data);
    });
  }

  deleteMessage(chatId: string, messageId: string, forEveryone: boolean): void {
    this.api.deleteMessage(messageId, forEveryone).subscribe(res => {
      if (res.success) this.state.removeMessage(chatId, messageId, forEveryone);
    });
  }

  toggleReaction(chatId: string, messageId: string, emoji: string): void {
    this.api.toggleReaction(messageId, emoji).subscribe(res => {
      if (res.success && res.data) this.state.updateMessage(chatId, res.data);
    });
  }

  pinMessage(chatId: string, messageId: string, pin: boolean): void {
    this.api.pinMessage(chatId, messageId, pin).subscribe();
  }

  starMessage(messageId: string, star: boolean): void {
    this.api.starMessage(messageId, star).subscribe();
  }

  markSeen(chatId: string): void {
    this.state.resetUnread(chatId);
    this.api.markAsSeen(chatId).subscribe();
  }

  sendTyping(chatId: string, typing: boolean): void {
    this.ws.sendTyping(chatId, typing);
  }

  private subscribeToWsEvents(): void {
    // New message
    this.ws.message$.pipe(takeUntil(this.destroy$)).subscribe(msg => {
      this.state.addMessage(msg.chatId, msg);
      this.state.updateChatLastMessage(msg.chatId, msg);
      if (msg.chatId !== this.state.activeChatId) {
        this.state.incrementUnread(msg.chatId);
      } else {
        this.markSeen(msg.chatId);
      }
    });

    // Message edit
    this.ws.messageEdit$.pipe(takeUntil(this.destroy$)).subscribe(msg => {
      this.state.updateMessage(msg.chatId, msg);
    });

    // Message delete
    this.ws.messageDelete$.pipe(takeUntil(this.destroy$)).subscribe(evt => {
      this.state.removeMessage(evt.chatId, evt.messageId, evt.forEveryone);
    });

    // Reactions
    this.ws.reaction$.pipe(takeUntil(this.destroy$)).subscribe(msg => {
      this.state.updateMessage(msg.chatId, msg);
    });

    // Pin
    this.ws.pin$.pipe(takeUntil(this.destroy$)).subscribe(evt => {
      const messages = this.state.getMessages(evt.chatId);
      const msg = messages.find(m => m.id === evt.messageId);
      if (msg) this.state.updateMessage(evt.chatId, { ...msg, pinned: evt.pinned });
    });

    // Typing
    this.ws.typing$.pipe(takeUntil(this.destroy$)).subscribe(evt => {
      const currentUserId = this.auth.currentUser?.id;
      if (evt.userId !== currentUserId) {
        this.state.setTyping(evt.chatId, evt.userId, evt.userName, evt.typing);
      }
    });

    // Presence
    this.ws.presence$.pipe(takeUntil(this.destroy$)).subscribe((evt: PresenceEvent) => {
      // Update member presence in chat list
      const chats = this.state.chats;
      chats.forEach(chat => {
        const member = chat.members?.find(m => m.userId === evt.userId);
        if (member) member.presenceStatus = evt.status;
      });
      this.state.setChats([...chats]);
    });

    // New chat from WS
    this.ws.newChat$.pipe(takeUntil(this.destroy$)).subscribe(chat => {
      this.state.upsertChat(chat);
    });
  }

  private startHeartbeat(): void {
    this.heartbeatSub = interval(APP_CONFIG.HEARTBEAT_INTERVAL)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.ws.sendHeartbeat();
        this.userApi.sendHeartbeat().subscribe();
      });
  }

  ngOnDestroy(): void {
    this.shutdown();
    this.destroy$.complete();
  }
}
