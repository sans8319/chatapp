import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

// Angular Material
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatRippleModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { OverlayModule } from '@angular/cdk/overlay';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { AppComponent } from './app.component';
import { APP_ROUTES } from './app.routes';

// Interceptors
import { AuthInterceptor } from './core/interceptors/auth.interceptor';
import { ErrorInterceptor } from './core/interceptors/error.interceptor';

// Guards
import { AuthGuard } from './core/guards/auth.guard';
import { AdminGuard } from './core/guards/admin.guard';

// Feature components
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { ChatListComponent } from './features/chat/chat-list/chat-list.component';
import { ChatWindowComponent } from './features/chat/chat-window/chat-window.component';
import { MessageItemComponent } from './features/chat/message-item/message-item.component';
import { NewChatDialogComponent } from './features/chat/new-chat/new-chat-dialog.component';
import { GroupSettingsDialogComponent } from './features/chat/group-settings/group-settings-dialog.component';
import { SearchComponent } from './features/chat/search/search.component';
import { AdminPanelComponent } from './features/admin/admin-panel.component';
import { ProfileComponent } from './features/profile/profile.component';

// Shared components
import { UserAvatarComponent } from './shared/components/user-avatar/user-avatar.component';
import { TypingIndicatorComponent } from './shared/components/typing-indicator/typing-indicator.component';
import { EmojiPickerComponent } from './shared/components/emoji-picker/emoji-picker.component';
import { FileUploadComponent } from './shared/components/file-upload/file-upload.component';
import { MessageBubbleComponent } from './shared/components/message-bubble/message-bubble.component';
import { MainLayoutComponent } from './features/chat/main-layout/main-layout.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ChatListComponent,
    ChatWindowComponent,
    MessageItemComponent,
    NewChatDialogComponent,
    GroupSettingsDialogComponent,
    SearchComponent,
    AdminPanelComponent,
    ProfileComponent,
    UserAvatarComponent,
    TypingIndicatorComponent,
    EmojiPickerComponent,
    FileUploadComponent,
    MessageBubbleComponent,
    MainLayoutComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(APP_ROUTES),
    InfiniteScrollModule,
    // Material
    MatButtonModule, MatInputModule, MatFormFieldModule, MatIconModule,
    MatListModule, MatMenuModule, MatDialogModule, MatSnackBarModule,
    MatTooltipModule, MatBadgeModule, MatProgressSpinnerModule,
    MatChipsModule, MatAutocompleteModule, MatSelectModule,
    MatSlideToggleModule, MatTabsModule, MatRippleModule,
    MatDividerModule, MatCardModule, MatToolbarModule, MatSidenavModule,
    OverlayModule,
  ],
  providers: [
    AuthGuard, AdminGuard,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
