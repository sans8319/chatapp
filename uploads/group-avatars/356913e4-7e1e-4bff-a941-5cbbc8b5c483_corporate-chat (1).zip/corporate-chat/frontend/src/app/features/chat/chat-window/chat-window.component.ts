import {
  Component, OnInit, OnDestroy, ViewChild,
  ElementRef, AfterViewChecked, ChangeDetectorRef
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject, BehaviorSubject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ChatService } from '../../../core/services/chat.service';
import { ChatStateService } from '../../../core/services/chat-state.service';
import { AuthService } from '../../../core/services/auth.service';
import { ChatApiService } from '../../../core/services/chat-api.service';
import { WebSocketService } from '../../../core/services/websocket.service';
import { GroupSettingsDialogComponent } from '../group-settings/group-settings-dialog.component';
import { APP_CONFIG } from '../../../config/app.config';
import { Chat, Message, User } from '../../../shared/models';

@Component({
  selector: 'app-chat-window',
  templateUrl: './chat-window.component.html',
  styleUrls: ['./chat-window.component.scss'],
})
export class ChatWindowComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('messageContainer') messageContainer!: ElementRef;
  @ViewChild('messageInput') messageInput!: ElementRef;

  private destroy$ = new Subject<void>();
  private typingTimeout?: ReturnType<typeof setTimeout>;
  private shouldScrollToBottom = true;
  private lastScrollHeight = 0;
  private typingInput$ = new Subject<string>();

  chat: Chat | null = null;
  messages: Message[] = [];
  inputText = '';
  loadingMessages = false;
  loadingMore = false;
  currentPage = 0;
  hasMoreMessages = false;
  showEmojiPicker = false;
  typingUsers: Map<string, string> = new Map();
  replyingTo: Message | null = null;
  editingMessage: Message | null = null;
  searchMode = false;
  searchQuery = '';
  searchResults: Message[] = [];
  pinnedMessages: Message[] = [];
  showPinned = false;
  currentUserId = '';
  isGroup = false;

  constructor(
    private route: ActivatedRoute,
    public chatService: ChatService,
    public state: ChatStateService,
    public auth: AuthService,
    private api: ChatApiService,
    private ws: WebSocketService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.currentUserId = this.auth.currentUser?.id ?? '';

    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const chatId = params['id'];
      if (chatId) this.initChat(chatId);
    });

    this.state.loadingMessages$.pipe(takeUntil(this.destroy$))
      .subscribe(l => (this.loadingMessages = l));

    // Debounce typing indicator
    this.typingInput$.pipe(
      debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$)
    ).subscribe(text => {
      if (this.chat) this.chatService.sendTyping(this.chat.id, text.length > 0);
    });
  }

  private initChat(chatId: string): void {
    this.chatService.openChat(chatId);
    this.chat = this.state.activeChat ?? null;

    this.state.chats$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.chat = this.state.chats.find(c => c.id === chatId) ?? null;
      if (this.chat) this.isGroup = this.chat.type === 'GROUP';
    });

    this.state.getMessages$(chatId).pipe(takeUntil(this.destroy$)).subscribe(msgs => {
      const wasAtBottom = this.isAtBottom();
      this.messages = msgs;
      this.shouldScrollToBottom = wasAtBottom;
      this.cdr.detectChanges();
    });

    this.state.getTyping$(chatId).pipe(takeUntil(this.destroy$)).subscribe(map => {
      this.typingUsers = map;
      this.cdr.detectChanges();
    });
  }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  onScroll(): void {
    const el = this.messageContainer?.nativeElement;
    if (!el) return;
    if (el.scrollTop < 100 && !this.loadingMore && this.hasMoreMessages) {
      this.loadOlderMessages();
    }
  }

  private loadOlderMessages(): void {
    if (!this.chat) return;
    this.loadingMore = true;
    const el = this.messageContainer.nativeElement;
    this.lastScrollHeight = el.scrollHeight;
    this.currentPage++;
    this.api.getMessages(this.chat.id, this.currentPage, APP_CONFIG.MESSAGES_PAGE_SIZE).subscribe({
      next: res => {
        if (res.success && res.data) {
          this.hasMoreMessages = res.data.hasNext;
          this.state.prependMessages(this.chat!.id, res.data.content);
          // Maintain scroll position after prepend
          setTimeout(() => {
            el.scrollTop = el.scrollHeight - this.lastScrollHeight;
          }, 0);
        }
        this.loadingMore = false;
      },
      error: () => (this.loadingMore = false),
    });
  }

  sendMessage(): void {
    if (!this.chat) return;
    const text = this.inputText.trim();
    if (!text && !this.editingMessage) return;

    if (this.editingMessage) {
      this.chatService.editMessage(this.chat.id, this.editingMessage.id, text);
      this.cancelEdit();
      return;
    }

    // Parse mentions: @username -> userId
    const mentions = this.extractMentions(text);
    this.chatService.sendMessage(this.chat.id, text, {
      parentMessageId: this.replyingTo?.id,
      mentions,
    });
    this.inputText = '';
    this.replyingTo = null;
    this.shouldScrollToBottom = true;
    this.chatService.sendTyping(this.chat.id, false);
  }

  private extractMentions(text: string): string[] {
    const regex = /@(\w+)/g;
    const matches: string[] = [];
    let m;
    while ((m = regex.exec(text)) !== null) {
      const member = this.chat?.members?.find(mb =>
        mb.username === m[1] || mb.displayName === m[1]);
      if (member) matches.push(member.userId);
    }
    return [...new Set(matches)];
  }

  onInputKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
    this.typingInput$.next(this.inputText);
  }

  onInputChange(): void {
    this.typingInput$.next(this.inputText);
    if (this.typingTimeout) clearTimeout(this.typingTimeout);
    this.typingTimeout = setTimeout(() => {
      if (this.chat) this.chatService.sendTyping(this.chat.id, false);
    }, APP_CONFIG.TYPING_TIMEOUT);
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length || !this.chat) return;
    const file = input.files[0];
    if (file.size > APP_CONFIG.MAX_UPLOAD_SIZE) {
      this.snackBar.open('File too large (max 50MB)', 'Close', { duration: 3000 });
      return;
    }
    this.chatService.sendFile(this.chat.id, file);
    input.value = '';
  }

  onEmojiSelect(emoji: string): void {
    this.inputText += emoji;
    this.showEmojiPicker = false;
    this.messageInput?.nativeElement.focus();
  }

  replyTo(message: Message): void {
    this.replyingTo = message;
    this.messageInput?.nativeElement.focus();
  }

  cancelReply(): void { this.replyingTo = null; }

  startEdit(message: Message): void {
    this.editingMessage = message;
    this.inputText = message.content ?? '';
    this.messageInput?.nativeElement.focus();
  }

  cancelEdit(): void {
    this.editingMessage = null;
    this.inputText = '';
  }

  deleteMessage(message: Message, forEveryone: boolean): void {
    if (!this.chat) return;
    this.chatService.deleteMessage(this.chat.id, message.id, forEveryone);
  }

  toggleReaction(message: Message, emoji: string): void {
    if (!this.chat) return;
    this.chatService.toggleReaction(this.chat.id, message.id, emoji);
  }

  pinMessage(message: Message): void {
    if (!this.chat) return;
    this.chatService.pinMessage(this.chat.id, message.id, !message.pinned);
  }

  starMessage(message: Message): void {
    this.chatService.starMessage(message.id, !message.starred);
  }

  forwardMessage(message: Message): void {
    // Open new chat dialog to forward to
    this.snackBar.open('Forward: Select a chat (not yet implemented in demo)', 'Ok', { duration: 2000 });
  }

  loadPinnedMessages(): void {
    if (!this.chat) return;
    this.showPinned = !this.showPinned;
    if (this.showPinned) {
      this.api.getPinnedMessages(this.chat.id).subscribe(res => {
        if (res.success) this.pinnedMessages = res.data ?? [];
      });
    }
  }

  openGroupSettings(): void {
    if (!this.chat) return;
    this.dialog.open(GroupSettingsDialogComponent, {
      width: '480px',
      data: { chat: this.chat },
      panelClass: 'dialog-panel',
    }).afterClosed().subscribe(updated => {
      if (updated) this.state.upsertChat(updated);
    });
  }

  searchMessages(): void {
    if (!this.chat || !this.searchQuery.trim()) return;
    this.api.searchMessages(this.chat.id, this.searchQuery).subscribe(res => {
      if (res.success) this.searchResults = res.data?.content ?? [];
    });
  }

  clearSearch(): void {
    this.searchMode = false;
    this.searchQuery = '';
    this.searchResults = [];
  }

  getOtherMember(): any {
    if (!this.chat || this.chat.type !== 'DIRECT') return null;
    return this.chat.members?.find(m => m.userId !== this.currentUserId);
  }

  isMessageMine(message: Message): boolean {
    return message.senderId === this.currentUserId;
  }

  getTypingText(): string {
    const users = Array.from(this.typingUsers.values());
    if (users.length === 0) return '';
    if (users.length === 1) return `${users[0]} is typing…`;
    if (users.length === 2) return `${users[0]} and ${users[1]} are typing…`;
    return 'Several people are typing…';
  }

  private isAtBottom(): boolean {
    const el = this.messageContainer?.nativeElement;
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight < 100;
  }

  private scrollToBottom(): void {
    try {
      const el = this.messageContainer?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    } catch {}
  }

  trackById(_: number, msg: Message): string { return msg.id; }

  ngOnDestroy(): void {
    if (this.typingTimeout) clearTimeout(this.typingTimeout);
    this.destroy$.next();
    this.destroy$.complete();
  }
}
