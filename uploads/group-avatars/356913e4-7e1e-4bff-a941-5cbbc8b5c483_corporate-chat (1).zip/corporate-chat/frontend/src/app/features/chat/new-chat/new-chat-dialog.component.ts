import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { ChatApiService } from '../../../core/services/chat-api.service';
import { UserApiService } from '../../../core/services/user-api.service';
import { AuthService } from '../../../core/services/auth.service';
import { User } from '../../../shared/models';

@Component({
  selector: 'app-new-chat-dialog',
  template: `
<div class="dialog-container">
  <h2 mat-dialog-title>
    <mat-icon>chat</mat-icon> New Conversation
  </h2>

  <mat-dialog-content>
    <mat-tab-group [(selectedIndex)]="tabIndex">
      <!-- Direct Chat -->
      <mat-tab label="Direct Message">
        <div class="tab-content">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Search users</mat-label>
            <mat-icon matPrefix>search</mat-icon>
            <input matInput [(ngModel)]="userSearch" (input)="onSearch()" placeholder="Type a name…" />
          </mat-form-field>
          <div class="user-list">
            <div class="user-item" *ngFor="let user of filteredUsers"
                 [class.selected]="isSelected(user.id)"
                 (click)="toggleUser(user)" matRipple>
              <app-user-avatar [user]="user" [size]="36"></app-user-avatar>
              <div class="user-info-wrap">
                <span class="uname" [class.inactive]="!user.active">
                  {{ user.displayName || user.username }}
                </span>
                <span class="username">&#64;{{ user.username }}</span>
              </div>
              <mat-icon *ngIf="isSelected(user.id)" class="check-icon">check_circle</mat-icon>
            </div>
            <div *ngIf="filteredUsers.length === 0" class="no-results">
              <mat-icon>person_search</mat-icon>
              <p>No users found</p>
            </div>
          </div>
        </div>
      </mat-tab>

      <!-- Group Chat -->
      <mat-tab label="Group Chat">
        <div class="tab-content">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Group Name</mat-label>
            <mat-icon matPrefix>group</mat-icon>
            <input matInput [formControl]="groupNameCtrl" placeholder="Enter group name" />
          </mat-form-field>
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Search & add members</mat-label>
            <mat-icon matPrefix>person_add</mat-icon>
            <input matInput [(ngModel)]="userSearch" (input)="onSearch()" />
          </mat-form-field>

          <!-- Selected chips -->
          <div class="selected-chips" *ngIf="selectedUsers.length > 0">
            <mat-chip-set>
              <mat-chip *ngFor="let u of selectedUsers" (removed)="toggleUser(u)">
                {{ u.displayName || u.username }}
                <button matChipRemove><mat-icon>cancel</mat-icon></button>
              </mat-chip>
            </mat-chip-set>
          </div>

          <div class="user-list">
            <div class="user-item" *ngFor="let user of filteredUsers"
                 [class.selected]="isSelected(user.id)"
                 (click)="toggleUser(user)" matRipple>
              <app-user-avatar [user]="user" [size]="32"></app-user-avatar>
              <span class="uname">{{ user.displayName || user.username }}</span>
              <mat-icon *ngIf="isSelected(user.id)" class="check-icon">check_circle</mat-icon>
            </div>
          </div>
        </div>
      </mat-tab>
    </mat-tab-group>
  </mat-dialog-content>

  <mat-dialog-actions align="end">
    <button mat-button (click)="close()">Cancel</button>
    <button mat-raised-button color="primary"
            [disabled]="!canCreate() || loading"
            (click)="create()">
      <mat-spinner *ngIf="loading" diameter="16" class="inline-spinner"></mat-spinner>
      <span *ngIf="!loading">{{ tabIndex === 0 ? 'Start Chat' : 'Create Group' }}</span>
    </button>
  </mat-dialog-actions>
</div>`,
  styleUrls: ['./new-chat-dialog.component.scss'],
})
export class NewChatDialogComponent implements OnInit {
  tabIndex = 0;
  userSearch = '';
  allUsers: User[] = [];
  filteredUsers: User[] = [];
  selectedUsers: User[] = [];
  loading = false;
  groupNameCtrl;

  constructor(
    private dialogRef: MatDialogRef<NewChatDialogComponent>,
    private chatApi: ChatApiService,
    private userApi: UserApiService,
    private auth: AuthService,
    private fb: FormBuilder,
  ) {
    this.groupNameCtrl = this.fb.control('', Validators.required);
  }

  ngOnInit(): void {
    this.userApi.getAllActiveUsers().subscribe(res => {
      if (res.success && res.data) {
        this.allUsers = res.data.filter(u => u.id !== this.auth.currentUser?.id);
        this.filteredUsers = [...this.allUsers];
      }
    });
  }

  onSearch(): void {
    const q = this.userSearch.toLowerCase();
    this.filteredUsers = this.allUsers.filter(u =>
      u.displayName?.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q));
  }

  toggleUser(user: User): void {
    const idx = this.selectedUsers.findIndex(u => u.id === user.id);
    if (idx >= 0) this.selectedUsers.splice(idx, 1);
    else {
      if (this.tabIndex === 0) this.selectedUsers = [user]; // direct: only 1
      else this.selectedUsers.push(user);
    }
  }

  isSelected(id: string): boolean {
    return this.selectedUsers.some(u => u.id === id);
  }

  canCreate(): boolean {
    if (this.tabIndex === 0) return this.selectedUsers.length === 1;
    return this.selectedUsers.length >= 1 && !!this.groupNameCtrl.value?.trim();
  }

  create(): void {
    if (!this.canCreate()) return;
    this.loading = true;
    const memberIds = this.selectedUsers.map(u => u.id);
    const payload = this.tabIndex === 0
      ? { type: 'DIRECT', memberIds }
      : { type: 'GROUP', name: this.groupNameCtrl.value, memberIds };

    this.chatApi.createChat(payload).subscribe({
      next: res => {
        this.loading = false;
        if (res.success) this.dialogRef.close(res.data);
      },
      error: () => (this.loading = false),
    });
  }

  close(): void { this.dialogRef.close(); }
}
