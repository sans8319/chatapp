import { Component, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ChatApiService } from '../../../core/services/chat-api.service';
import { UserApiService } from '../../../core/services/user-api.service';
import { ChatStateService } from '../../../core/services/chat-state.service';
import { ChatApiService as ChatApi } from '../../../core/services/chat-api.service';
import { Message, User } from '../../../shared/models';

@Component({
  selector: 'app-search',
  template: `
<div class="search-panel">
  <div class="search-header">
    <mat-icon>search</mat-icon>
    <input class="search-input" [(ngModel)]="query" (input)="onInput()"
           placeholder="Search messages, users…" autofocus />
    <button mat-icon-button *ngIf="query" (click)="clear()">
      <mat-icon>close</mat-icon>
    </button>
  </div>

  <mat-tab-group *ngIf="query.length >= 2">
    <mat-tab label="Messages ({{ msgResults.length }})">
      <div class="results-list">
        <div class="result-item" *ngFor="let m of msgResults"
             (click)="goToMessage(m)" matRipple>
          <mat-icon class="ri-icon">chat_bubble</mat-icon>
          <div class="ri-content">
            <span class="ri-title">{{ m.senderName }}</span>
            <span class="ri-sub">{{ m.content }}</span>
          </div>
          <span class="ri-time">{{ m.createdAt | date:'shortDate' }}</span>
        </div>
        <div *ngIf="msgResults.length === 0 && !loading" class="no-results">
          <mat-icon>search_off</mat-icon> No messages found
        </div>
      </div>
    </mat-tab>

    <mat-tab label="Users ({{ userResults.length }})">
      <div class="results-list">
        <div class="result-item" *ngFor="let u of userResults"
             (click)="startChatWith(u)" matRipple>
          <app-user-avatar [user]="u" [size]="32"></app-user-avatar>
          <div class="ri-content">
            <span class="ri-title" [class.inactive]="!u.active">
              {{ u.displayName || u.username }}
            </span>
            <span class="ri-sub">{{ u.email }}</span>
          </div>
          <span class="ri-badge" *ngIf="!u.active">Inactive</span>
        </div>
        <div *ngIf="userResults.length === 0 && !loading" class="no-results">
          <mat-icon>person_search</mat-icon> No users found
        </div>
      </div>
    </mat-tab>
  </mat-tab-group>

  <div class="search-hint" *ngIf="query.length < 2">
    <mat-icon>tips_and_updates</mat-icon>
    Type at least 2 characters to search
  </div>

  <div class="search-loading" *ngIf="loading">
    <mat-spinner diameter="28"></mat-spinner>
  </div>
</div>`,
  styles: [`
.search-panel { padding: 0; height: 100%; display: flex; flex-direction: column; }
.search-header {
  display: flex; align-items: center; gap: 8px;
  padding: 12px 16px; border-bottom: 1px solid var(--border); background: var(--surface);
  mat-icon { color: var(--text-secondary); }
}
.search-input { flex: 1; border: none; outline: none; font-size: 15px; background: transparent; color: var(--text-primary); }
.results-list { padding: 8px; max-height: 400px; overflow-y: auto; }
.result-item {
  display: flex; align-items: center; gap: 10px; padding: 10px 12px;
  border-radius: 8px; cursor: pointer;
  &:hover { background: var(--hover); }
}
.ri-icon { color: var(--text-secondary); }
.ri-content { flex: 1; overflow: hidden; }
.ri-title { display: block; font-size: 13px; font-weight: 600; white-space: nowrap;
            overflow: hidden; text-overflow: ellipsis; &.inactive { color: var(--inactive-text); } }
.ri-sub { display: block; font-size: 12px; color: var(--text-secondary); white-space: nowrap;
          overflow: hidden; text-overflow: ellipsis; }
.ri-time { font-size: 11px; color: var(--text-secondary); flex-shrink: 0; }
.ri-badge { font-size: 11px; background: #fce4ec; color: #c62828; padding: 2px 6px; border-radius: 8px; }
.no-results { display: flex; align-items: center; gap: 8px; padding: 24px; color: var(--text-secondary); justify-content: center; }
.search-hint { display: flex; align-items: center; gap: 8px; padding: 32px; color: var(--text-secondary); justify-content: center; }
.search-loading { display: flex; justify-content: center; padding: 24px; }
`],
})
export class SearchComponent implements OnDestroy {
  private destroy$ = new Subject<void>();
  private search$ = new Subject<string>();

  query = '';
  msgResults: Message[] = [];
  userResults: User[] = [];
  loading = false;

  constructor(
    private chatApi: ChatApiService,
    private userApi: UserApiService,
    private state: ChatStateService,
    private router: Router,
  ) {
    this.search$.pipe(debounceTime(400), takeUntil(this.destroy$)).subscribe(q => this.runSearch(q));
  }

  onInput(): void { this.search$.next(this.query); }

  private runSearch(q: string): void {
    if (q.length < 2) return;
    this.loading = true;

    // Search users
    this.userApi.searchUsers(q, 0, 10, false).subscribe({
      next: res => { if (res.success) this.userResults = res.data?.content ?? []; },
      error: () => {},
    });

    // Search messages across all chats the user is in
    const chats = this.state.chats;
    this.msgResults = [];
    let pending = chats.length;
    if (pending === 0) { this.loading = false; return; }

    chats.forEach(chat => {
      this.chatApi.searchMessages(chat.id, q, 0, 5).subscribe({
        next: res => {
          if (res.success && res.data) this.msgResults.push(...res.data.content);
        },
        error: () => {},
        complete: () => { pending--; if (pending === 0) this.loading = false; },
      });
    });
  }

  goToMessage(msg: Message): void {
    this.router.navigate(['/chat', msg.chatId]);
    this.clear();
  }

  startChatWith(user: User): void {
    this.chatApi.createChat({ type: 'DIRECT', memberIds: [user.id] }).subscribe(res => {
      if (res.success && res.data) {
        this.state.upsertChat(res.data);
        this.router.navigate(['/chat', res.data.id]);
        this.clear();
      }
    });
  }

  clear(): void {
    this.query = '';
    this.msgResults = [];
    this.userResults = [];
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }
}
