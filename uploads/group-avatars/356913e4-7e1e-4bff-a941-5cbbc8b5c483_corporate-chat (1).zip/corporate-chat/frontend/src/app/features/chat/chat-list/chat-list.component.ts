import { Component, EventEmitter, Input, OnInit, OnDestroy, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ChatStateService } from '../../../core/services/chat-state.service';
import { AuthService } from '../../../core/services/auth.service';
import { Chat } from '../../../shared/models';

@Component({
  selector: 'app-chat-list',
  templateUrl: './chat-list.component.html',
  styleUrls: ['./chat-list.component.scss'],
})
export class ChatListComponent implements OnInit, OnDestroy {
  @Input() searchQuery = '';
  @Output() chatSelected = new EventEmitter<string>();

  private destroy$ = new Subject<void>();
  chats: Chat[] = [];
  currentUserId = '';

  constructor(public state: ChatStateService, private auth: AuthService) {}

  ngOnInit(): void {
    this.currentUserId = this.auth.currentUser?.id ?? '';
    this.state.chats$.pipe(takeUntil(this.destroy$)).subscribe(chats => (this.chats = chats));
  }

  get filteredChats(): Chat[] {
    if (!this.searchQuery) return this.chats;
    const q = this.searchQuery.toLowerCase();
    return this.chats.filter(c => c.name?.toLowerCase().includes(q));
  }

  selectChat(chatId: string): void {
    this.chatSelected.emit(chatId);
  }

  getLastMessagePreview(chat: Chat): string {
    if (!chat.lastMessage) return 'No messages yet';
    const msg = chat.lastMessage;
    if (msg.deletedForEveryone) return 'Message deleted';
    if (msg.messageType !== 'TEXT') return `📎 ${msg.messageType.toLowerCase()}`;
    return msg.content ? (msg.content.length > 50 ? msg.content.substring(0, 50) + '…' : msg.content) : '';
  }

  formatTime(dateStr?: string): string {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffDays === 0) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return date.toLocaleDateString([], { weekday: 'short' });
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }

  isActive(chatId: string): boolean {
    return this.state.activeChatId === chatId;
  }

  getOtherMember(chat: Chat) {
    if (chat.type !== 'DIRECT') return null;
    return chat.members?.find(m => m.userId !== this.currentUserId) ?? null;
  }

  isOtherUserActive(chat: Chat): boolean {
    const other = this.getOtherMember(chat);
    return other?.userActive ?? true;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
