import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ChatApiService } from '../../../core/services/chat-api.service';
import { UserApiService } from '../../../core/services/user-api.service';
import { AuthService } from '../../../core/services/auth.service';
import { Chat, User } from '../../../shared/models';

@Component({
  selector: 'app-group-settings-dialog',
  template: `
<div class="dialog-container">
  <h2 mat-dialog-title><mat-icon>group</mat-icon> Group Settings</h2>
  <mat-dialog-content>
    <mat-tab-group>
      <!-- Info -->
      <mat-tab label="Info">
        <div class="settings-section">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Group Name</mat-label>
            <input matInput [formControl]="nameCtrl" />
          </mat-form-field>
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Description</mat-label>
            <textarea matInput [formControl]="descCtrl" rows="3"></textarea>
          </mat-form-field>
          <button mat-raised-button color="primary" (click)="saveInfo()" [disabled]="saving">
            Save Changes
          </button>
        </div>
      </mat-tab>

      <!-- Members -->
      <mat-tab label="Members ({{ chat.members?.length }})">
        <div class="members-list">
          <div class="member-item" *ngFor="let m of chat.members">
            <app-user-avatar [userName]="m.displayName" [size]="36"></app-user-avatar>
            <div class="member-info">
              <span class="mname" [class.inactive]="!m.userActive">
                {{ m.displayName || m.username }}
              </span>
              <span class="mrole">{{ m.memberRole }}</span>
            </div>
            <div class="member-actions">
              <span class="online-dot" [class.online]="m.presenceStatus === 'ONLINE'"></span>
              <button mat-icon-button color="warn"
                      *ngIf="isAdminOrOwner && m.userId !== currentUserId"
                      (click)="removeMember(m.userId)"
                      matTooltip="Remove">
                <mat-icon>person_remove</mat-icon>
              </button>
            </div>
          </div>
        </div>
        <mat-divider></mat-divider>
        <div class="add-member-section" *ngIf="isAdminOrOwner">
          <p class="section-label">Add Members</p>
          <mat-form-field appearance="outline" class="full-width">
            <mat-label>Search users</mat-label>
            <input matInput [(ngModel)]="addSearch" (input)="onAddSearch()" />
          </mat-form-field>
          <div class="user-list-compact">
            <div class="user-item-sm" *ngFor="let u of addResults"
                 [class.already-member]="isMember(u.id)"
                 (click)="addMember(u)" matRipple>
              <app-user-avatar [user]="u" [size]="28"></app-user-avatar>
              <span>{{ u.displayName || u.username }}</span>
              <mat-icon *ngIf="isMember(u.id)">check</mat-icon>
            </div>
          </div>
        </div>
      </mat-tab>
    </mat-tab-group>
  </mat-dialog-content>
  <mat-dialog-actions align="end">
    <button mat-button color="warn" (click)="leaveGroup()">Leave Group</button>
    <button mat-button (click)="close()">Close</button>
  </mat-dialog-actions>
</div>`,
  styleUrls: ['./group-settings-dialog.component.scss'],
})
export class GroupSettingsDialogComponent implements OnInit {
  chat: Chat;
  nameCtrl: FormControl;
  descCtrl: FormControl;
  saving = false;
  addSearch = '';
  addResults: User[] = [];
  allUsers: User[] = [];
  currentUserId = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) data: { chat: Chat },
    private dialogRef: MatDialogRef<GroupSettingsDialogComponent>,
    private chatApi: ChatApiService,
    private userApi: UserApiService,
    private auth: AuthService,
    private snackBar: MatSnackBar,
  ) {
    this.chat = { ...data.chat };
    this.nameCtrl = new FormControl(this.chat.name, Validators.required);
    this.descCtrl = new FormControl(this.chat.description ?? '');
    this.currentUserId = this.auth.currentUser?.id ?? '';
  }

  ngOnInit(): void {
    this.userApi.getAllActiveUsers().subscribe(res => {
      if (res.success && res.data) this.allUsers = res.data;
    });
  }

  get isAdminOrOwner(): boolean {
    return this.chat.memberRole === 'OWNER' || this.chat.memberRole === 'ADMIN';
  }

  isMember(userId: string): boolean {
    return this.chat.members?.some(m => m.userId === userId) ?? false;
  }

  onAddSearch(): void {
    const q = this.addSearch.toLowerCase();
    this.addResults = q
      ? this.allUsers.filter(u => !this.isMember(u.id) &&
          (u.displayName?.toLowerCase().includes(q) || u.username.includes(q)))
      : [];
  }

  saveInfo(): void {
    if (this.nameCtrl.invalid) return;
    this.saving = true;
    this.chatApi.updateChat(this.chat.id, {
      name: this.nameCtrl.value,
      description: this.descCtrl.value,
    }).subscribe({
      next: res => {
        this.saving = false;
        if (res.success && res.data) {
          this.snackBar.open('Group updated', 'Ok', { duration: 2000 });
          this.dialogRef.close(res.data);
        }
      },
      error: () => (this.saving = false),
    });
  }

  addMember(user: User): void {
    if (this.isMember(user.id)) return;
    this.chatApi.addMembers(this.chat.id, [user.id]).subscribe(res => {
      if (res.success) {
        this.snackBar.open(`${user.displayName || user.username} added`, 'Ok', { duration: 2000 });
        this.chatApi.getChat(this.chat.id).subscribe(r => { if (r.data) this.chat = r.data; });
      }
    });
  }

  removeMember(userId: string): void {
    this.chatApi.removeMember(this.chat.id, userId).subscribe(res => {
      if (res.success) {
        this.chat = { ...this.chat, members: this.chat.members?.filter(m => m.userId !== userId) };
        this.snackBar.open('Member removed', 'Ok', { duration: 2000 });
      }
    });
  }

  leaveGroup(): void {
    this.chatApi.leaveChat(this.chat.id).subscribe(res => {
      if (res.success) this.dialogRef.close('left');
    });
  }

  close(): void { this.dialogRef.close(); }
}
