import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserApiService } from '../../core/services/user-api.service';
import { User, PageResponse } from '../../shared/models';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.scss'],
})
export class AdminPanelComponent implements OnInit {
  users: User[] = [];
  loading = false;
  searchQuery = '';
  currentPage = 0;
  totalPages = 0;
  totalUsers = 0;
  pageSize = 20;
  actionLoading = new Set<string>();

  constructor(private userApi: UserApiService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    this.userApi.adminGetUsers(this.currentPage, this.pageSize).subscribe({
      next: res => {
        if (res.success && res.data) {
          this.users = res.data.content;
          this.totalPages = res.data.totalPages;
          this.totalUsers = res.data.totalElements;
        }
        this.loading = false;
      },
      error: () => (this.loading = false),
    });
  }

  search(): void {
    if (!this.searchQuery.trim()) {
      this.currentPage = 0;
      this.loadUsers();
      return;
    }
    this.loading = true;
    this.userApi.adminSearchUsers(this.searchQuery, 0, this.pageSize).subscribe({
      next: res => {
        if (res.success && res.data) this.users = res.data.content;
        this.loading = false;
      },
      error: () => (this.loading = false),
    });
  }

  deactivate(user: User): void {
    if (!confirm(`Deactivate ${user.displayName || user.username}? Their chat history will be preserved.`)) return;
    this.actionLoading.add(user.id);
    this.userApi.adminDeactivateUser(user.id).subscribe({
      next: res => {
        if (res.success) {
          user.active = false;
          this.snackBar.open('User deactivated. Chat history preserved.', 'Ok', { duration: 3000 });
        }
        this.actionLoading.delete(user.id);
      },
      error: () => this.actionLoading.delete(user.id),
    });
  }

  reactivate(user: User): void {
    this.actionLoading.add(user.id);
    this.userApi.adminReactivateUser(user.id).subscribe({
      next: res => {
        if (res.success) {
          user.active = true;
          this.snackBar.open('User reactivated', 'Ok', { duration: 2000 });
        }
        this.actionLoading.delete(user.id);
      },
      error: () => this.actionLoading.delete(user.id),
    });
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.loadUsers(); }
  }

  prevPage(): void {
    if (this.currentPage > 0) { this.currentPage--; this.loadUsers(); }
  }

  isLoading(userId: string): boolean { return this.actionLoading.has(userId); }
}
