import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ChatService } from '../../../core/services/chat.service';
import { ChatStateService } from '../../../core/services/chat-state.service';
import { AuthService } from '../../../core/services/auth.service';
import { UserApiService } from '../../../core/services/user-api.service';
import { WebSocketService } from '../../../core/services/websocket.service';
import { User } from '../../../shared/models';
import { MatDialog } from '@angular/material/dialog';
import { NewChatDialogComponent } from '../new-chat/new-chat-dialog.component';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss'],
})
export class MainLayoutComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  currentUser: User | null = null;
  sidebarOpen = true;
  unreadNotifications = 0;
  wsStatus = 'DISCONNECTED';
  searchQuery = '';

  constructor(
    public chatService: ChatService,
    public state: ChatStateService,
    public auth: AuthService,
    private userApi: UserApiService,
    private ws: WebSocketService,
    private router: Router,
    private dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.currentUser = this.auth.currentUser;
    this.chatService.init();

    this.auth.currentUser$.pipe(takeUntil(this.destroy$)).subscribe(u => (this.currentUser = u));
    this.ws.connectionState$.pipe(takeUntil(this.destroy$)).subscribe(s => (this.wsStatus = s));

    this.ws.notification$.pipe(takeUntil(this.destroy$)).subscribe(() => this.unreadNotifications++);

    this.userApi.getUnreadNotificationCount().subscribe(res => {
      if (res.success) this.unreadNotifications = res.data ?? 0;
    });
  }

  openNewChat(): void {
    this.dialog.open(NewChatDialogComponent, { width: '500px', panelClass: 'dialog-panel' })
      .afterClosed().subscribe((chat: any) => {
        if (chat) {
          this.state.upsertChat(chat);
          this.router.navigate(['/chat', chat.id]);
        }
      });
  }

  selectChat(chatId: string): void {
    this.router.navigate(['/chat', chatId]);
    this.chatService.openChat(chatId);
    if (window.innerWidth < 768) this.sidebarOpen = false;
  }

  logout(): void {
    this.chatService.shutdown();
    this.auth.logout();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
