import {
  Component, Input, Output, EventEmitter,
  OnInit, HostListener, ElementRef
} from '@angular/core';
import { Message } from '../../../shared/models';

@Component({
  selector: 'app-message-item',
  templateUrl: './message-item.component.html',
  styleUrls: ['./message-item.component.scss'],
})
export class MessageItemComponent implements OnInit {
  @Input() message!: Message;
  @Input() isMine = false;
  @Input() currentUserId = '';
  @Input() isGroup = false;

  @Output() reply = new EventEmitter<Message>();
  @Output() edit = new EventEmitter<Message>();
  @Output() delete = new EventEmitter<{ message: Message; forEveryone: boolean }>();
  @Output() react = new EventEmitter<{ message: Message; emoji: string }>();
  @Output() pin = new EventEmitter<Message>();
  @Output() star = new EventEmitter<Message>();
  @Output() forward = new EventEmitter<Message>();

  showActions = false;
  showReactionPicker = false;

  QUICK_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '👎'];

  ngOnInit(): void {}

  get reactionGroups(): { emoji: string; users: string[]; count: number; mine: boolean }[] {
    if (!this.message.reactions) return [];
    return Object.entries(this.message.reactions).map(([emoji, users]) => ({
      emoji, users, count: users.length,
      mine: users.includes(this.currentUserId),
    }));
  }

  get deliveryIcon(): string {
    if (!this.isMine) return '';
    switch (this.message.deliveryStatus) {
      case 'SEEN': return 'done_all';
      case 'DELIVERED': return 'done_all';
      case 'SENT': return 'done';
      default: return this.message._pending ? 'schedule' : 'done';
    }
  }

  get deliveryColor(): string {
    if (this.message.deliveryStatus === 'SEEN') return '#4fc3f7';
    return '#90a4ae';
  }

  get isDeleted(): boolean {
    return this.message.deletedForEveryone || this.message.deleted;
  }

  get formattedTime(): string {
    const d = new Date(this.message.createdAt);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  get isImage(): boolean {
    return this.message.messageType === 'IMAGE' ||
      (this.message.attachments?.some(a => a.attachmentType === 'IMAGE') ?? false);
  }

  get isVideo(): boolean {
    return this.message.messageType === 'VIDEO' ||
      (this.message.attachments?.some(a => a.attachmentType === 'VIDEO') ?? false);
  }

  get isDocument(): boolean {
    return this.message.messageType === 'DOCUMENT' ||
      (this.message.attachments?.some(a => a.attachmentType === 'DOCUMENT') ?? false);
  }

  onReact(emoji: string): void {
    this.react.emit({ message: this.message, emoji });
    this.showReactionPicker = false;
  }

  onReply(): void { this.reply.emit(this.message); }
  onEdit(): void { this.edit.emit(this.message); }
  onPin(): void { this.pin.emit(this.message); }
  onStar(): void { this.star.emit(this.message); }
  onForward(): void { this.forward.emit(this.message); }

  onDeleteForMe(): void {
    this.delete.emit({ message: this.message, forEveryone: false });
  }
  onDeleteForEveryone(): void {
    this.delete.emit({ message: this.message, forEveryone: true });
  }

  formatFileSize(bytes?: number): string {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1024 / 1024).toFixed(1) + ' MB';
  }

  getFileIcon(mimeType?: string): string {
    if (!mimeType) return 'insert_drive_file';
    if (mimeType.includes('pdf')) return 'picture_as_pdf';
    if (mimeType.includes('word') || mimeType.includes('document')) return 'description';
    if (mimeType.includes('sheet') || mimeType.includes('excel')) return 'table_chart';
    if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return 'slideshow';
    if (mimeType.includes('zip') || mimeType.includes('rar')) return 'folder_zip';
    if (mimeType.includes('text')) return 'article';
    return 'insert_drive_file';
  }
}
