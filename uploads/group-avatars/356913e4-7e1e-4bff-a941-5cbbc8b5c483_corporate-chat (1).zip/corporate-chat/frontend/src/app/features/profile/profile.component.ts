import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserApiService } from '../../core/services/user-api.service';
import { AuthService } from '../../core/services/auth.service';
import { User } from '../../shared/models';

@Component({
  selector: 'app-profile',
  template: `
<div class="profile-page">
  <div class="profile-card">
    <h1><mat-icon>account_circle</mat-icon> My Profile</h1>

    <!-- Avatar -->
    <div class="avatar-section">
      <app-user-avatar [user]="user" [size]="96"></app-user-avatar>
      <div class="avatar-actions">
        <button mat-stroked-button (click)="avatarInput.click()">
          <mat-icon>photo_camera</mat-icon> Change Photo
        </button>
        <input #avatarInput type="file" hidden accept="image/*" (change)="onAvatarChange($event)" />
        <span class="upload-hint">JPG, PNG, GIF — max 5MB</span>
      </div>
    </div>

    <mat-divider></mat-divider>

    <!-- Profile form -->
    <form [formGroup]="form" (ngSubmit)="save()" class="profile-form">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Display Name</mat-label>
        <mat-icon matPrefix>badge</mat-icon>
        <input matInput formControlName="displayName" />
        <mat-error *ngIf="form.get('displayName')?.hasError('required')">Required</mat-error>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Bio</mat-label>
        <mat-icon matPrefix>info</mat-icon>
        <textarea matInput formControlName="bio" rows="3" placeholder="Tell people about yourself…"></textarea>
        <mat-hint align="end">{{ form.get('bio')?.value?.length || 0 }}/500</mat-hint>
      </mat-form-field>

      <!-- Read-only fields -->
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Username</mat-label>
        <mat-icon matPrefix>alternate_email</mat-icon>
        <input matInput [value]="user?.username" readonly />
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Email</mat-label>
        <mat-icon matPrefix>email</mat-icon>
        <input matInput [value]="user?.email" readonly />
      </mat-form-field>

      <div class="profile-meta">
        <mat-chip [color]="user?.role === 'ADMIN' ? 'accent' : 'primary'" selected>
          {{ user?.role }}
        </mat-chip>
        <mat-chip [color]="user?.active ? 'primary' : 'warn'" selected>
          {{ user?.active ? 'Active' : 'Inactive' }}
        </mat-chip>
        <mat-chip>
          <mat-icon inline>calendar_today</mat-icon>
          Joined {{ user?.createdAt | date:'mediumDate' }}
        </mat-chip>
      </div>

      <button mat-raised-button color="primary" type="submit" [disabled]="loading || form.invalid">
        <mat-spinner *ngIf="loading" diameter="18" class="inline-spinner"></mat-spinner>
        <mat-icon *ngIf="!loading">save</mat-icon>
        {{ loading ? 'Saving…' : 'Save Changes' }}
      </button>
    </form>
  </div>
</div>`,
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  form: FormGroup;
  user: User | null = null;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private userApi: UserApiService,
    private auth: AuthService,
    private snackBar: MatSnackBar,
  ) {
    this.form = this.fb.group({
      displayName: ['', [Validators.required, Validators.maxLength(100)]],
      bio: ['', Validators.maxLength(500)],
    });
  }

  ngOnInit(): void {
    this.user = this.auth.currentUser;
    if (this.user) {
      this.form.patchValue({ displayName: this.user.displayName, bio: this.user.bio ?? '' });
    }
  }

  save(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.userApi.updateProfile(this.form.value).subscribe({
      next: res => {
        if (res.success && res.data) {
          this.user = res.data;
          this.auth.updateCurrentUser(res.data);
          this.snackBar.open('Profile updated!', 'Ok', { duration: 2000 });
        }
        this.loading = false;
      },
      error: () => (this.loading = false),
    });
  }

  onAvatarChange(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.loading = true;
    this.userApi.uploadAvatar(file).subscribe({
      next: res => {
        if (res.success && res.data) {
          this.user = res.data;
          this.auth.updateCurrentUser(res.data);
          this.snackBar.open('Avatar updated!', 'Ok', { duration: 2000 });
        }
        this.loading = false;
      },
      error: () => (this.loading = false),
    });
  }
}
