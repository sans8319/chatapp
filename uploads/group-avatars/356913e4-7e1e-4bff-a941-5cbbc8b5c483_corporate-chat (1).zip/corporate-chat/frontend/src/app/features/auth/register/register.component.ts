import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  template: `
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="auth-header">
      <mat-icon class="auth-logo">chat</mat-icon>
      <h1>Create Account</h1>
      <p class="subtitle">Join Corporate Chat</p>
    </div>
    <form [formGroup]="form" (ngSubmit)="submit()" class="auth-form">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Display Name</mat-label>
        <mat-icon matPrefix>badge</mat-icon>
        <input matInput formControlName="displayName" />
        <mat-error *ngIf="form.get('displayName')?.hasError('required')">Required</mat-error>
      </mat-form-field>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Username</mat-label>
        <mat-icon matPrefix>alternate_email</mat-icon>
        <input matInput formControlName="username" />
        <mat-error *ngIf="form.get('username')?.hasError('required')">Required</mat-error>
        <mat-error *ngIf="form.get('username')?.hasError('minlength')">Min 3 characters</mat-error>
      </mat-form-field>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Email</mat-label>
        <mat-icon matPrefix>email</mat-icon>
        <input matInput formControlName="email" type="email" />
        <mat-error *ngIf="form.get('email')?.hasError('email')">Invalid email</mat-error>
      </mat-form-field>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Password</mat-label>
        <mat-icon matPrefix>lock</mat-icon>
        <input matInput formControlName="password" [type]="hidePassword ? 'password' : 'text'" />
        <button mat-icon-button matSuffix type="button" (click)="hidePassword=!hidePassword">
          <mat-icon>{{ hidePassword ? 'visibility_off' : 'visibility' }}</mat-icon>
        </button>
        <mat-error *ngIf="form.get('password')?.hasError('minlength')">Min 8 characters</mat-error>
      </mat-form-field>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Role</mat-label>
        <mat-select formControlName="role">
          <mat-option value="EMPLOYEE">Employee</mat-option>
          <mat-option value="ADMIN">Admin</mat-option>
        </mat-select>
      </mat-form-field>
      <div *ngIf="error" class="error-msg"><mat-icon>error_outline</mat-icon> {{ error }}</div>
      <button mat-raised-button color="primary" type="submit" class="full-width submit-btn" [disabled]="loading">
        <mat-spinner *ngIf="loading" diameter="20" class="inline-spinner"></mat-spinner>
        <span *ngIf="!loading">Create Account</span>
      </button>
    </form>
    <div class="auth-footer">
      <span>Already have an account?</span>
      <a routerLink="/login">Sign in</a>
    </div>
  </div>
</div>`,
})
export class RegisterComponent {
  form: FormGroup;
  loading = false;
  error = '';
  hidePassword = true;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      displayName: ['', [Validators.required]],
      username: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      role: ['EMPLOYEE'],
    });
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';
    this.auth.register(this.form.value).subscribe({
      next: () => this.router.navigate(['/']),
      error: err => {
        this.loading = false;
        this.error = err.error?.error || 'Registration failed';
      },
      complete: () => (this.loading = false),
    });
  }
}
