import { Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { AdminGuard } from './core/guards/admin.guard';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { MainLayoutComponent } from './features/chat/main-layout/main-layout.component';
import { ChatWindowComponent } from './features/chat/chat-window/chat-window.component';
import { AdminPanelComponent } from './features/admin/admin-panel.component';
import { ProfileComponent } from './features/profile/profile.component';

export const APP_ROUTES: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: '',
    component: MainLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'chat/:id', component: ChatWindowComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'admin', component: AdminPanelComponent, canActivate: [AdminGuard] },
      { path: '', redirectTo: 'chat', pathMatch: 'full' },
    ],
  },
  { path: '**', redirectTo: '' },
];
