// ============================================================
// CORPORATE CHAT - FRONTEND CONFIGURATION
// Change API_URL and WS_URL here to match your backend server
// ALL API calls and WebSocket connections use these values
// ============================================================

export const APP_CONFIG = {
  // Backend REST API base URL - change to your backend machine IP/domain
  API_URL: 'http://localhost:8080/api',

  // WebSocket endpoint - change to your backend machine IP/domain
  WS_URL: 'http://localhost:8080/ws',

  // File upload base URL (served by backend as static resources)
  FILE_BASE_URL: 'http://localhost:8080',

  // Pagination
  DEFAULT_PAGE_SIZE: 50,
  MESSAGES_PAGE_SIZE: 50,

  // WebSocket reconnect delay (ms)
  WS_RECONNECT_DELAY: 3000,
  WS_HEARTBEAT_INCOMING: 10000,
  WS_HEARTBEAT_OUTGOING: 10000,

  // Heartbeat interval (ms) - keep user online
  HEARTBEAT_INTERVAL: 30000,

  // Typing indicator timeout (ms)
  TYPING_TIMEOUT: 3000,

  // Max upload size (bytes) - 50MB
  MAX_UPLOAD_SIZE: 52428800,

  // Allowed file types
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  ALLOWED_VIDEO_TYPES: ['video/mp4', 'video/webm', 'video/ogg'],
  ALLOWED_DOCUMENT_TYPES: [
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain', 'text/csv', 'application/zip'
  ],

  // App metadata
  APP_NAME: 'Corporate Chat',
  VERSION: '1.0.0',
};
