# 🏢 Corporate Chat — Production-Ready Full-Stack Application

A complete enterprise-grade corporate chat application built with **Spring Boot** (backend) and **Angular** (frontend), featuring real-time messaging via WebSocket + RabbitMQ, Redis caching, JWT auth, file uploads, admin panel, and much more.

---

## 🗂 Project Structure

```
corporate-chat/
├── backend/          # Spring Boot 3 application
│   ├── src/
│   ├── pom.xml
│   └── .env.example
└── frontend/         # Angular 17 application
    ├── src/
    ├── angular.json
    └── package.json
```

---

## ⚙️ Prerequisites

| Tool | Version |
|------|---------|
| Java | 17+ |
| Maven | 3.9+ |
| Node.js | 18+ |
| npm | 9+ |
| PostgreSQL | 14+ |
| Redis | 7+ |
| RabbitMQ | 3.12+ |

---

## 🚀 Quick Start

### 1. Clone / Extract the project

```bash
# Extract the archive
unzip corporate-chat.zip
cd corporate-chat
```

### 2. Start Infrastructure Services

#### Using Docker Compose (recommended):
```bash
# Save this as docker-compose.infra.yml in the project root
cat > docker-compose.infra.yml << 'EOF'
version: '3.8'
services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: corporate_chat
      POSTGRES_USER: chat_user
      POSTGRES_PASSWORD: StrongPassword123!
    ports:
      - "5432:5432"
    volumes:
      - pg_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  rabbitmq:
    image: rabbitmq:3.12-management-alpine
    ports:
      - "5672:5672"
      - "15672:15672"
    environment:
      RABBITMQ_DEFAULT_USER: guest
      RABBITMQ_DEFAULT_PASS: guest

volumes:
  pg_data:
EOF

docker-compose -f docker-compose.infra.yml up -d
```

#### Or install manually (Ubuntu/Debian):
```bash
# PostgreSQL
sudo apt install postgresql-16
sudo -u postgres createuser chat_user
sudo -u postgres createdb corporate_chat -O chat_user
sudo -u postgres psql -c "ALTER USER chat_user PASSWORD 'StrongPassword123!';"

# Redis
sudo apt install redis-server
sudo systemctl start redis

# RabbitMQ
sudo apt install rabbitmq-server
sudo systemctl start rabbitmq-server
```

---

### 3. Configure Backend

```bash
cd backend

# Copy environment file
cp .env.example .env

# Edit .env with your actual values
nano .env
```

**Key values to set in `.env`:**
```env
BASE_URL=http://YOUR_BACKEND_IP:8080        # ← change to your server IP
DB_HOST=localhost
DB_NAME=corporate_chat
DB_USERNAME=chat_user
DB_PASSWORD=StrongPassword123!
JWT_SECRET=YourVeryLongSecretKeyAtLeast256BitsLongHere
REDIS_HOST=localhost
RABBITMQ_HOST=localhost
CORS_ALLOWED_ORIGINS=http://YOUR_FRONTEND_IP:4200
UPLOAD_PATH=/var/chat-uploads
```

**Create upload directories:**
```bash
sudo mkdir -p /var/chat-uploads/{images,videos,documents}
sudo chown -R $USER:$USER /var/chat-uploads
```

### 4. Build & Run Backend

```bash
cd backend

# Build (downloads all Maven dependencies)
mvn clean install -DskipTests

# Run
mvn spring-boot:run

# OR run the JAR directly
java -jar target/chat-1.0.0.jar
```

The backend starts on **http://localhost:8080**

Database tables are auto-created on first run via Hibernate DDL.

---

### 5. Configure Frontend

```bash
cd frontend
```

Edit `src/app/config/app.config.ts`:
```typescript
export const APP_CONFIG = {
  API_URL: 'http://YOUR_BACKEND_IP:8080/api',   // ← change to backend IP
  WS_URL:  'http://YOUR_BACKEND_IP:8080/ws',    // ← change to backend IP
  FILE_BASE_URL: 'http://YOUR_BACKEND_IP:8080', // ← change to backend IP
  // ...rest stays the same
};
```

> **Note:** This is the **only file** you need to change. No other file contains hardcoded URLs.

### 6. Install & Run Frontend

```bash
cd frontend

# Install all npm packages
npm install

# Start dev server (accessible from any machine on the network)
ng serve --host 0.0.0.0 --port 4200

# OR using npm script
npm start
```

The frontend starts on **http://localhost:4200**

---

## 🔑 First Login / Admin Setup

1. Open `http://localhost:4200`
2. Click **Create Account**
3. Fill in details and select **Role: Admin** for the first account
4. Login and access the **Admin Panel** from the sidebar

> Subsequent users registering as Admin will also get admin rights. In production, restrict this by removing the role selection from the register form or adding an invite code.

---

## 🌐 Multi-Machine Setup

If running backend and frontend on **different machines**:

| Machine | Service | Config |
|---------|---------|--------|
| Server A (192.168.1.100) | Spring Boot | `BASE_URL=http://192.168.1.100:8080`, `CORS_ALLOWED_ORIGINS=http://192.168.1.101:4200` |
| Server B (192.168.1.101) | Angular | `API_URL=http://192.168.1.100:8080/api`, `WS_URL=http://192.168.1.100:8080/ws` |

**Firewall rules needed:**
```bash
# On backend machine — open port 8080
sudo ufw allow 8080/tcp

# On frontend machine — open port 4200
sudo ufw allow 4200/tcp
```

---

## 📋 Feature Checklist

### Authentication
- [x] Register (Admin / Employee roles)
- [x] Login / Logout
- [x] JWT access tokens (15 min expiry)
- [x] Refresh token rotation (7 days)
- [x] BCrypt password hashing (strength 12)
- [x] Session / device management

### Admin Panel
- [x] View all users with pagination
- [x] Search users by name/email/username
- [x] Deactivate users (history preserved, name greyed out)
- [x] Reactivate users
- [x] Inactive users appear grey in chat; active users appear blue

### Chat System
- [x] 1-to-1 direct chat
- [x] Group chat with name/description
- [x] Add/remove members (admin/owner only)
- [x] Rename / update group chat
- [x] Chat list with last message preview and timestamp
- [x] Delete chat from my side (soft delete, not global)
- [x] Mute/unmute chat

### Messages
- [x] Text messages
- [x] Image uploads (JPEG, PNG, GIF, WebP)
- [x] Video uploads (MP4, WebM)
- [x] Document uploads (PDF, Word, Excel, PowerPoint, ZIP, TXT)
- [x] Emoji reactions (toggle on/off)
- [x] Mention users (@username)
- [x] Edit message (with full edit history)
- [x] Delete for me / delete for everyone
- [x] Forward messages
- [x] Reply to specific message (threading)
- [x] Pin / unpin messages
- [x] Star / bookmark messages
- [x] Link preview (title, description, image, site name)
- [x] Typing indicator (real-time)
- [x] Message timestamps

### Delivery
- [x] Sent / Delivered / Seen per user
- [x] Unread message count per chat (Redis-cached)
- [x] Mark messages as seen on chat open
- [x] Infinite scroll for message history
- [x] Pagination (page-based)

### Real-Time
- [x] WebSocket STOMP over SockJS
- [x] RabbitMQ message queue (async, non-blocking)
- [x] Optimistic UI updates (message appears instantly)
- [x] Auto-reconnect on disconnect
- [x] Heartbeat / presence keepalive
- [x] Online / offline indicators

### Notifications
- [x] Real-time in-app notifications via WebSocket
- [x] Mention alerts with badge count
- [x] New message notifications

### File Storage
- [x] Local filesystem storage (`/uploads/images`, `/uploads/videos`, `/uploads/documents`)
- [x] File type validation (MIME detection via Apache Tika)
- [x] File size limit (configurable, default 50MB)
- [x] Static file serving via Spring Boot
- [x] Files served via `BASE_URL/uploads/...`

### Search
- [x] Search messages within chat
- [x] Search users (active/all)
- [x] Cross-chat message search via global search component

### Performance
- [x] Redis: online presence, unread counts, typing state
- [x] RabbitMQ: async message broadcast
- [x] HikariCP connection pool
- [x] Hibernate lazy loading
- [x] Message sequence number for order guarantee
- [x] Client-side deduplication by `clientTempId`
- [x] Messages sorted by `createdAt ASC` on frontend

---

## 🔌 API Endpoints Reference

### Auth
```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/refresh
POST /api/auth/logout
```

### Users
```
GET  /api/users/me
PUT  /api/users/me
POST /api/users/me/avatar
GET  /api/users/{id}
GET  /api/users?search
GET  /api/users/online
POST /api/users/heartbeat
```

### Chats
```
POST   /api/chats
GET    /api/chats
GET    /api/chats/{id}
PUT    /api/chats/{id}
DELETE /api/chats/{id}
POST   /api/chats/{id}/members
DELETE /api/chats/{id}/members/{memberId}
POST   /api/chats/{id}/leave
POST   /api/chats/{id}/mute?mute=true
```

### Messages
```
POST   /api/messages
POST   /api/messages/upload          (multipart file)
GET    /api/messages/chat/{chatId}
PUT    /api/messages/{id}
DELETE /api/messages/{id}?forEveryone=true
POST   /api/messages/{id}/reactions
POST   /api/messages/chat/{chatId}/pin/{msgId}?pin=true
GET    /api/messages/chat/{chatId}/pinned
POST   /api/messages/{id}/star?star=true
GET    /api/messages/starred
POST   /api/messages/chat/{chatId}/seen
GET    /api/messages/chat/{chatId}/search?q=
GET    /api/messages/{id}/history
```

### Admin
```
GET    /api/admin/users
GET    /api/admin/users/search?q=
DELETE /api/admin/users/{id}         (deactivate)
POST   /api/admin/users/{id}/reactivate
```

### Notifications
```
GET  /api/notifications
GET  /api/notifications/unread-count
POST /api/notifications/read-all
POST /api/notifications/{id}/read
```

### WebSocket Topics
```
SUBSCRIBE /topic/chat.{chatId}.messages        → new messages
SUBSCRIBE /topic/chat.{chatId}.messages.edit   → edited messages
SUBSCRIBE /topic/chat.{chatId}.messages.delete → deleted messages
SUBSCRIBE /topic/chat.{chatId}.reactions       → reaction updates
SUBSCRIBE /topic/chat.{chatId}.pins            → pin/unpin events
SUBSCRIBE /topic/chat.{chatId}.seen            → read receipts
SUBSCRIBE /topic/chat.{chatId}.typing          → typing events
SUBSCRIBE /topic/presence                      → online/offline events
SUBSCRIBE /user/queue/notifications            → personal notifications
SUBSCRIBE /user/queue/chats.new                → new chat invitations

SEND /app/typing           → { chatId, typing }
SEND /app/presence.heartbeat
```

---

## 🗄 Database Schema

Tables auto-created by Hibernate on startup:

| Table | Description |
|-------|-------------|
| `users` | User accounts with roles, presence, avatar |
| `chats` | Chat rooms (DIRECT / GROUP) |
| `chat_members` | User membership in chats with roles |
| `messages` | All messages with threading, sequence numbers |
| `message_status` | Per-user delivery tracking (SENT/DELIVERED/SEEN) |
| `message_edit_history` | Full edit audit trail |
| `attachments` | File metadata linked to messages |
| `reactions` | Emoji reactions per user per message |
| `pinned_messages` | Pinned messages per chat |
| `starred_messages` | Starred/bookmarked messages per user |
| `notifications` | In-app notification log |
| `refresh_tokens` | JWT refresh token store with revocation |

---

## 🔧 Configuration Reference

### Backend `.env` (all keys)

```env
# App
BASE_URL=http://192.168.1.100:8080
SERVER_PORT=8080

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=corporate_chat
DB_USERNAME=chat_user
DB_PASSWORD=StrongPassword123!

# JWT
JWT_SECRET=<256-bit random string>
JWT_ACCESS_EXPIRATION_MS=900000      # 15 minutes
JWT_REFRESH_EXPIRATION_MS=604800000  # 7 days

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# RabbitMQ
RABBITMQ_HOST=localhost
RABBITMQ_PORT=5672
RABBITMQ_USERNAME=guest
RABBITMQ_PASSWORD=guest

# Files
UPLOAD_PATH=/var/chat-uploads
UPLOAD_MAX_FILE_SIZE=52428800         # 50MB

# CORS
CORS_ALLOWED_ORIGINS=http://localhost:4200
```

### Frontend `src/app/config/app.config.ts` (all keys)

```typescript
export const APP_CONFIG = {
  API_URL: 'http://localhost:8080/api',
  WS_URL: 'http://localhost:8080/ws',
  FILE_BASE_URL: 'http://localhost:8080',
  DEFAULT_PAGE_SIZE: 50,
  MESSAGES_PAGE_SIZE: 50,
  WS_RECONNECT_DELAY: 3000,
  HEARTBEAT_INTERVAL: 30000,
  TYPING_TIMEOUT: 3000,
  MAX_UPLOAD_SIZE: 52428800,
};
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| `Cannot connect to DB` | Check PostgreSQL is running; verify `DB_*` env vars |
| `Redis connection refused` | Start Redis: `sudo systemctl start redis` |
| `RabbitMQ refused` | Start RabbitMQ: `sudo systemctl start rabbitmq-server` |
| `CORS error in browser` | Add frontend URL to `CORS_ALLOWED_ORIGINS` in `.env` |
| `WebSocket not connecting` | Check `WS_URL` in `app.config.ts` matches backend IP |
| `File upload fails` | Check `UPLOAD_PATH` directory exists and is writable |
| `JWT errors` | Ensure `JWT_SECRET` is at least 256 bits (32+ characters) |
| `Messages not appearing` | Check RabbitMQ queues in management UI at `:15672` |
| `Build error: Hikari` | Hikari is included via `spring-boot-starter-data-jpa` |

---

## 📦 Production Build

### Backend
```bash
cd backend
mvn clean package -Pprod
java -Xms512m -Xmx2g -jar target/chat-1.0.0.jar
```

### Frontend
```bash
cd frontend
ng build --configuration production
# Serve dist/ with Nginx or any static file server
```

#### Nginx config example:
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/corporate-chat/dist/corporate-chat-frontend/browser;
    index index.html;
    location / { try_files $uri $uri/ /index.html; }
    location /api { proxy_pass http://localhost:8080; }
    location /ws {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    location /uploads { proxy_pass http://localhost:8080; }
}
```

---

## 🏗 Architecture

```
Browser (Angular)
    │
    ├── REST (HTTP/HTTPS) ──────────────────► Spring Boot Controllers
    │                                              │
    └── WebSocket (STOMP/SockJS) ─────────────►   │
                                                   │
                                         ┌─────────┴──────────┐
                                         │   Service Layer      │
                                         └─────────┬──────────┘
                                                   │
                        ┌──────────────────────────┼──────────────────────┐
                        │                          │                      │
                   PostgreSQL               Redis Cache              RabbitMQ
                  (persistence)         (presence/unread)          (async queue)
                                                                       │
                                                                  MessageConsumer
                                                                       │
                                                               WebSocket Broadcast
                                                              (to all chat members)
```

**Message Flow:**
1. Client sends REST POST `/api/messages`
2. Service saves to PostgreSQL (with sequence number)
3. Service publishes to RabbitMQ **asynchronously**
4. RabbitMQ consumer receives and broadcasts via WebSocket `/topic/chat.{id}.messages`
5. All connected clients in that chat receive the message instantly
6. Offline users load messages on next `openChat()` call

---

*Corporate Chat v1.0.0 — Built with Spring Boot 3.2 + Angular 17*
