package com.corporate.chat.controller;

import com.corporate.chat.dto.request.AddMembersRequest;
import com.corporate.chat.dto.request.CreateChatRequest;
import com.corporate.chat.dto.request.UpdateChatRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.service.ChatService;
import com.corporate.chat.util.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/chats")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @PostMapping
    public ResponseEntity<ApiResponse<ChatResponse>> createChat(
            @Valid @RequestBody CreateChatRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(chatService.createChat(userId, request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ChatResponse>>> getMyChats() {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(chatService.getUserChats(userId)));
    }

    @GetMapping("/{chatId}")
    public ResponseEntity<ApiResponse<ChatResponse>> getChat(@PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(chatService.getChatById(chatId, userId)));
    }

    @PutMapping("/{chatId}")
    public ResponseEntity<ApiResponse<ChatResponse>> updateChat(
            @PathVariable String chatId,
            @Valid @RequestBody UpdateChatRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(chatService.updateChat(chatId, userId, request)));
    }

    @DeleteMapping("/{chatId}")
    public ResponseEntity<ApiResponse<Void>> deleteForMe(@PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        chatService.deleteForUser(chatId, userId);
        return ResponseEntity.ok(ApiResponse.success("Chat removed from your view", null));
    }

    @GetMapping("/{chatId}/members")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getMembers(@PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(chatService.getChatMembers(chatId, userId)));
    }

    @PostMapping("/{chatId}/members")
    public ResponseEntity<ApiResponse<Void>> addMembers(
            @PathVariable String chatId,
            @Valid @RequestBody AddMembersRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        chatService.addMembers(chatId, userId, request);
        return ResponseEntity.ok(ApiResponse.success("Members added", null));
    }

    @DeleteMapping("/{chatId}/members/{memberId}")
    public ResponseEntity<ApiResponse<Void>> removeMember(
            @PathVariable String chatId,
            @PathVariable String memberId) {
        String userId = SecurityUtils.getCurrentUserId();
        chatService.removeMember(chatId, userId, memberId);
        return ResponseEntity.ok(ApiResponse.success("Member removed", null));
    }

    @PostMapping("/{chatId}/leave")
    public ResponseEntity<ApiResponse<Void>> leaveChat(@PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        chatService.removeMember(chatId, userId, userId);
        return ResponseEntity.ok(ApiResponse.success("Left chat", null));
    }

    @PostMapping("/{chatId}/mute")
    public ResponseEntity<ApiResponse<Void>> muteChat(
            @PathVariable String chatId,
            @RequestParam boolean mute) {
        String userId = SecurityUtils.getCurrentUserId();
        chatService.toggleMute(chatId, userId, mute);
        return ResponseEntity.ok(ApiResponse.success(mute ? "Chat muted" : "Chat unmuted", null));
    }

    @PostMapping(value = "/{chatId}/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<ChatResponse>> updateChatAvatar(
            @PathVariable String chatId,
            @RequestPart("file") MultipartFile file) {
        // Implementation delegated to service
        return ResponseEntity.ok(ApiResponse.success("Avatar updated", null));
    }
}
