package com.corporate.chat.dto.response;
import lombok.*;
import java.time.Instant;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class MessageStatusResponse {
    private String userId;
    private String status;
    private Instant deliveredAt;
    private Instant seenAt;
}
