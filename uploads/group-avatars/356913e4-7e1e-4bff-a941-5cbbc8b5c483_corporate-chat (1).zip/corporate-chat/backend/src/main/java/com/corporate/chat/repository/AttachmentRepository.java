package com.corporate.chat.repository;

import com.corporate.chat.model.Attachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttachmentRepository extends JpaRepository<Attachment, String> {

    List<Attachment> findByMessageId(String messageId);

    @Query("SELECT a FROM Attachment a WHERE a.message.chat.id = :chatId " +
           "AND a.attachmentType = :type ORDER BY a.createdAt DESC")
    List<Attachment> findByChatIdAndType(@Param("chatId") String chatId,
                                          @Param("type") Attachment.AttachmentType type);
}
