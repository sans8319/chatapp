package com.corporate.chat.service;

import com.corporate.chat.dto.response.NotificationResponse;
import com.corporate.chat.dto.response.PageResponse;
import com.corporate.chat.model.Message;
import com.corporate.chat.model.Notification;
import com.corporate.chat.model.User;
import com.corporate.chat.repository.NotificationRepository;
import com.corporate.chat.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;

    @Async("taskExecutor")
    @Transactional
    public void createNewMessageNotification(User sender, Message message, List<String> recipientIds) {
        String preview = message.getContent() != null
            ? (message.getContent().length() > 60
                ? message.getContent().substring(0, 60) + "..."
                : message.getContent())
            : "[File]";

        for (String recipientId : recipientIds) {
            if (recipientId.equals(sender.getId())) continue;
            try {
                Notification notification = Notification.builder()
                    .recipientId(recipientId)
                    .senderId(sender.getId())
                    .type(Notification.NotificationType.NEW_MESSAGE)
                    .title(sender.getDisplayName() != null ? sender.getDisplayName() : sender.getUsername())
                    .body(preview)
                    .chatId(message.getChat().getId())
                    .messageId(message.getId())
                    .build();
                notification = notificationRepository.save(notification);
                pushNotification(recipientId, toResponse(notification, sender));
            } catch (Exception e) {
                log.warn("Failed to create notification for {}", recipientId);
            }
        }
    }

    @Async("taskExecutor")
    @Transactional
    public void createMentionNotification(String senderId, String mentionedUserId, Message message) {
        try {
            User sender = userRepository.findById(senderId).orElse(null);
            if (sender == null) return;

            Notification notification = Notification.builder()
                .recipientId(mentionedUserId)
                .senderId(senderId)
                .type(Notification.NotificationType.MENTION)
                .title("You were mentioned by " + (sender.getDisplayName() != null
                    ? sender.getDisplayName() : sender.getUsername()))
                .body(message.getContent() != null ? message.getContent().substring(0,
                    Math.min(100, message.getContent().length())) : "")
                .chatId(message.getChat().getId())
                .messageId(message.getId())
                .build();
            notification = notificationRepository.save(notification);
            pushNotification(mentionedUserId, toResponse(notification, sender));
        } catch (Exception e) {
            log.warn("Failed to create mention notification", e);
        }
    }

    public PageResponse<NotificationResponse> getNotifications(String userId, int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size,
            Sort.by("createdAt").descending());
        Page<Notification> notifications = notificationRepository
            .findByRecipientIdOrderByCreatedAtDesc(userId, pageRequest);
        List<NotificationResponse> content = notifications.getContent().stream()
            .map(n -> toResponseWithSender(n)).collect(Collectors.toList());
        return PageResponse.<NotificationResponse>builder()
            .content(content).page(page).size(size)
            .totalElements(notifications.getTotalElements())
            .totalPages(notifications.getTotalPages())
            .hasNext(notifications.hasNext()).hasPrevious(notifications.hasPrevious())
            .build();
    }

    public long getUnreadCount(String userId) {
        return notificationRepository.countByRecipientIdAndReadFalse(userId);
    }

    @Transactional
    public void markAllAsRead(String userId) {
        notificationRepository.markAllAsRead(userId, Instant.now());
    }

    @Transactional
    public void markAsRead(String notificationId) {
        notificationRepository.markAsRead(notificationId, Instant.now());
    }

    private void pushNotification(String userId, NotificationResponse response) {
        try {
            messagingTemplate.convertAndSendToUser(userId, "/queue/notifications", response);
        } catch (Exception e) {
            log.warn("Failed to push notification to user {}", userId);
        }
    }

    private NotificationResponse toResponse(Notification n, User sender) {
        return NotificationResponse.builder()
            .id(n.getId()).type(n.getType().name())
            .title(n.getTitle()).body(n.getBody())
            .chatId(n.getChatId()).messageId(n.getMessageId())
            .senderId(n.getSenderId())
            .senderName(sender != null ? (sender.getDisplayName() != null
                ? sender.getDisplayName() : sender.getUsername()) : null)
            .senderAvatar(sender != null ? sender.getAvatarUrl() : null)
            .read(n.isRead()).createdAt(n.getCreatedAt())
            .build();
    }

    private NotificationResponse toResponseWithSender(Notification n) {
        User sender = n.getSenderId() != null
            ? userRepository.findById(n.getSenderId()).orElse(null) : null;
        return toResponse(n, sender);
    }
}
