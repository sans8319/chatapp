package com.corporate.chat.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    // ---- Exchange Names ----
    public static final String CHAT_EXCHANGE = "chat.exchange";
    public static final String NOTIFICATION_EXCHANGE = "notification.exchange";
    public static final String PRESENCE_EXCHANGE = "presence.exchange";

    // ---- Queue Names ----
    public static final String MESSAGE_QUEUE = "chat.messages";
    public static final String NOTIFICATION_QUEUE = "chat.notifications";
    public static final String PRESENCE_QUEUE = "chat.presence";
    public static final String MESSAGE_DELIVERY_QUEUE = "chat.message.delivery";

    // ---- Routing Keys ----
    public static final String MESSAGE_ROUTING_KEY = "chat.message.send";
    public static final String NOTIFICATION_ROUTING_KEY = "chat.notification";
    public static final String PRESENCE_ROUTING_KEY = "chat.presence.update";
    public static final String DELIVERY_ROUTING_KEY = "chat.message.delivery";

    // ---- Exchanges ----
    @Bean
    public DirectExchange chatExchange() {
        return ExchangeBuilder.directExchange(CHAT_EXCHANGE).durable(true).build();
    }

    @Bean
    public DirectExchange notificationExchange() {
        return ExchangeBuilder.directExchange(NOTIFICATION_EXCHANGE).durable(true).build();
    }

    @Bean
    public FanoutExchange presenceExchange() {
        return ExchangeBuilder.fanoutExchange(PRESENCE_EXCHANGE).durable(true).build();
    }

    // ---- Queues ----
    @Bean
    public Queue messageQueue() {
        return QueueBuilder.durable(MESSAGE_QUEUE)
                .withArgument("x-message-ttl", 86400000) // 24 hours TTL
                .withArgument("x-max-length", 100000)
                .build();
    }

    @Bean
    public Queue notificationQueue() {
        return QueueBuilder.durable(NOTIFICATION_QUEUE).build();
    }

    @Bean
    public Queue presenceQueue() {
        return QueueBuilder.durable(PRESENCE_QUEUE).build();
    }

    @Bean
    public Queue messageDeliveryQueue() {
        return QueueBuilder.durable(MESSAGE_DELIVERY_QUEUE).build();
    }

    // ---- Bindings ----
    @Bean
    public Binding messageBinding() {
        return BindingBuilder.bind(messageQueue()).to(chatExchange()).with(MESSAGE_ROUTING_KEY);
    }

    @Bean
    public Binding notificationBinding() {
        return BindingBuilder.bind(notificationQueue()).to(notificationExchange()).with(NOTIFICATION_ROUTING_KEY);
    }

    @Bean
    public Binding presenceBinding() {
        return BindingBuilder.bind(presenceQueue()).to(presenceExchange());
    }

    @Bean
    public Binding deliveryBinding() {
        return BindingBuilder.bind(messageDeliveryQueue()).to(chatExchange()).with(DELIVERY_ROUTING_KEY);
    }

    // ---- Message Converter ----
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter());
        template.setMandatory(true);
        return template;
    }

    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(jsonMessageConverter());
        factory.setConcurrentConsumers(3);
        factory.setMaxConcurrentConsumers(10);
        factory.setAcknowledgeMode(AcknowledgeMode.AUTO);
        factory.setPrefetchCount(10);
        return factory;
    }
}
