package com.corporate.chat.repository;

import com.corporate.chat.model.MessageEditHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageEditHistoryRepository extends JpaRepository<MessageEditHistory, String> {
    List<MessageEditHistory> findByMessageIdOrderByEditedAtDesc(String messageId);
}
