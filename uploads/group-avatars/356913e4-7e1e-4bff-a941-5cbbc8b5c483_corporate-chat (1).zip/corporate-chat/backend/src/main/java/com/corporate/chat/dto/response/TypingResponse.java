package com.corporate.chat.dto.response;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TypingResponse {
    private String chatId;
    private String userId;
    private String userName;
    private boolean typing;
}
