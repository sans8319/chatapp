package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "notifications", indexes = {
    @Index(name = "idx_notifications_user_id", columnList = "user_id"),
    @Index(name = "idx_notifications_read", columnList = "read_at"),
    @Index(name = "idx_notifications_created_at", columnList = "created_at")
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "user_id", nullable = false, length = 36)
    private String userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, length = 50)
    private NotificationType type;

    @Column(name = "title", length = 255)
    private String title;

    @Column(name = "body", length = 500)
    private String body;

    @Column(name = "chat_id", length = 36)
    private String chatId;

    @Column(name = "message_id", length = 36)
    private String messageId;

    @Column(name = "sender_id", length = 36)
    private String senderId;

    @Column(name = "read_at")
    private Instant readAt;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;

    public enum NotificationType {
        NEW_MESSAGE, MENTION, GROUP_ADDED, GROUP_REMOVED,
        REACTION, REPLY, SYSTEM
    }
}
