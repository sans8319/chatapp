package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "pinned_messages",
    uniqueConstraints = @UniqueConstraint(columnNames = {"chat_id", "message_id"}),
    indexes = {
        @Index(name = "idx_pinned_chat_id", columnList = "chat_id")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PinnedMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "chat_id", nullable = false, length = 36)
    private String chatId;

    @Column(name = "message_id", nullable = false, length = 36)
    private String messageId;

    @Column(name = "pinned_by", nullable = false, length = 36)
    private String pinnedBy;

    @CreationTimestamp
    @Column(name = "pinned_at", updatable = false)
    private Instant pinnedAt;
}
