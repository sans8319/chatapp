package com.corporate.chat.model;

public enum Role {
    ADMIN,
    EMPLOYEE
}
