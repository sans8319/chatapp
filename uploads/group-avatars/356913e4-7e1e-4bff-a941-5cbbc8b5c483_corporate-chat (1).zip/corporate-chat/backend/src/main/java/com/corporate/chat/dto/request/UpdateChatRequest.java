package com.corporate.chat.dto.request;

import lombok.Data;

@Data
public class UpdateChatRequest {
    private String name;
    private String description;
}
