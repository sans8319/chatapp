package com.corporate.chat.websocket;

import com.corporate.chat.service.PresenceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.security.Principal;

@Component
@RequiredArgsConstructor
@Slf4j
public class WebSocketEventListener {

    private final PresenceService presenceService;

    @EventListener
    public void handleWebSocketConnect(SessionConnectedEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String userId = extractUserId(accessor);
        if (userId != null) {
            presenceService.setOnline(userId);
            log.info("WebSocket connected: userId={}, sessionId={}", userId, accessor.getSessionId());
        }
    }

    @EventListener
    public void handleWebSocketDisconnect(SessionDisconnectEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String userId = extractUserId(accessor);
        if (userId != null) {
            presenceService.setOffline(userId);
            log.info("WebSocket disconnected: userId={}, sessionId={}", userId, accessor.getSessionId());
        }
    }

    private String extractUserId(SimpMessageHeaderAccessor accessor) {
        try {
            Principal principal = accessor.getUser();
            if (principal instanceof UsernamePasswordAuthenticationToken token) {
                if (token.getPrincipal() instanceof UserDetails userDetails) {
                    // We need the userId not username — handled in UserDetailsServiceImpl
                    // Store userId in session attributes
                    Object userId = accessor.getSessionAttributes() != null
                        ? accessor.getSessionAttributes().get("userId") : null;
                    if (userId != null) return userId.toString();
                    return userDetails.getUsername(); // fallback
                }
            }
        } catch (Exception e) {
            log.warn("Could not extract userId from WS session", e);
        }
        return null;
    }
}
