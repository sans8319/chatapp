package com.corporate.chat.service;

import com.corporate.chat.config.RedisConfig;
import com.corporate.chat.model.User;
import com.corporate.chat.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class PresenceService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final RedisTemplate<String, String> stringRedisTemplate;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public void setOnline(String userId) {
        try {
            redisTemplate.opsForSet().add(RedisConfig.ONLINE_USERS_KEY, userId);
            redisTemplate.expire(RedisConfig.ONLINE_USERS_KEY, 1, TimeUnit.DAYS);
            stringRedisTemplate.delete(RedisConfig.USER_LAST_SEEN_PREFIX + userId);
            updateUserPresenceInDb(userId, User.PresenceStatus.ONLINE);
            broadcastPresence(userId, "ONLINE");
        } catch (Exception e) {
            log.warn("Failed to set online status for {}: {}", userId, e.getMessage());
        }
    }

    public void setOffline(String userId) {
        try {
            redisTemplate.opsForSet().remove(RedisConfig.ONLINE_USERS_KEY, userId);
            String nowStr = String.valueOf(Instant.now().toEpochMilli());
            stringRedisTemplate.opsForValue().set(
                RedisConfig.USER_LAST_SEEN_PREFIX + userId,
                nowStr, 7, TimeUnit.DAYS);
            updateUserPresenceInDb(userId, User.PresenceStatus.OFFLINE);
            broadcastPresence(userId, "OFFLINE");
        } catch (Exception e) {
            log.warn("Failed to set offline status for {}: {}", userId, e.getMessage());
        }
    }

    public boolean isOnline(String userId) {
        try {
            Boolean member = redisTemplate.opsForSet().isMember(RedisConfig.ONLINE_USERS_KEY, userId);
            return Boolean.TRUE.equals(member);
        } catch (Exception e) {
            return false;
        }
    }

    public Set<String> getOnlineUserIds() {
        try {
            Set<Object> members = redisTemplate.opsForSet().members(RedisConfig.ONLINE_USERS_KEY);
            if (members == null) return Collections.emptySet();
            Set<String> result = new HashSet<>();
            members.forEach(m -> result.add(m.toString()));
            return result;
        } catch (Exception e) {
            return Collections.emptySet();
        }
    }

    public Instant getLastSeen(String userId) {
        try {
            String val = stringRedisTemplate.opsForValue().get(RedisConfig.USER_LAST_SEEN_PREFIX + userId);
            if (val != null) {
                return Instant.ofEpochMilli(Long.parseLong(val));
            }
        } catch (Exception e) {
            log.warn("Failed to get last seen for {}", userId);
        }
        return null;
    }

    public void setTyping(String chatId, String userId, String userName, boolean typing) {
        try {
            String key = RedisConfig.TYPING_USERS_PREFIX + chatId;
            if (typing) {
                stringRedisTemplate.opsForHash().put(key, userId, userName);
                stringRedisTemplate.expire(key, 10, TimeUnit.SECONDS);
            } else {
                stringRedisTemplate.opsForHash().delete(key, userId);
            }
        } catch (Exception e) {
            log.warn("Failed to update typing status", e);
        }
    }

    public Map<String, String> getTypingUsers(String chatId) {
        try {
            Map<Object, Object> entries = stringRedisTemplate.opsForHash()
                .entries(RedisConfig.TYPING_USERS_PREFIX + chatId);
            Map<String, String> result = new HashMap<>();
            entries.forEach((k, v) -> result.put(k.toString(), v.toString()));
            return result;
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }

    public void incrementUnreadCount(String chatId, String userId) {
        try {
            String key = RedisConfig.UNREAD_COUNT_PREFIX + chatId + ":" + userId;
            stringRedisTemplate.opsForValue().increment(key);
            stringRedisTemplate.expire(key, 30, TimeUnit.DAYS);
        } catch (Exception e) {
            log.warn("Failed to increment unread count", e);
        }
    }

    public void resetUnreadCount(String chatId, String userId) {
        try {
            String key = RedisConfig.UNREAD_COUNT_PREFIX + chatId + ":" + userId;
            stringRedisTemplate.delete(key);
        } catch (Exception e) {
            log.warn("Failed to reset unread count", e);
        }
    }

    public long getUnreadCount(String chatId, String userId) {
        try {
            String key = RedisConfig.UNREAD_COUNT_PREFIX + chatId + ":" + userId;
            String val = stringRedisTemplate.opsForValue().get(key);
            return val != null ? Long.parseLong(val) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private void broadcastPresence(String userId, String status) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("userId", userId);
            payload.put("status", status);
            payload.put("timestamp", Instant.now());
            messagingTemplate.convertAndSend("/topic/presence", payload);
        } catch (Exception e) {
            log.warn("Failed to broadcast presence", e);
        }
    }

    private void updateUserPresenceInDb(String userId, User.PresenceStatus status) {
        try {
            userRepository.updatePresence(userId, status, Instant.now());
        } catch (Exception e) {
            log.warn("Failed to update DB presence for {}", userId);
        }
    }

    // Clean up stale online entries every 5 minutes
    @Scheduled(fixedDelay = 300000)
    public void cleanupStalePresence() {
        try {
            Set<String> onlineIds = getOnlineUserIds();
            // Presence entries older than 5 minutes without heartbeat get cleaned
            // In production, use heartbeat mechanism
        } catch (Exception e) {
            log.warn("Presence cleanup failed", e);
        }
    }
}
