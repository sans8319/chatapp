package com.corporate.chat.util;

import com.corporate.chat.exception.AppException;
import com.corporate.chat.model.User;
import com.corporate.chat.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

public class SecurityUtils {

    private static UserRepository userRepository;

    // Called from a Spring component to inject the repo
    public static void setUserRepository(UserRepository repo) {
        userRepository = repo;
    }

    public static String getCurrentUsername() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) {
            throw new AppException("Not authenticated", HttpStatus.UNAUTHORIZED);
        }
        Object principal = auth.getPrincipal();
        if (principal instanceof UserDetails ud) {
            return ud.getUsername();
        }
        return principal.toString();
    }

    public static String getCurrentUserId() {
        String username = getCurrentUsername();
        if (userRepository == null) {
            throw new AppException("UserRepository not initialized in SecurityUtils", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        User user = userRepository.findByUsernameOrEmail(username, username)
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        return user.getId();
    }

    public static boolean isAdmin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null && auth.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
    }
}
