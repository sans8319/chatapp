package com.corporate.chat.repository;

import com.corporate.chat.model.PinnedMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PinnedMessageRepository extends JpaRepository<PinnedMessage, String> {

    List<PinnedMessage> findByChatIdOrderByPinnedAtDesc(String chatId);

    Optional<PinnedMessage> findByChatIdAndMessageId(String chatId, String messageId);

    void deleteByChatIdAndMessageId(String chatId, String messageId);

    boolean existsByChatIdAndMessageId(String chatId, String messageId);
}
