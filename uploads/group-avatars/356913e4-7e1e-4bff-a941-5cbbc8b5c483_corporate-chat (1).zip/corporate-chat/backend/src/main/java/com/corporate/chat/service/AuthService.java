package com.corporate.chat.service;

import com.corporate.chat.config.RedisConfig;
import com.corporate.chat.dto.request.LoginRequest;
import com.corporate.chat.dto.request.RegisterRequest;
import com.corporate.chat.dto.request.RefreshTokenRequest;
import com.corporate.chat.dto.response.AuthResponse;
import com.corporate.chat.dto.response.UserResponse;
import com.corporate.chat.exception.AppException;
import com.corporate.chat.model.RefreshToken;
import com.corporate.chat.model.Role;
import com.corporate.chat.model.User;
import com.corporate.chat.repository.RefreshTokenRepository;
import com.corporate.chat.repository.UserRepository;
import com.corporate.chat.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;
    private final RedisTemplate<String, String> stringRedisTemplate;
    private final PresenceService presenceService;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new AppException("Username already taken", HttpStatus.CONFLICT);
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AppException("Email already registered", HttpStatus.CONFLICT);
        }

        Role role = Role.EMPLOYEE;
        if ("ADMIN".equalsIgnoreCase(request.getRole())) {
            role = Role.ADMIN;
        }

        String displayName = request.getDisplayName() != null
            ? request.getDisplayName() : request.getUsername();

        User user = User.builder()
            .username(request.getUsername())
            .email(request.getEmail())
            .passwordHash(passwordEncoder.encode(request.getPassword()))
            .displayName(displayName)
            .role(role)
            .active(true)
            .presenceStatus(User.PresenceStatus.OFFLINE)
            .build();

        user = userRepository.save(user);
        log.info("New user registered: {}", user.getUsername());

        String accessToken = jwtTokenProvider.generateAccessToken(user.getUsername());
        String refreshToken = createRefreshToken(user.getId(), null);

        return buildAuthResponse(user, accessToken, refreshToken);
    }

    @Transactional
    public AuthResponse login(LoginRequest request, String ipAddress) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    request.getUsernameOrEmail(), request.getPassword()));

            String username = authentication.getName();
            User user = userRepository.findByUsernameOrEmail(username, username)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

            if (!user.isActive()) {
                throw new AppException("Account is deactivated", HttpStatus.FORBIDDEN);
            }

            // Revoke old refresh tokens for this user
            refreshTokenRepository.revokeAllByUserId(user.getId(), Instant.now());

            String accessToken = jwtTokenProvider.generateAccessToken(username);
            String refreshToken = createRefreshToken(user.getId(), ipAddress);

            // Mark user online
            presenceService.setOnline(user.getId());

            log.info("User logged in: {}", username);
            return buildAuthResponse(user, accessToken, refreshToken);

        } catch (BadCredentialsException e) {
            throw new AppException("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
    }

    @Transactional
    public AuthResponse refreshToken(RefreshTokenRequest request) {
        RefreshToken storedToken = refreshTokenRepository.findByToken(request.getRefreshToken())
            .orElseThrow(() -> new AppException("Refresh token not found", HttpStatus.UNAUTHORIZED));

        if (storedToken.isRevoked()) {
            throw new AppException("Refresh token has been revoked", HttpStatus.UNAUTHORIZED);
        }
        if (storedToken.getExpiresAt().isBefore(Instant.now())) {
            throw new AppException("Refresh token has expired", HttpStatus.UNAUTHORIZED);
        }

        User user = userRepository.findById(storedToken.getUserId())
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        if (!user.isActive()) {
            throw new AppException("Account is deactivated", HttpStatus.FORBIDDEN);
        }

        // Rotate refresh token
        refreshTokenRepository.revokeByToken(storedToken.getToken(), Instant.now());
        String newAccessToken = jwtTokenProvider.generateAccessToken(user.getUsername());
        String newRefreshToken = createRefreshToken(user.getId(), null);

        return buildAuthResponse(user, newAccessToken, newRefreshToken);
    }

    @Transactional
    public void logout(String userId) {
        refreshTokenRepository.revokeAllByUserId(userId, Instant.now());
        presenceService.setOffline(userId);
        // Invalidate access token in Redis blacklist
        stringRedisTemplate.opsForValue().set(
            RedisConfig.USER_SESSIONS_PREFIX + userId + ":logout",
            String.valueOf(System.currentTimeMillis()),
            7, TimeUnit.DAYS);
        log.info("User {} logged out", userId);
    }

    private String createRefreshToken(String userId, String ipAddress) {
        String tokenValue = jwtTokenProvider.generateRefreshToken(
            userId + ":" + System.currentTimeMillis());

        RefreshToken refreshToken = RefreshToken.builder()
            .userId(userId)
            .token(tokenValue)
            .expiresAt(Instant.now().plusMillis(jwtTokenProvider.getRefreshExpirationMs()))
            .ipAddress(ipAddress)
            .build();

        refreshTokenRepository.save(refreshToken);
        return tokenValue;
    }

    private AuthResponse buildAuthResponse(User user, String accessToken, String refreshToken) {
        UserResponse userResponse = UserResponse.builder()
            .id(user.getId())
            .username(user.getUsername())
            .email(user.getEmail())
            .displayName(user.getDisplayName())
            .avatarUrl(user.getAvatarUrl())
            .role(user.getRole().name())
            .active(user.isActive())
            .presenceStatus(user.getPresenceStatus().name())
            .createdAt(user.getCreatedAt())
            .build();

        return AuthResponse.builder()
            .accessToken(accessToken)
            .refreshToken(refreshToken)
            .tokenType("Bearer")
            .expiresIn(jwtTokenProvider.getAccessExpirationMs() / 1000)
            .user(userResponse)
            .build();
    }
}
