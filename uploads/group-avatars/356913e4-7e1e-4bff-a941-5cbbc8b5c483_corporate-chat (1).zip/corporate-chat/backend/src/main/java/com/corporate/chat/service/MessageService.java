package com.corporate.chat.service;

import com.corporate.chat.config.AppConfig;
import com.corporate.chat.dto.request.EditMessageRequest;
import com.corporate.chat.dto.request.ReactionRequest;
import com.corporate.chat.dto.request.SendMessageRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.exception.AppException;
import com.corporate.chat.messaging.MessagePublisher;
import com.corporate.chat.model.*;
import com.corporate.chat.repository.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class MessageService {

    private final MessageRepository messageRepository;
    private final MessageStatusRepository messageStatusRepository;
    private final MessageEditHistoryRepository editHistoryRepository;
    private final AttachmentRepository attachmentRepository;
    private final ReactionRepository reactionRepository;
    private final PinnedMessageRepository pinnedMessageRepository;
    private final StarredMessageRepository starredMessageRepository;
    private final ChatMemberRepository chatMemberRepository;
    private final ChatRepository chatRepository;
    private final UserRepository userRepository;
    private final FileStorageService fileStorageService;
    private final PresenceService presenceService;
    private final NotificationService notificationService;
    private final MessagePublisher messagePublisher;
    private final AppConfig appConfig;
    private final ObjectMapper objectMapper;

    @Transactional
    public MessageResponse sendMessage(String senderId, SendMessageRequest req) {
        validateMember(req.getChatId(), senderId);

        User sender = userRepository.findById(senderId)
            .orElseThrow(() -> new AppException("Sender not found", HttpStatus.NOT_FOUND));
        Chat chat = chatRepository.findById(req.getChatId())
            .orElseThrow(() -> new AppException("Chat not found", HttpStatus.NOT_FOUND));

        Message.MessageType msgType = req.getMessageType() != null
            ? Message.MessageType.valueOf(req.getMessageType().toUpperCase())
            : Message.MessageType.TEXT;

        // Sequence number for ordering guarantee
        long seqNum = generateSequenceNumber(req.getChatId());

        // Serialize mentions
        String mentionsJson = null;
        if (req.getMentions() != null && !req.getMentions().isEmpty()) {
            try { mentionsJson = objectMapper.writeValueAsString(req.getMentions()); }
            catch (Exception ignored) {}
        }

        Message message = Message.builder()
            .chat(chat)
            .sender(sender)
            .content(req.getContent())
            .messageType(msgType)
            .parentMessageId(req.getParentMessageId())
            .forwardedFromId(req.getForwardedFromId())
            .sequenceNumber(seqNum)
            .mentions(mentionsJson)
            .build();

        message = messageRepository.save(message);

        // Create SENT status for sender
        createMessageStatus(message, senderId, MessageStatus.DeliveryStatus.SENT);

        // Create SENT status for all other active members
        List<String> memberIds = chatMemberRepository.findActiveUserIdsByChatId(req.getChatId());
        for (String memberId : memberIds) {
            if (!memberId.equals(senderId)) {
                createMessageStatus(message, memberId, MessageStatus.DeliveryStatus.SENT);
                if (!presenceService.isOnline(memberId)) {
                    presenceService.incrementUnreadCount(req.getChatId(), memberId);
                }
            }
        }

        // Update chat last message
        chat.setLastMessageId(message.getId());
        chat.setLastMessageAt(message.getCreatedAt());
        chatRepository.save(chat);

        MessageResponse response = toMessageResponse(message, senderId);
        response.setClientTempId(req.getClientTempId());

        // Publish to RabbitMQ -> WebSocket broadcast (async, non-blocking)
        messagePublisher.publishMessage(response);

        // Handle mentions notifications
        if (req.getMentions() != null) {
            req.getMentions().forEach(mentionedId ->
                notificationService.createMentionNotification(senderId, mentionedId, message));
        }

        // Notifications for non-mentioned members
        notificationService.createNewMessageNotification(sender, message, memberIds);

        log.debug("Message {} sent in chat {} by {}", message.getId(), req.getChatId(), senderId);
        return response;
    }

    @Transactional
    public MessageResponse sendFileMessage(String senderId, String chatId, MultipartFile file) {
        validateMember(chatId, senderId);

        User sender = userRepository.findById(senderId)
            .orElseThrow(() -> new AppException("Sender not found", HttpStatus.NOT_FOUND));
        Chat chat = chatRepository.findById(chatId)
            .orElseThrow(() -> new AppException("Chat not found", HttpStatus.NOT_FOUND));

        String mimeType = fileStorageService.detectMimeType(file);
        String fileUrl = fileStorageService.storeFileByType(file);
        String attachmentTypeStr = fileStorageService.getAttachmentTypeFromMime(mimeType);
        Attachment.AttachmentType attType = Attachment.AttachmentType.valueOf(attachmentTypeStr);

        Message.MessageType msgType = switch (attType) {
            case IMAGE -> Message.MessageType.IMAGE;
            case VIDEO -> Message.MessageType.VIDEO;
            default -> Message.MessageType.DOCUMENT;
        };

        long seqNum = generateSequenceNumber(chatId);

        Message message = Message.builder()
            .chat(chat).sender(sender)
            .content(file.getOriginalFilename())
            .messageType(msgType)
            .sequenceNumber(seqNum)
            .build();
        message = messageRepository.save(message);

        Attachment attachment = Attachment.builder()
            .message(message)
            .uploadedBy(senderId)
            .fileName(fileUrl.substring(fileUrl.lastIndexOf('/') + 1))
            .originalName(Objects.requireNonNullElse(file.getOriginalFilename(), "file"))
            .fileUrl(fileUrl)
            .filePath(fileUrl)
            .mimeType(mimeType)
            .fileSize(file.getSize())
            .attachmentType(attType)
            .build();
        attachmentRepository.save(attachment);

        createMessageStatus(message, senderId, MessageStatus.DeliveryStatus.SENT);
        List<String> memberIds = chatMemberRepository.findActiveUserIdsByChatId(chatId);
        for (String memberId : memberIds) {
            if (!memberId.equals(senderId)) {
                createMessageStatus(message, memberId, MessageStatus.DeliveryStatus.SENT);
                if (!presenceService.isOnline(memberId)) {
                    presenceService.incrementUnreadCount(chatId, memberId);
                }
            }
        }

        chat.setLastMessageId(message.getId());
        chat.setLastMessageAt(message.getCreatedAt());
        chatRepository.save(chat);

        MessageResponse response = toMessageResponse(message, senderId);
        messagePublisher.publishMessage(response);
        return response;
    }

    @Transactional
    public MessageResponse editMessage(String messageId, String userId, EditMessageRequest req) {
        Message message = findMessageById(messageId);
        if (!message.getSender().getId().equals(userId)) {
            throw new AppException("Cannot edit other user's message", HttpStatus.FORBIDDEN);
        }
        if (message.isDeleted()) {
            throw new AppException("Cannot edit deleted message", HttpStatus.BAD_REQUEST);
        }

        // Save edit history
        MessageEditHistory history = MessageEditHistory.builder()
            .message(message).previousContent(message.getContent()).editedBy(userId).build();
        editHistoryRepository.save(history);

        message.setContent(req.getContent());
        message.setEdited(true);
        message.setEditedAt(Instant.now());
        message = messageRepository.save(message);

        MessageResponse response = toMessageResponse(message, userId);
        messagePublisher.publishMessageEdit(response);
        return response;
    }

    @Transactional
    public void deleteMessage(String messageId, String userId, boolean forEveryone) {
        Message message = findMessageById(messageId);
        validateMember(message.getChat().getId(), userId);

        if (forEveryone) {
            if (!message.getSender().getId().equals(userId)) {
                // Admins can delete for everyone too
                ChatMember member = chatMemberRepository
                    .findByChatIdAndUserId(message.getChat().getId(), userId)
                    .orElseThrow(() -> new AppException("Not a member", HttpStatus.FORBIDDEN));
                if (member.getMemberRole() == ChatMember.MemberRole.MEMBER) {
                    throw new AppException("Cannot delete other user's message", HttpStatus.FORBIDDEN);
                }
            }
            messageRepository.deleteForEveryone(messageId, Instant.now());
        } else {
            // Soft delete for current user — store user's delete in status
            MessageStatus status = messageStatusRepository
                .findByMessageIdAndUserId(messageId, userId)
                .orElse(null);
            // Mark as a user-specific deletion via a deleted_for field
            message.setDeleted(true);
            message.setDeletedAt(Instant.now());
            messageRepository.save(message);
        }

        messagePublisher.publishMessageDelete(message.getChat().getId(), messageId, forEveryone);
    }

    @Transactional
    public MessageResponse toggleReaction(String messageId, String userId, ReactionRequest req) {
        Message message = findMessageById(messageId);
        validateMember(message.getChat().getId(), userId);

        Optional<Reaction> existing = reactionRepository
            .findByMessageIdAndUserIdAndEmoji(messageId, userId, req.getEmoji());

        if (existing.isPresent()) {
            reactionRepository.deleteByMessageIdAndUserIdAndEmoji(messageId, userId, req.getEmoji());
        } else {
            Reaction reaction = Reaction.builder()
                .message(message).userId(userId).emoji(req.getEmoji()).build();
            reactionRepository.save(reaction);
        }

        MessageResponse response = toMessageResponse(message, userId);
        messagePublisher.publishReactionUpdate(response);
        return response;
    }

    @Transactional
    public void togglePin(String chatId, String messageId, String userId, boolean pin) {
        validateMember(chatId, userId);
        if (pin) {
            if (!pinnedMessageRepository.existsByChatIdAndMessageId(chatId, messageId)) {
                PinnedMessage pinned = PinnedMessage.builder()
                    .chatId(chatId).messageId(messageId).pinnedBy(userId).build();
                pinnedMessageRepository.save(pinned);
            }
        } else {
            pinnedMessageRepository.deleteByChatIdAndMessageId(chatId, messageId);
        }
        messagePublisher.publishPinUpdate(chatId, messageId, pin);
    }

    @Transactional
    public void toggleStar(String messageId, String userId, boolean star) {
        Message message = findMessageById(messageId);
        if (star) {
            if (!starredMessageRepository.existsByUserIdAndMessageId(userId, messageId)) {
                StarredMessage sm = StarredMessage.builder()
                    .userId(userId).messageId(messageId)
                    .chatId(message.getChat().getId()).build();
                starredMessageRepository.save(sm);
            }
        } else {
            starredMessageRepository.deleteByUserIdAndMessageId(userId, messageId);
        }
    }

    @Transactional
    public void markMessagesAsSeen(String chatId, String userId) {
        List<MessageStatus> unseen = messageStatusRepository.findUnseenInChat(chatId, userId);
        if (!unseen.isEmpty()) {
            List<String> ids = unseen.stream().map(ms -> ms.getMessage().getId()).toList();
            messageStatusRepository.markAsSeen(ids, userId, Instant.now());
            chatMemberRepository.updateLastRead(chatId, userId,
                ids.get(ids.size() - 1), Instant.now());
            presenceService.resetUnreadCount(chatId, userId);
            // Broadcast seen status
            messagePublisher.publishSeenStatus(chatId, userId, ids);
        }
    }

    public PageResponse<MessageResponse> getChatMessages(String chatId, String userId, int page, int size) {
        validateMember(chatId, userId);
        PageRequest pageRequest = PageRequest.of(page, Math.min(size, appConfig.getMaxPageSize()),
            Sort.by("createdAt").ascending());
        Page<Message> messages = messageRepository.findByChatId(chatId, pageRequest);
        Set<String> pinnedIds = pinnedMessageRepository.findByChatIdOrderByPinnedAtDesc(chatId)
            .stream().map(PinnedMessage::getMessageId).collect(Collectors.toSet());
        Set<String> starredIds = starredMessageRepository.findByUserIdOrderByStarredAtDesc(userId)
            .stream().map(StarredMessage::getMessageId).collect(Collectors.toSet());

        List<MessageResponse> content = messages.getContent().stream()
            .map(m -> {
                MessageResponse r = toMessageResponse(m, userId);
                r.setPinned(pinnedIds.contains(m.getId()));
                r.setStarred(starredIds.contains(m.getId()));
                return r;
            }).collect(Collectors.toList());

        return PageResponse.<MessageResponse>builder()
            .content(content).page(page).size(size)
            .totalElements(messages.getTotalElements())
            .totalPages(messages.getTotalPages())
            .hasNext(messages.hasNext()).hasPrevious(messages.hasPrevious())
            .build();
    }

    public PageResponse<MessageResponse> searchMessages(String chatId, String userId,
                                                         String query, int page, int size) {
        validateMember(chatId, userId);
        PageRequest pageRequest = PageRequest.of(page, size);
        Page<Message> messages = messageRepository.searchMessages(chatId, query, pageRequest);
        List<MessageResponse> content = messages.getContent().stream()
            .map(m -> toMessageResponse(m, userId)).collect(Collectors.toList());
        return PageResponse.<MessageResponse>builder()
            .content(content).page(page).size(size)
            .totalElements(messages.getTotalElements())
            .totalPages(messages.getTotalPages())
            .hasNext(messages.hasNext()).hasPrevious(messages.hasPrevious())
            .build();
    }

    public List<MessageResponse> getPinnedMessages(String chatId, String userId) {
        validateMember(chatId, userId);
        List<PinnedMessage> pinned = pinnedMessageRepository.findByChatIdOrderByPinnedAtDesc(chatId);
        return pinned.stream().map(pm -> {
            Message msg = messageRepository.findById(pm.getMessageId()).orElse(null);
            if (msg == null) return null;
            MessageResponse r = toMessageResponse(msg, userId);
            r.setPinned(true);
            return r;
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    public List<MessageResponse> getStarredMessages(String userId) {
        List<StarredMessage> starred = starredMessageRepository.findByUserIdOrderByStarredAtDesc(userId);
        return starred.stream().map(sm -> {
            Message msg = messageRepository.findById(sm.getMessageId()).orElse(null);
            if (msg == null) return null;
            MessageResponse r = toMessageResponse(msg, userId);
            r.setStarred(true);
            return r;
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    public List<MessageEditHistory> getEditHistory(String messageId, String userId) {
        Message message = findMessageById(messageId);
        validateMember(message.getChat().getId(), userId);
        return editHistoryRepository.findByMessageIdOrderByEditedAtDesc(messageId);
    }

    // ---- Internal helpers ----
    private synchronized long generateSequenceNumber(String chatId) {
        Optional<Long> max = messageRepository.findMaxSequenceNumber(chatId);
        return max.orElse(0L) + 1;
    }

    private void createMessageStatus(Message message, String userId, MessageStatus.DeliveryStatus status) {
        MessageStatus ms = MessageStatus.builder()
            .message(message).userId(userId).status(status).build();
        if (status == MessageStatus.DeliveryStatus.DELIVERED) ms.setDeliveredAt(Instant.now());
        if (status == MessageStatus.DeliveryStatus.SEEN) ms.setSeenAt(Instant.now());
        messageStatusRepository.save(ms);
    }

    private void validateMember(String chatId, String userId) {
        ChatMember member = chatMemberRepository.findByChatIdAndUserId(chatId, userId)
            .orElseThrow(() -> new AppException("Not a member of this chat", HttpStatus.FORBIDDEN));
        if (!member.isActive()) throw new AppException("Not an active member", HttpStatus.FORBIDDEN);
    }

    private Message findMessageById(String messageId) {
        return messageRepository.findById(messageId)
            .orElseThrow(() -> new AppException("Message not found: " + messageId, HttpStatus.NOT_FOUND));
    }

    public MessageResponse toMessageResponse(Message message, String currentUserId) {
        User sender = message.getSender();
        List<Attachment> attachments = attachmentRepository.findByMessageId(message.getId());
        List<Reaction> reactions = reactionRepository.findByMessageId(message.getId());
        List<MessageStatus> statuses = messageStatusRepository.findByMessageId(message.getId());

        // Build reaction map: emoji -> [userIds]
        Map<String, List<String>> reactionMap = new LinkedHashMap<>();
        for (Reaction r : reactions) {
            reactionMap.computeIfAbsent(r.getEmoji(), k -> new ArrayList<>()).add(r.getUserId());
        }

        // Get current user's delivery status
        String deliveryStatus = statuses.stream()
            .filter(s -> s.getUserId().equals(currentUserId))
            .map(s -> s.getStatus().name())
            .findFirst().orElse("SENT");

        List<AttachmentResponse> attachmentResponses = attachments.stream()
            .map(a -> AttachmentResponse.builder()
                .id(a.getId()).fileName(a.getFileName()).originalName(a.getOriginalName())
                .fileUrl(a.getFileUrl()).mimeType(a.getMimeType()).fileSize(a.getFileSize())
                .attachmentType(a.getAttachmentType() != null ? a.getAttachmentType().name() : null)
                .width(a.getWidth()).height(a.getHeight()).thumbnailUrl(a.getThumbnailUrl())
                .build())
            .collect(Collectors.toList());

        List<MessageStatusResponse> statusResponses = statuses.stream()
            .map(s -> MessageStatusResponse.builder()
                .userId(s.getUserId()).status(s.getStatus().name())
                .deliveredAt(s.getDeliveredAt()).seenAt(s.getSeenAt())
                .build())
            .collect(Collectors.toList());

        // Parse mentions
        List<String> mentions = new ArrayList<>();
        if (message.getMentions() != null) {
            try {
                mentions = objectMapper.readValue(message.getMentions(), new TypeReference<>() {});
            } catch (Exception ignored) {}
        }

        // Parent message (shallow)
        MessageResponse parentResponse = null;
        if (message.getParentMessageId() != null) {
            messageRepository.findById(message.getParentMessageId()).ifPresent(parent -> {
                // shallow reference only
            });
        }

        return MessageResponse.builder()
            .id(message.getId())
            .chatId(message.getChat().getId())
            .senderId(sender.getId())
            .senderName(sender.getDisplayName() != null ? sender.getDisplayName() : sender.getUsername())
            .senderAvatar(sender.getAvatarUrl())
            .senderActive(sender.isActive())
            .content(message.isDeletedForEveryone() ? "[Deleted]" : message.getContent())
            .messageType(message.getMessageType().name())
            .parentMessageId(message.getParentMessageId())
            .forwardedFromId(message.getForwardedFromId())
            .edited(message.isEdited())
            .editedAt(message.getEditedAt())
            .deleted(message.isDeleted())
            .deletedForEveryone(message.isDeletedForEveryone())
            .linkPreviewUrl(message.getLinkPreviewUrl())
            .linkPreviewTitle(message.getLinkPreviewTitle())
            .linkPreviewDescription(message.getLinkPreviewDescription())
            .linkPreviewImage(message.getLinkPreviewImage())
            .sequenceNumber(message.getSequenceNumber())
            .createdAt(message.getCreatedAt())
            .updatedAt(message.getUpdatedAt())
            .mentions(mentions)
            .attachments(attachmentResponses)
            .reactions(reactionMap)
            .statuses(statusResponses)
            .deliveryStatus(deliveryStatus)
            .build();
    }
}
