package com.corporate.chat.service;

import com.corporate.chat.config.AppConfig;
import com.corporate.chat.dto.request.UpdateProfileRequest;
import com.corporate.chat.dto.response.PageResponse;
import com.corporate.chat.dto.response.UserResponse;
import com.corporate.chat.exception.AppException;
import com.corporate.chat.model.User;
import com.corporate.chat.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final FileStorageService fileStorageService;
    private final PresenceService presenceService;
    private final AppConfig appConfig;

    public UserResponse getUserById(String userId) {
        User user = findUserById(userId);
        return toResponse(user);
    }

    public UserResponse getCurrentUser(String username) {
        User user = userRepository.findByUsernameOrEmail(username, username)
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        return toResponse(user);
    }

    @Transactional
    public UserResponse updateProfile(String userId, UpdateProfileRequest req) {
        User user = findUserById(userId);
        if (req.getDisplayName() != null && !req.getDisplayName().isBlank()) {
            user.setDisplayName(req.getDisplayName());
        }
        if (req.getBio() != null) {
            user.setBio(req.getBio());
        }
        return toResponse(userRepository.save(user));
    }

    @Transactional
    public UserResponse updateAvatar(String userId, MultipartFile file) {
        User user = findUserById(userId);
        // Delete old avatar
        if (user.getAvatarUrl() != null) {
            fileStorageService.deleteFileByUrl(user.getAvatarUrl());
        }
        String avatarUrl = fileStorageService.storeImage(file);
        user.setAvatarUrl(avatarUrl);
        return toResponse(userRepository.save(user));
    }

    public PageResponse<UserResponse> searchUsers(String query, int page, int size, boolean activeOnly) {
        PageRequest pageRequest = PageRequest.of(page, Math.min(size, appConfig.getMaxPageSize()),
            Sort.by("displayName").ascending());
        Page<User> users = activeOnly
            ? userRepository.searchActiveUsers(query, pageRequest)
            : userRepository.searchAllUsers(query, pageRequest);
        return buildPageResponse(users, page, size);
    }

    // ---- Admin operations ----
    public PageResponse<UserResponse> getAllUsersAdmin(int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, Math.min(size, appConfig.getMaxPageSize()),
            Sort.by("createdAt").descending());
        Page<User> users = userRepository.findAllUsersAdmin(pageRequest);
        return buildPageResponse(users, page, size);
    }

    @Transactional
    public void deactivateUser(String targetUserId, String adminId) {
        User user = findUserById(targetUserId);
        if (!user.isActive()) {
            throw new AppException("User is already deactivated", HttpStatus.BAD_REQUEST);
        }
        userRepository.deactivateUser(targetUserId, adminId, Instant.now());
        presenceService.setOffline(targetUserId);
        log.info("User {} deactivated by admin {}", targetUserId, adminId);
    }

    @Transactional
    public void reactivateUser(String targetUserId) {
        User user = findUserById(targetUserId);
        user.setActive(true);
        user.setDeactivatedAt(null);
        user.setDeactivatedBy(null);
        userRepository.save(user);
        log.info("User {} reactivated", targetUserId);
    }

    public List<UserResponse> getAllActiveUsers() {
        return userRepository.findAllActiveUsers().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    private User findUserById(String userId) {
        return userRepository.findById(userId)
            .orElseThrow(() -> new AppException("User not found: " + userId, HttpStatus.NOT_FOUND));
    }

    public UserResponse toResponse(User user) {
        boolean online = presenceService.isOnline(user.getId());
        Instant lastSeen = user.getLastSeenAt();
        if (lastSeen == null) lastSeen = presenceService.getLastSeen(user.getId());

        return UserResponse.builder()
            .id(user.getId())
            .username(user.getUsername())
            .email(user.getEmail())
            .displayName(user.getDisplayName() != null ? user.getDisplayName() : user.getUsername())
            .avatarUrl(user.getAvatarUrl())
            .bio(user.getBio())
            .role(user.getRole().name())
            .active(user.isActive())
            .presenceStatus(online ? "ONLINE" : user.getPresenceStatus().name())
            .lastSeenAt(lastSeen)
            .createdAt(user.getCreatedAt())
            .deactivatedAt(user.getDeactivatedAt())
            .build();
    }

    private PageResponse<UserResponse> buildPageResponse(Page<User> page, int pageNum, int size) {
        List<UserResponse> content = page.getContent().stream()
            .map(this::toResponse).collect(Collectors.toList());
        return PageResponse.<UserResponse>builder()
            .content(content).page(pageNum).size(size)
            .totalElements(page.getTotalElements())
            .totalPages(page.getTotalPages())
            .hasNext(page.hasNext()).hasPrevious(page.hasPrevious())
            .build();
    }
}
