package com.corporate.chat.repository;

import com.corporate.chat.model.ChatMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface ChatMemberRepository extends JpaRepository<ChatMember, String> {

    @Query("SELECT cm FROM ChatMember cm WHERE cm.chat.id = :chatId AND cm.active = true")
    List<ChatMember> findActiveMembersByChatId(@Param("chatId") String chatId);

    @Query("SELECT cm FROM ChatMember cm WHERE cm.chat.id = :chatId AND cm.user.id = :userId")
    Optional<ChatMember> findByChatIdAndUserId(@Param("chatId") String chatId,
                                                @Param("userId") String userId);

    @Query("SELECT cm FROM ChatMember cm WHERE cm.user.id = :userId AND cm.active = true")
    List<ChatMember> findActiveByUserId(@Param("userId") String userId);

    boolean existsByChatIdAndUserId(String chatId, String userId);

    @Modifying
    @Query("UPDATE ChatMember cm SET cm.active = false, cm.leftAt = :now " +
           "WHERE cm.chat.id = :chatId AND cm.user.id = :userId")
    void removeMember(@Param("chatId") String chatId,
                      @Param("userId") String userId,
                      @Param("now") Instant now);

    @Modifying
    @Query("UPDATE ChatMember cm SET cm.lastReadMessageId = :messageId, cm.lastReadAt = :now " +
           "WHERE cm.chat.id = :chatId AND cm.user.id = :userId")
    void updateLastRead(@Param("chatId") String chatId,
                        @Param("userId") String userId,
                        @Param("messageId") String messageId,
                        @Param("now") Instant now);

    @Query("SELECT cm.user.id FROM ChatMember cm WHERE cm.chat.id = :chatId AND cm.active = true")
    List<String> findActiveUserIdsByChatId(@Param("chatId") String chatId);
}
