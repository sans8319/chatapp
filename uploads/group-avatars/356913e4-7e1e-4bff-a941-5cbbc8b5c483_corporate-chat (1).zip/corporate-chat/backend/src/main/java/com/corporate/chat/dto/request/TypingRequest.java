package com.corporate.chat.dto.request;

import lombok.Data;

@Data
public class TypingRequest {
    private String chatId;
    private boolean typing;
}
