package com.corporate.chat.util;

import com.corporate.chat.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SecurityUtilsInitializer {

    private final UserRepository userRepository;

    @PostConstruct
    public void init() {
        SecurityUtils.setUserRepository(userRepository);
    }
}
