package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "messages", indexes = {
    @Index(name = "idx_messages_chat_id", columnList = "chat_id"),
    @Index(name = "idx_messages_sender_id", columnList = "sender_id"),
    @Index(name = "idx_messages_created_at", columnList = "created_at"),
    @Index(name = "idx_messages_parent_id", columnList = "parent_message_id"),
    @Index(name = "idx_messages_deleted", columnList = "deleted")
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chat_id", nullable = false)
    private Chat chat;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender_id", nullable = false)
    private User sender;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @Enumerated(EnumType.STRING)
    @Column(name = "message_type", length = 30)
    @Builder.Default
    private MessageType messageType = MessageType.TEXT;

    // Threading / Reply
    @Column(name = "parent_message_id", length = 36)
    private String parentMessageId;

    @Column(name = "forwarded_from_id", length = 36)
    private String forwardedFromId;

    // Edit tracking
    @Column(name = "edited", nullable = false)
    @Builder.Default
    private boolean edited = false;

    @Column(name = "edited_at")
    private Instant editedAt;

    // Soft delete
    @Column(name = "deleted", nullable = false)
    @Builder.Default
    private boolean deleted = false;

    @Column(name = "deleted_at")
    private Instant deletedAt;

    @Column(name = "deleted_for_everyone", nullable = false)
    @Builder.Default
    private boolean deletedForEveryone = false;

    // Link preview
    @Column(name = "link_preview_url", length = 2000)
    private String linkPreviewUrl;

    @Column(name = "link_preview_title", length = 500)
    private String linkPreviewTitle;

    @Column(name = "link_preview_description", length = 1000)
    private String linkPreviewDescription;

    @Column(name = "link_preview_image", length = 1000)
    private String linkPreviewImage;

    // Sequence for ordering guarantee
    @Column(name = "sequence_number")
    private Long sequenceNumber;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false, nullable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;

    // Mentions stored as JSON array of user IDs
    @Column(name = "mentions", length = 2000)
    private String mentions;

    @OneToMany(mappedBy = "message", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<MessageStatus> statuses = new ArrayList<>();

    @OneToMany(mappedBy = "message", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Attachment> attachments = new ArrayList<>();

    @OneToMany(mappedBy = "message", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Reaction> reactions = new ArrayList<>();

    @OneToMany(mappedBy = "message", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<MessageEditHistory> editHistory = new ArrayList<>();

    public enum MessageType {
        TEXT, IMAGE, VIDEO, DOCUMENT, AUDIO, SYSTEM, TYPING
    }
}
