package com.corporate.chat.dto.response;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AttachmentResponse {
    private String id;
    private String fileName;
    private String originalName;
    private String fileUrl;
    private String mimeType;
    private Long fileSize;
    private String attachmentType;
    private Integer width;
    private Integer height;
    private String thumbnailUrl;
}
