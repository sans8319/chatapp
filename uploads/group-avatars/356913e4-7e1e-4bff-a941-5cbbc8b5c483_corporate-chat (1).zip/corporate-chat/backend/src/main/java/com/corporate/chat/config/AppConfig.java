package com.corporate.chat.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.Executor;

@Configuration
public class AppConfig implements WebMvcConfigurer {

    @Value("${app.base-url}")
    private String baseUrl;

    @Value("${app.upload.path}")
    private String uploadPath;

    @Value("${app.upload.images-dir}")
    private String imagesDir;

    @Value("${app.upload.videos-dir}")
    private String videosDir;

    @Value("${app.upload.documents-dir}")
    private String documentsDir;

    @Value("${app.upload.max-size}")
    private long maxUploadSize;

    @Value("${app.pagination.default-page-size}")
    private int defaultPageSize;

    @Value("${app.pagination.max-page-size}")
    private int maxPageSize;

    // ---- Getters for use in services ----
    public String getBaseUrl() { return baseUrl; }
    public String getUploadPath() { return uploadPath; }
    public String getImagesDir() { return imagesDir; }
    public String getVideosDir() { return videosDir; }
    public String getDocumentsDir() { return documentsDir; }
    public long getMaxUploadSize() { return maxUploadSize; }
    public int getDefaultPageSize() { return defaultPageSize; }
    public int getMaxPageSize() { return maxPageSize; }

    public Path getImagesPath() { return Paths.get(uploadPath, imagesDir); }
    public Path getVideosPath() { return Paths.get(uploadPath, videosDir); }
    public Path getDocumentsPath() { return Paths.get(uploadPath, documentsDir); }

    public String buildFileUrl(String subPath, String filename) {
        return baseUrl + "/uploads/" + subPath + "/" + filename;
    }

    // ---- Static resource serving for uploads ----
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String uploadLocation = "file:" + Paths.get(uploadPath).toAbsolutePath() + "/";
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(uploadLocation)
                .setCachePeriod(3600);
    }

    // ---- Async executor for background tasks ----
    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(16);
        executor.setQueueCapacity(500);
        executor.setThreadNamePrefix("ChatAsync-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();
        return executor;
    }

    @Bean
    public MultipartResolver multipartResolver() {
        return new StandardServletMultipartResolver();
    }
}
