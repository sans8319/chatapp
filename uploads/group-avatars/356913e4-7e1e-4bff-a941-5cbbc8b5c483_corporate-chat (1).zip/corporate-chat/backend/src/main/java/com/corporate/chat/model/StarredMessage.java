package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "starred_messages",
    uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "message_id"}),
    indexes = {
        @Index(name = "idx_starred_user_id", columnList = "user_id")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class StarredMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "user_id", nullable = false, length = 36)
    private String userId;

    @Column(name = "message_id", nullable = false, length = 36)
    private String messageId;

    @Column(name = "chat_id", nullable = false, length = 36)
    private String chatId;

    @CreationTimestamp
    @Column(name = "starred_at", updatable = false)
    private Instant starredAt;
}
