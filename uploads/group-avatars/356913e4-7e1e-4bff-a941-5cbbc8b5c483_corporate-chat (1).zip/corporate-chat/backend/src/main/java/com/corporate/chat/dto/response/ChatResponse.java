package com.corporate.chat.dto.response;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import java.time.Instant;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatResponse {
    private String id;
    private String type;
    private String name;
    private String description;
    private String avatarUrl;
    private String createdBy;
    private boolean active;
    private Instant createdAt;
    private Instant lastMessageAt;
    private MessageResponse lastMessage;
    private List<ChatMemberResponse> members;
    private int unreadCount;
    private boolean muted;
    private String memberRole;
}
