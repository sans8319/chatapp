package com.corporate.chat.service;

import com.corporate.chat.dto.response.LinkPreviewResponse;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class LinkPreviewService {

    private static final Pattern URL_PATTERN = Pattern.compile(
        "https?://[\\w\\-._~:/?#\\[\\]@!$&'()*+,;=%]+",
        Pattern.CASE_INSENSITIVE);
    private static final int TIMEOUT_MS = 5000;
    private static final int MAX_CONTENT_LENGTH = 2 * 1024 * 1024; // 2MB

    public Optional<String> extractFirstUrl(String text) {
        if (text == null || text.isBlank()) return Optional.empty();
        Matcher matcher = URL_PATTERN.matcher(text);
        if (matcher.find()) return Optional.of(matcher.group());
        return Optional.empty();
    }

    @Async("taskExecutor")
    public CompletableFuture<LinkPreviewResponse> fetchPreview(String url) {
        try {
            Document doc = Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (compatible; CorporateChatBot/1.0)")
                .timeout(TIMEOUT_MS)
                .maxBodySize(MAX_CONTENT_LENGTH)
                .followRedirects(true)
                .get();

            String title = getMetaOrFallback(doc, "og:title", "twitter:title",
                doc.title());
            String description = getMetaOrFallback(doc, "og:description",
                "twitter:description", "description");
            String image = getMetaOrFallback(doc, "og:image", "twitter:image", null);
            String siteName = getMetaOrFallback(doc, "og:site_name", null,
                extractDomain(url));

            // Truncate
            if (title != null && title.length() > 200) title = title.substring(0, 200);
            if (description != null && description.length() > 400) description = description.substring(0, 400);

            return CompletableFuture.completedFuture(LinkPreviewResponse.builder()
                .url(url)
                .title(title)
                .description(description)
                .image(image)
                .siteName(siteName)
                .build());

        } catch (Exception e) {
            log.debug("Failed to fetch link preview for {}: {}", url, e.getMessage());
            return CompletableFuture.completedFuture(LinkPreviewResponse.builder()
                .url(url).title(extractDomain(url)).build());
        }
    }

    private String getMetaOrFallback(Document doc, String ogTag, String twitterTag, String fallback) {
        // Try og: tag
        Element el = doc.selectFirst("meta[property=" + ogTag + "]");
        if (el != null && !el.attr("content").isBlank()) return el.attr("content").trim();

        // Try twitter: tag
        if (twitterTag != null) {
            el = doc.selectFirst("meta[name=" + twitterTag + "]");
            if (el != null && !el.attr("content").isBlank()) return el.attr("content").trim();
        }

        // Fallback: try standard meta name
        if (fallback != null && !fallback.startsWith("http")) {
            el = doc.selectFirst("meta[name=" + fallback + "]");
            if (el != null && !el.attr("content").isBlank()) return el.attr("content").trim();
            return fallback;
        }
        return fallback;
    }

    private String extractDomain(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            return host != null ? host.replaceFirst("^www\\.", "") : url;
        } catch (Exception e) {
            return url;
        }
    }
}
