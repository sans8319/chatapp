package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "message_edit_history", indexes = {
    @Index(name = "idx_edit_history_message_id", columnList = "message_id")
})
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class MessageEditHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @Column(name = "previous_content", columnDefinition = "TEXT")
    private String previousContent;

    @Column(name = "edited_by", nullable = false, length = 36)
    private String editedBy;

    @CreationTimestamp
    @Column(name = "edited_at", updatable = false)
    private Instant editedAt;
}
