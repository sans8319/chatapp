package com.corporate.chat.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class SendMessageRequest {
    @NotBlank
    private String chatId;
    private String content;
    private String messageType; // TEXT, IMAGE, VIDEO, DOCUMENT
    private String parentMessageId;
    private String forwardedFromId;
    private String clientTempId; // For duplicate prevention
    private List<String> mentions;
}
