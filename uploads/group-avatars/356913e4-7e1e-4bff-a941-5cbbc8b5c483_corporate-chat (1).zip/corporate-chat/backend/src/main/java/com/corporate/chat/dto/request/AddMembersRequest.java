package com.corporate.chat.dto.request;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.util.List;

@Data
public class AddMembersRequest {
    @NotEmpty
    private List<String> userIds;
}
