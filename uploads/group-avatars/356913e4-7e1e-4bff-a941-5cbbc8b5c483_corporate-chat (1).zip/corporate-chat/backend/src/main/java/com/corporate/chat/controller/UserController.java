package com.corporate.chat.controller;

import com.corporate.chat.dto.request.UpdateProfileRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.service.PresenceService;
import com.corporate.chat.service.UserService;
import com.corporate.chat.util.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final PresenceService presenceService;

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserResponse>> getMe() {
        String username = SecurityUtils.getCurrentUsername();
        return ResponseEntity.ok(ApiResponse.success(userService.getCurrentUser(username)));
    }

    @PutMapping("/me")
    public ResponseEntity<ApiResponse<UserResponse>> updateProfile(
            @Valid @RequestBody UpdateProfileRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(userService.updateProfile(userId, request)));
    }

    @PostMapping(value = "/me/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<UserResponse>> uploadAvatar(
            @RequestPart("file") MultipartFile file) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(userService.updateAvatar(userId, file)));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable String userId) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUserById(userId)));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<PageResponse<UserResponse>>> searchUsers(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "true") boolean activeOnly) {
        return ResponseEntity.ok(ApiResponse.success(
            userService.searchUsers(q, page, size, activeOnly)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllActiveUsers() {
        return ResponseEntity.ok(ApiResponse.success(userService.getAllActiveUsers()));
    }

    @GetMapping("/online")
    public ResponseEntity<ApiResponse<Set<String>>> getOnlineUsers() {
        return ResponseEntity.ok(ApiResponse.success(presenceService.getOnlineUserIds()));
    }

    @PostMapping("/heartbeat")
    public ResponseEntity<Void> heartbeat() {
        String userId = SecurityUtils.getCurrentUserId();
        presenceService.setOnline(userId);
        return ResponseEntity.ok().build();
    }
}
