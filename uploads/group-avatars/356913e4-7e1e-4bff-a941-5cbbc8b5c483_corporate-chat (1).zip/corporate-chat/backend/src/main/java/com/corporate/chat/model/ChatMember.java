package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "chat_members",
    uniqueConstraints = @UniqueConstraint(columnNames = {"chat_id", "user_id"}),
    indexes = {
        @Index(name = "idx_chat_members_chat_id", columnList = "chat_id"),
        @Index(name = "idx_chat_members_user_id", columnList = "user_id"),
        @Index(name = "idx_chat_members_active", columnList = "active")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ChatMember {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chat_id", nullable = false)
    private Chat chat;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "member_role", length = 20)
    @Builder.Default
    private MemberRole memberRole = MemberRole.MEMBER;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @Column(name = "muted", nullable = false)
    @Builder.Default
    private boolean muted = false;

    @Column(name = "muted_until")
    private Instant mutedUntil;

    @Column(name = "deleted_for_user", nullable = false)
    @Builder.Default
    private boolean deletedForUser = false;

    @Column(name = "last_read_message_id", length = 36)
    private String lastReadMessageId;

    @Column(name = "last_read_at")
    private Instant lastReadAt;

    @CreationTimestamp
    @Column(name = "joined_at", updatable = false)
    private Instant joinedAt;

    @Column(name = "left_at")
    private Instant leftAt;

    public enum MemberRole {
        OWNER, ADMIN, MEMBER
    }
}
