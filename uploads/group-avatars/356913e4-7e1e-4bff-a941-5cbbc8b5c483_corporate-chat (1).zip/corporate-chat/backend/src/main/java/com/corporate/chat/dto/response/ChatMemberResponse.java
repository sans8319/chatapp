package com.corporate.chat.dto.response;
import lombok.*;
import java.time.Instant;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ChatMemberResponse {
    private String userId;
    private String username;
    private String displayName;
    private String avatarUrl;
    private String memberRole;
    private boolean active;
    private boolean userActive;
    private String presenceStatus;
    private Instant joinedAt;
    private Instant lastReadAt;
}
