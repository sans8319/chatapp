package com.corporate.chat.service;

import com.corporate.chat.dto.request.AddMembersRequest;
import com.corporate.chat.dto.request.CreateChatRequest;
import com.corporate.chat.dto.request.UpdateChatRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.exception.AppException;
import com.corporate.chat.model.*;
import com.corporate.chat.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChatService {

    private final ChatRepository chatRepository;
    private final ChatMemberRepository chatMemberRepository;
    private final UserRepository userRepository;
    private final MessageRepository messageRepository;
    private final PresenceService presenceService;
    private final UserService userService;
    private final SimpMessagingTemplate messagingTemplate;

    @Transactional
    public ChatResponse createChat(String currentUserId, CreateChatRequest req) {
        Chat.ChatType chatType = Chat.ChatType.valueOf(req.getType().toUpperCase());

        if (chatType == Chat.ChatType.DIRECT) {
            return createDirectChat(currentUserId, req);
        } else {
            return createGroupChat(currentUserId, req);
        }
    }

    private ChatResponse createDirectChat(String currentUserId, CreateChatRequest req) {
        if (req.getMemberIds().isEmpty()) {
            throw new AppException("Specify target user for direct chat", HttpStatus.BAD_REQUEST);
        }
        String otherUserId = req.getMemberIds().stream()
            .filter(id -> !id.equals(currentUserId))
            .findFirst()
            .orElse(req.getMemberIds().get(0));

        // Return existing direct chat if present
        Optional<Chat> existing = chatRepository.findDirectChat(currentUserId, otherUserId);
        if (existing.isPresent()) {
            return toChatResponse(existing.get(), currentUserId);
        }

        User otherUser = userRepository.findById(otherUserId)
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        User currentUser = userRepository.findById(currentUserId)
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        Chat chat = Chat.builder()
            .type(Chat.ChatType.DIRECT)
            .createdBy(currentUserId)
            .build();
        chat = chatRepository.save(chat);

        addMemberToChat(chat, currentUser, ChatMember.MemberRole.OWNER);
        addMemberToChat(chat, otherUser, ChatMember.MemberRole.MEMBER);

        log.info("Direct chat created between {} and {}", currentUserId, otherUserId);
        ChatResponse response = toChatResponse(chat, currentUserId);
        // Notify other user
        notifyNewChat(otherUserId, response);
        return response;
    }

    private ChatResponse createGroupChat(String currentUserId, CreateChatRequest req) {
        if (req.getName() == null || req.getName().isBlank()) {
            throw new AppException("Group name is required", HttpStatus.BAD_REQUEST);
        }
        User currentUser = userRepository.findById(currentUserId)
            .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        Chat chat = Chat.builder()
            .type(Chat.ChatType.GROUP)
            .name(req.getName())
            .description(req.getDescription())
            .createdBy(currentUserId)
            .build();
        chat = chatRepository.save(chat);

        addMemberToChat(chat, currentUser, ChatMember.MemberRole.OWNER);

        // Add requested members
        Set<String> memberIds = new HashSet<>(req.getMemberIds());
        memberIds.remove(currentUserId);
        List<User> members = userRepository.findByIdIn(new ArrayList<>(memberIds));
        for (User member : members) {
            addMemberToChat(chat, member, ChatMember.MemberRole.MEMBER);
        }

        log.info("Group chat '{}' created by {}", chat.getName(), currentUserId);
        ChatResponse response = toChatResponse(chat, currentUserId);
        // Notify all members
        memberIds.forEach(uid -> notifyNewChat(uid, response));
        return response;
    }

    public List<ChatResponse> getUserChats(String userId) {
        List<Chat> chats = chatRepository.findChatsByUserId(userId);
        return chats.stream()
            .map(c -> toChatResponse(c, userId))
            .collect(Collectors.toList());
    }

    public ChatResponse getChatById(String chatId, String userId) {
        Chat chat = findChatById(chatId);
        assertMember(chatId, userId);
        return toChatResponse(chat, userId);
    }

    @Transactional
    public ChatResponse updateChat(String chatId, String userId, UpdateChatRequest req) {
        Chat chat = findChatById(chatId);
        assertAdminOrOwner(chatId, userId);
        if (req.getName() != null && !req.getName().isBlank()) chat.setName(req.getName());
        if (req.getDescription() != null) chat.setDescription(req.getDescription());
        chat = chatRepository.save(chat);
        ChatResponse response = toChatResponse(chat, userId);
        broadcastChatUpdate(chat, response);
        return response;
    }

    @Transactional
    public void addMembers(String chatId, String requesterId, AddMembersRequest req) {
        Chat chat = findChatById(chatId);
        if (chat.getType() != Chat.ChatType.GROUP) {
            throw new AppException("Cannot add members to direct chat", HttpStatus.BAD_REQUEST);
        }
        assertAdminOrOwner(chatId, requesterId);
        List<User> usersToAdd = userRepository.findByIdIn(req.getUserIds());
        for (User user : usersToAdd) {
            Optional<ChatMember> existing = chatMemberRepository.findByChatIdAndUserId(chatId, user.getId());
            if (existing.isPresent() && existing.get().isActive()) continue;
            if (existing.isPresent()) {
                existing.get().setActive(true);
                existing.get().setLeftAt(null);
                chatMemberRepository.save(existing.get());
            } else {
                addMemberToChat(chat, user, ChatMember.MemberRole.MEMBER);
            }
            notifyNewChat(user.getId(), toChatResponse(chat, user.getId()));
        }
        broadcastMembersUpdate(chatId);
    }

    @Transactional
    public void removeMember(String chatId, String requesterId, String targetUserId) {
        Chat chat = findChatById(chatId);
        if (chat.getType() != Chat.ChatType.GROUP) {
            throw new AppException("Cannot remove members from direct chat", HttpStatus.BAD_REQUEST);
        }
        // Can remove self, or admin/owner can remove others
        if (!requesterId.equals(targetUserId)) {
            assertAdminOrOwner(chatId, requesterId);
        }
        chatMemberRepository.removeMember(chatId, targetUserId, Instant.now());
        broadcastMembersUpdate(chatId);
    }

    @Transactional
    public void deleteForUser(String chatId, String userId) {
        ChatMember member = chatMemberRepository.findByChatIdAndUserId(chatId, userId)
            .orElseThrow(() -> new AppException("Not a member", HttpStatus.FORBIDDEN));
        member.setDeletedForUser(true);
        chatMemberRepository.save(member);
    }

    @Transactional
    public void toggleMute(String chatId, String userId, boolean mute) {
        ChatMember member = chatMemberRepository.findByChatIdAndUserId(chatId, userId)
            .orElseThrow(() -> new AppException("Not a member", HttpStatus.FORBIDDEN));
        member.setMuted(mute);
        chatMemberRepository.save(member);
    }

    public List<UserResponse> getChatMembers(String chatId, String requesterId) {
        assertMember(chatId, requesterId);
        List<ChatMember> members = chatMemberRepository.findActiveMembersByChatId(chatId);
        return members.stream()
            .map(cm -> userService.toResponse(cm.getUser()))
            .collect(Collectors.toList());
    }

    // ---- Internal helpers ----
    private ChatMember addMemberToChat(Chat chat, User user, ChatMember.MemberRole role) {
        ChatMember member = ChatMember.builder()
            .chat(chat).user(user).memberRole(role).active(true).build();
        return chatMemberRepository.save(member);
    }

    public Chat findChatById(String chatId) {
        return chatRepository.findById(chatId)
            .orElseThrow(() -> new AppException("Chat not found: " + chatId, HttpStatus.NOT_FOUND));
    }

    public void assertMember(String chatId, String userId) {
        ChatMember member = chatMemberRepository.findByChatIdAndUserId(chatId, userId)
            .orElseThrow(() -> new AppException("Not a member of this chat", HttpStatus.FORBIDDEN));
        if (!member.isActive()) {
            throw new AppException("You are not an active member of this chat", HttpStatus.FORBIDDEN);
        }
    }

    private void assertAdminOrOwner(String chatId, String userId) {
        ChatMember member = chatMemberRepository.findByChatIdAndUserId(chatId, userId)
            .orElseThrow(() -> new AppException("Not a member", HttpStatus.FORBIDDEN));
        if (member.getMemberRole() == ChatMember.MemberRole.MEMBER) {
            throw new AppException("Admin or Owner role required", HttpStatus.FORBIDDEN);
        }
    }

    public ChatResponse toChatResponse(Chat chat, String currentUserId) {
        List<ChatMember> members = chatMemberRepository.findActiveMembersByChatId(chat.getId());

        ChatMember myMembership = members.stream()
            .filter(m -> m.getUser().getId().equals(currentUserId))
            .findFirst().orElse(null);

        // For direct chats, use the other user's name/avatar
        String chatName = chat.getName();
        String chatAvatar = chat.getAvatarUrl();
        if (chat.getType() == Chat.ChatType.DIRECT) {
            Optional<ChatMember> other = members.stream()
                .filter(m -> !m.getUser().getId().equals(currentUserId))
                .findFirst();
            if (other.isPresent()) {
                User otherUser = other.get().getUser();
                chatName = otherUser.getDisplayName() != null ? otherUser.getDisplayName() : otherUser.getUsername();
                chatAvatar = otherUser.getAvatarUrl();
            }
        }

        long unread = presenceService.getUnreadCount(chat.getId(), currentUserId);

        List<ChatMemberResponse> memberResponses = members.stream()
            .map(m -> ChatMemberResponse.builder()
                .userId(m.getUser().getId())
                .username(m.getUser().getUsername())
                .displayName(m.getUser().getDisplayName() != null
                    ? m.getUser().getDisplayName() : m.getUser().getUsername())
                .avatarUrl(m.getUser().getAvatarUrl())
                .memberRole(m.getMemberRole().name())
                .active(m.isActive())
                .userActive(m.getUser().isActive())
                .presenceStatus(presenceService.isOnline(m.getUser().getId()) ? "ONLINE" : "OFFLINE")
                .joinedAt(m.getJoinedAt())
                .lastReadAt(m.getLastReadAt())
                .build())
            .collect(Collectors.toList());

        return ChatResponse.builder()
            .id(chat.getId())
            .type(chat.getType().name())
            .name(chatName)
            .description(chat.getDescription())
            .avatarUrl(chatAvatar)
            .createdBy(chat.getCreatedBy())
            .active(chat.isActive())
            .createdAt(chat.getCreatedAt())
            .lastMessageAt(chat.getLastMessageAt())
            .members(memberResponses)
            .unreadCount((int) unread)
            .muted(myMembership != null && myMembership.isMuted())
            .memberRole(myMembership != null ? myMembership.getMemberRole().name() : null)
            .build();
    }

    private void notifyNewChat(String userId, ChatResponse response) {
        try {
            messagingTemplate.convertAndSendToUser(userId, "/queue/chats.new", response);
        } catch (Exception e) {
            log.warn("Failed to notify user {} of new chat", userId);
        }
    }

    private void broadcastChatUpdate(Chat chat, ChatResponse response) {
        try {
            messagingTemplate.convertAndSend("/topic/chat." + chat.getId() + ".update", response);
        } catch (Exception e) {
            log.warn("Failed to broadcast chat update", e);
        }
    }

    private void broadcastMembersUpdate(String chatId) {
        try {
            List<ChatMember> members = chatMemberRepository.findActiveMembersByChatId(chatId);
            messagingTemplate.convertAndSend("/topic/chat." + chatId + ".members", members);
        } catch (Exception e) {
            log.warn("Failed to broadcast members update", e);
        }
    }
}
