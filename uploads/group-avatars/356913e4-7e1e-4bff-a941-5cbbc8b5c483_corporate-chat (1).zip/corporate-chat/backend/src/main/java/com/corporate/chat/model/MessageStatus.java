package com.corporate.chat.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "message_status",
    uniqueConstraints = @UniqueConstraint(columnNames = {"message_id", "user_id"}),
    indexes = {
        @Index(name = "idx_msg_status_message_id", columnList = "message_id"),
        @Index(name = "idx_msg_status_user_id", columnList = "user_id"),
        @Index(name = "idx_msg_status_status", columnList = "status")
    })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class MessageStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @Column(name = "user_id", nullable = false, length = 36)
    private String userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private DeliveryStatus status = DeliveryStatus.SENT;

    @Column(name = "delivered_at")
    private Instant deliveredAt;

    @Column(name = "seen_at")
    private Instant seenAt;

    public enum DeliveryStatus {
        SENT, DELIVERED, SEEN
    }
}
