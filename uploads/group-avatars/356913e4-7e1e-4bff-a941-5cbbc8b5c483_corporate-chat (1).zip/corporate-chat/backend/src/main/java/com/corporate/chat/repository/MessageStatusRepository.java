package com.corporate.chat.repository;

import com.corporate.chat.model.MessageStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface MessageStatusRepository extends JpaRepository<MessageStatus, String> {

    List<MessageStatus> findByMessageId(String messageId);

    Optional<MessageStatus> findByMessageIdAndUserId(String messageId, String userId);

    @Modifying
    @Query("UPDATE MessageStatus ms SET ms.status = 'SEEN', ms.seenAt = :now " +
           "WHERE ms.message.id IN :messageIds AND ms.userId = :userId AND ms.status != 'SEEN'")
    void markAsSeen(@Param("messageIds") List<String> messageIds,
                    @Param("userId") String userId,
                    @Param("now") Instant now);

    @Modifying
    @Query("UPDATE MessageStatus ms SET ms.status = 'DELIVERED', ms.deliveredAt = :now " +
           "WHERE ms.message.id IN :messageIds AND ms.userId = :userId AND ms.status = 'SENT'")
    void markAsDelivered(@Param("messageIds") List<String> messageIds,
                         @Param("userId") String userId,
                         @Param("now") Instant now);

    @Query("SELECT ms FROM MessageStatus ms WHERE ms.message.chat.id = :chatId " +
           "AND ms.userId = :userId AND ms.status != 'SEEN' AND ms.message.deleted = false")
    List<MessageStatus> findUnseenInChat(@Param("chatId") String chatId,
                                          @Param("userId") String userId);
}
