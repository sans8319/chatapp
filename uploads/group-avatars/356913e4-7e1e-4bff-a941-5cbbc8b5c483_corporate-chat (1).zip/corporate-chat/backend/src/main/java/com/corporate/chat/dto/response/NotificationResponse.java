package com.corporate.chat.dto.response;
import lombok.*;
import java.time.Instant;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NotificationResponse {
    private String id;
    private String type;
    private String title;
    private String body;
    private String chatId;
    private String messageId;
    private String senderId;
    private String senderName;
    private String senderAvatar;
    private boolean read;
    private Instant createdAt;
}
