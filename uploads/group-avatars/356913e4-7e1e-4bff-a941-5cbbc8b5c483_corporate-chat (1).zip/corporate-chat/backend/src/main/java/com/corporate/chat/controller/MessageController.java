package com.corporate.chat.controller;

import com.corporate.chat.dto.request.EditMessageRequest;
import com.corporate.chat.dto.request.ReactionRequest;
import com.corporate.chat.dto.request.SendMessageRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.model.MessageEditHistory;
import com.corporate.chat.service.MessageService;
import com.corporate.chat.util.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;

    @PostMapping
    public ResponseEntity<ApiResponse<MessageResponse>> sendMessage(
            @Valid @RequestBody SendMessageRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(messageService.sendMessage(userId, request)));
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<MessageResponse>> sendFile(
            @RequestParam("chatId") String chatId,
            @RequestPart("file") MultipartFile file) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(messageService.sendFileMessage(userId, chatId, file)));
    }

    @GetMapping("/chat/{chatId}")
    public ResponseEntity<ApiResponse<PageResponse<MessageResponse>>> getChatMessages(
            @PathVariable String chatId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(
            messageService.getChatMessages(chatId, userId, page, size)));
    }

    @PutMapping("/{messageId}")
    public ResponseEntity<ApiResponse<MessageResponse>> editMessage(
            @PathVariable String messageId,
            @Valid @RequestBody EditMessageRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(messageService.editMessage(messageId, userId, request)));
    }

    @DeleteMapping("/{messageId}")
    public ResponseEntity<ApiResponse<Void>> deleteMessage(
            @PathVariable String messageId,
            @RequestParam(defaultValue = "false") boolean forEveryone) {
        String userId = SecurityUtils.getCurrentUserId();
        messageService.deleteMessage(messageId, userId, forEveryone);
        return ResponseEntity.ok(ApiResponse.success("Message deleted", null));
    }

    @PostMapping("/{messageId}/reactions")
    public ResponseEntity<ApiResponse<MessageResponse>> toggleReaction(
            @PathVariable String messageId,
            @Valid @RequestBody ReactionRequest request) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(
            messageService.toggleReaction(messageId, userId, request)));
    }

    @PostMapping("/chat/{chatId}/pin/{messageId}")
    public ResponseEntity<ApiResponse<Void>> pinMessage(
            @PathVariable String chatId,
            @PathVariable String messageId,
            @RequestParam(defaultValue = "true") boolean pin) {
        String userId = SecurityUtils.getCurrentUserId();
        messageService.togglePin(chatId, messageId, userId, pin);
        return ResponseEntity.ok(ApiResponse.success(pin ? "Message pinned" : "Message unpinned", null));
    }

    @GetMapping("/chat/{chatId}/pinned")
    public ResponseEntity<ApiResponse<List<MessageResponse>>> getPinnedMessages(
            @PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(messageService.getPinnedMessages(chatId, userId)));
    }

    @PostMapping("/{messageId}/star")
    public ResponseEntity<ApiResponse<Void>> starMessage(
            @PathVariable String messageId,
            @RequestParam(defaultValue = "true") boolean star) {
        String userId = SecurityUtils.getCurrentUserId();
        messageService.toggleStar(messageId, userId, star);
        return ResponseEntity.ok(ApiResponse.success(star ? "Starred" : "Unstarred", null));
    }

    @GetMapping("/starred")
    public ResponseEntity<ApiResponse<List<MessageResponse>>> getStarredMessages() {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(messageService.getStarredMessages(userId)));
    }

    @PostMapping("/chat/{chatId}/seen")
    public ResponseEntity<ApiResponse<Void>> markAsSeen(@PathVariable String chatId) {
        String userId = SecurityUtils.getCurrentUserId();
        messageService.markMessagesAsSeen(chatId, userId);
        return ResponseEntity.ok(ApiResponse.success("Marked as seen", null));
    }

    @GetMapping("/chat/{chatId}/search")
    public ResponseEntity<ApiResponse<PageResponse<MessageResponse>>> searchMessages(
            @PathVariable String chatId,
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(
            messageService.searchMessages(chatId, userId, q, page, size)));
    }

    @GetMapping("/{messageId}/history")
    public ResponseEntity<ApiResponse<List<MessageEditHistory>>> getEditHistory(
            @PathVariable String messageId) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(
            messageService.getEditHistory(messageId, userId)));
    }
}
