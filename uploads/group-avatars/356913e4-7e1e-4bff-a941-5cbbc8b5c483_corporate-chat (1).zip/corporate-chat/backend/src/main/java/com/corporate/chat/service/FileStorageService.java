package com.corporate.chat.service;

import com.corporate.chat.config.AppConfig;
import com.corporate.chat.exception.AppException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileStorageService {

    private final AppConfig appConfig;
    private final Tika tika = new Tika();

    private static final Set<String> ALLOWED_IMAGE_TYPES = Set.of(
        "image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp"
    );
    private static final Set<String> ALLOWED_VIDEO_TYPES = Set.of(
        "video/mp4", "video/webm", "video/ogg", "video/mpeg", "video/quicktime"
    );
    private static final Set<String> ALLOWED_DOCUMENT_TYPES = Set.of(
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain", "text/csv", "application/zip",
        "application/x-rar-compressed", "application/json"
    );

    public String storeImage(MultipartFile file) {
        return storeFile(file, appConfig.getImagesPath(), "images", ALLOWED_IMAGE_TYPES);
    }

    public String storeVideo(MultipartFile file) {
        return storeFile(file, appConfig.getVideosPath(), "videos", ALLOWED_VIDEO_TYPES);
    }

    public String storeDocument(MultipartFile file) {
        return storeFile(file, appConfig.getDocumentsPath(), "documents", ALLOWED_DOCUMENT_TYPES);
    }

    public String storeFileByType(MultipartFile file) {
        String mimeType = detectMimeType(file);
        if (ALLOWED_IMAGE_TYPES.contains(mimeType)) return storeImage(file);
        if (ALLOWED_VIDEO_TYPES.contains(mimeType)) return storeVideo(file);
        if (ALLOWED_DOCUMENT_TYPES.contains(mimeType)) return storeDocument(file);
        throw new AppException("Unsupported file type: " + mimeType, HttpStatus.BAD_REQUEST);
    }

    private String storeFile(MultipartFile file, Path dir, String subPath, Set<String> allowed) {
        validateFile(file, allowed);
        ensureDirectoryExists(dir);

        String originalFilename = sanitizeFilename(
            Objects.requireNonNullElse(file.getOriginalFilename(), "file"));
        String extension = getExtension(originalFilename);
        String uniqueFilename = UUID.randomUUID() + (extension.isEmpty() ? "" : "." + extension);

        try {
            Path targetPath = dir.resolve(uniqueFilename);
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
            log.info("Stored file: {}", targetPath);
            return appConfig.buildFileUrl(subPath, uniqueFilename);
        } catch (IOException e) {
            log.error("Failed to store file", e);
            throw new AppException("Failed to store file: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void deleteFileByUrl(String fileUrl) {
        if (fileUrl == null) return;
        try {
            String baseUploadUrl = appConfig.getBaseUrl() + "/uploads/";
            if (!fileUrl.startsWith(baseUploadUrl)) return;
            String relativePath = fileUrl.substring(baseUploadUrl.length());
            Path filePath = Paths.get(appConfig.getUploadPath()).resolve(relativePath);
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            log.warn("Failed to delete file: {}", fileUrl);
        }
    }

    public String detectMimeType(MultipartFile file) {
        try {
            return tika.detect(file.getInputStream(), file.getOriginalFilename());
        } catch (IOException e) {
            return file.getContentType() != null ? file.getContentType() : "application/octet-stream";
        }
    }

    public String getSubPathFromUrl(String fileUrl) {
        if (fileUrl == null) return null;
        if (fileUrl.contains("/images/")) return "images";
        if (fileUrl.contains("/videos/")) return "videos";
        if (fileUrl.contains("/documents/")) return "documents";
        return "documents";
    }

    private void validateFile(MultipartFile file, Set<String> allowedTypes) {
        if (file == null || file.isEmpty()) {
            throw new AppException("File is empty", HttpStatus.BAD_REQUEST);
        }
        if (file.getSize() > appConfig.getMaxUploadSize()) {
            throw new AppException(
                "File size exceeds maximum allowed: " + (appConfig.getMaxUploadSize() / 1024 / 1024) + "MB",
                HttpStatus.BAD_REQUEST);
        }
        String mimeType = detectMimeType(file);
        if (!allowedTypes.contains(mimeType)) {
            throw new AppException("File type not allowed: " + mimeType, HttpStatus.BAD_REQUEST);
        }
    }

    private void ensureDirectoryExists(Path dir) {
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            throw new AppException("Cannot create upload directory", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private String sanitizeFilename(String filename) {
        return filename.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private String getExtension(String filename) {
        int dotIdx = filename.lastIndexOf('.');
        return dotIdx > 0 ? filename.substring(dotIdx + 1).toLowerCase() : "";
    }

    public String getAttachmentTypeFromMime(String mimeType) {
        if (ALLOWED_IMAGE_TYPES.contains(mimeType)) return "IMAGE";
        if (ALLOWED_VIDEO_TYPES.contains(mimeType)) return "VIDEO";
        return "DOCUMENT";
    }
}
