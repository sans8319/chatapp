package com.corporate.chat.messaging;

import com.corporate.chat.config.RabbitMQConfig;
import com.corporate.chat.dto.response.MessageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class MessagePublisher {

    private final RabbitTemplate rabbitTemplate;

    @Async("taskExecutor")
    public void publishMessage(MessageResponse message) {
        try {
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.MESSAGE_ROUTING_KEY,
                message);
            log.debug("Published message {} to RabbitMQ", message.getId());
        } catch (Exception e) {
            log.error("Failed to publish message to RabbitMQ: {}", e.getMessage(), e);
        }
    }

    @Async("taskExecutor")
    public void publishMessageEdit(MessageResponse message) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("type", "MESSAGE_EDIT");
            payload.put("message", message);
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.MESSAGE_ROUTING_KEY,
                payload);
        } catch (Exception e) {
            log.error("Failed to publish edit event: {}", e.getMessage());
        }
    }

    @Async("taskExecutor")
    public void publishMessageDelete(String chatId, String messageId, boolean forEveryone) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("type", "MESSAGE_DELETE");
            payload.put("chatId", chatId);
            payload.put("messageId", messageId);
            payload.put("forEveryone", forEveryone);
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.MESSAGE_ROUTING_KEY,
                payload);
        } catch (Exception e) {
            log.error("Failed to publish delete event: {}", e.getMessage());
        }
    }

    @Async("taskExecutor")
    public void publishReactionUpdate(MessageResponse message) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("type", "REACTION_UPDATE");
            payload.put("message", message);
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.MESSAGE_ROUTING_KEY,
                payload);
        } catch (Exception e) {
            log.error("Failed to publish reaction event: {}", e.getMessage());
        }
    }

    @Async("taskExecutor")
    public void publishPinUpdate(String chatId, String messageId, boolean pinned) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("type", "PIN_UPDATE");
            payload.put("chatId", chatId);
            payload.put("messageId", messageId);
            payload.put("pinned", pinned);
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.MESSAGE_ROUTING_KEY,
                payload);
        } catch (Exception e) {
            log.error("Failed to publish pin event: {}", e.getMessage());
        }
    }

    @Async("taskExecutor")
    public void publishSeenStatus(String chatId, String userId, List<String> messageIds) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("type", "SEEN_STATUS");
            payload.put("chatId", chatId);
            payload.put("userId", userId);
            payload.put("messageIds", messageIds);
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.CHAT_EXCHANGE,
                RabbitMQConfig.DELIVERY_ROUTING_KEY,
                payload);
        } catch (Exception e) {
            log.error("Failed to publish seen status: {}", e.getMessage());
        }
    }
}
