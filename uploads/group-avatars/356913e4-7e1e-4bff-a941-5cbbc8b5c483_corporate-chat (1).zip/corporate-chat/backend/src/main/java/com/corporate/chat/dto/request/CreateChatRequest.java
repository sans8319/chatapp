package com.corporate.chat.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class CreateChatRequest {
    @NotBlank
    private String type; // DIRECT or GROUP
    private String name;
    private String description;
    @NotEmpty
    private List<String> memberIds;
}
