package com.corporate.chat.repository;

import com.corporate.chat.model.Reaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReactionRepository extends JpaRepository<Reaction, String> {

    List<Reaction> findByMessageId(String messageId);

    Optional<Reaction> findByMessageIdAndUserIdAndEmoji(String messageId, String userId, String emoji);

    void deleteByMessageIdAndUserIdAndEmoji(String messageId, String userId, String emoji);

    @Query("SELECT r FROM Reaction r WHERE r.message.id IN :messageIds")
    List<Reaction> findByMessageIdIn(@Param("messageIds") List<String> messageIds);
}
