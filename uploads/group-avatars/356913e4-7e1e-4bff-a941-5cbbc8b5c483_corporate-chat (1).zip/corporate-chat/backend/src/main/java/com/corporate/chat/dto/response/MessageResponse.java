package com.corporate.chat.dto.response;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessageResponse {
    private String id;
    private String chatId;
    private String senderId;
    private String senderName;
    private String senderAvatar;
    private boolean senderActive;
    private String content;
    private String messageType;
    private String parentMessageId;
    private MessageResponse parentMessage;
    private String forwardedFromId;
    private boolean edited;
    private Instant editedAt;
    private boolean deleted;
    private boolean deletedForEveryone;
    private String linkPreviewUrl;
    private String linkPreviewTitle;
    private String linkPreviewDescription;
    private String linkPreviewImage;
    private Long sequenceNumber;
    private Instant createdAt;
    private Instant updatedAt;
    private List<String> mentions;
    private List<AttachmentResponse> attachments;
    private Map<String, List<String>> reactions;
    private List<MessageStatusResponse> statuses;
    private boolean pinned;
    private boolean starred;
    private String deliveryStatus;
    private String clientTempId;
}
