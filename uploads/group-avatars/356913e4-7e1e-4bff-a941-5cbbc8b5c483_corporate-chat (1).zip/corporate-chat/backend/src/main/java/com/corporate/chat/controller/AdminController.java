package com.corporate.chat.controller;

import com.corporate.chat.dto.response.*;
import com.corporate.chat.service.UserService;
import com.corporate.chat.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserService userService;

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<PageResponse<UserResponse>>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(userService.getAllUsersAdmin(page, size)));
    }

    @GetMapping("/users/search")
    public ResponseEntity<ApiResponse<PageResponse<UserResponse>>> searchUsers(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(userService.searchUsers(q, page, size, false)));
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<ApiResponse<Void>> deactivateUser(@PathVariable String userId) {
        String adminId = SecurityUtils.getCurrentUserId();
        userService.deactivateUser(userId, adminId);
        return ResponseEntity.ok(ApiResponse.success("User deactivated", null));
    }

    @PostMapping("/users/{userId}/reactivate")
    public ResponseEntity<ApiResponse<Void>> reactivateUser(@PathVariable String userId) {
        userService.reactivateUser(userId);
        return ResponseEntity.ok(ApiResponse.success("User reactivated", null));
    }

    @GetMapping("/users/{userId}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserDetail(@PathVariable String userId) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUserById(userId)));
    }
}
