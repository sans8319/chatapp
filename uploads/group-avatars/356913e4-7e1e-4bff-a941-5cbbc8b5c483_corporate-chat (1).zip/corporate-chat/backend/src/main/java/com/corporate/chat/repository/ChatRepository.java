package com.corporate.chat.repository;

import com.corporate.chat.model.Chat;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatRepository extends JpaRepository<Chat, String> {

    @Query("SELECT DISTINCT c FROM Chat c " +
           "JOIN c.members m " +
           "WHERE m.user.id = :userId AND m.active = true AND m.deletedForUser = false " +
           "ORDER BY c.lastMessageAt DESC NULLS LAST")
    List<Chat> findChatsByUserId(@Param("userId") String userId);

    @Query("SELECT c FROM Chat c " +
           "JOIN c.members m1 " +
           "JOIN c.members m2 " +
           "WHERE c.type = 'DIRECT' " +
           "AND m1.user.id = :userId1 AND m1.active = true " +
           "AND m2.user.id = :userId2 AND m2.active = true")
    Optional<Chat> findDirectChat(@Param("userId1") String userId1,
                                   @Param("userId2") String userId2);

    @Query("SELECT c FROM Chat c " +
           "JOIN c.members m " +
           "WHERE c.type = 'GROUP' AND m.user.id = :userId AND m.active = true " +
           "AND (LOWER(c.name) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Chat> searchGroupChats(@Param("userId") String userId,
                                 @Param("query") String query);
}
