package com.corporate.chat.messaging;

import com.corporate.chat.config.RabbitMQConfig;
import com.corporate.chat.dto.response.MessageResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class MessageConsumer {

    private final SimpMessagingTemplate messagingTemplate;
    private final ObjectMapper objectMapper;

    @RabbitListener(queues = RabbitMQConfig.MESSAGE_QUEUE, containerFactory = "rabbitListenerContainerFactory")
    public void consumeMessage(Object payload) {
        try {
            if (payload instanceof MessageResponse message) {
                broadcastNewMessage(message);
            } else if (payload instanceof Map<?, ?> map) {
                String type = (String) map.get("type");
                if (type == null) return;

                switch (type) {
                    case "MESSAGE_EDIT" -> {
                        MessageResponse msg = objectMapper.convertValue(map.get("message"), MessageResponse.class);
                        broadcastMessageEdit(msg);
                    }
                    case "MESSAGE_DELETE" -> {
                        String chatId = (String) map.get("chatId");
                        String messageId = (String) map.get("messageId");
                        boolean forEveryone = Boolean.TRUE.equals(map.get("forEveryone"));
                        broadcastMessageDelete(chatId, messageId, forEveryone);
                    }
                    case "REACTION_UPDATE" -> {
                        MessageResponse msg = objectMapper.convertValue(map.get("message"), MessageResponse.class);
                        broadcastReactionUpdate(msg);
                    }
                    case "PIN_UPDATE" -> {
                        String chatId = (String) map.get("chatId");
                        String messageId = (String) map.get("messageId");
                        boolean pinned = Boolean.TRUE.equals(map.get("pinned"));
                        broadcastPinUpdate(chatId, messageId, pinned);
                    }
                    default -> log.warn("Unknown message type: {}", type);
                }
            }
        } catch (Exception e) {
            log.error("Error consuming message from queue: {}", e.getMessage(), e);
        }
    }

    @RabbitListener(queues = RabbitMQConfig.MESSAGE_DELIVERY_QUEUE, containerFactory = "rabbitListenerContainerFactory")
    public void consumeDelivery(Map<String, Object> payload) {
        try {
            String type = (String) payload.get("type");
            if ("SEEN_STATUS".equals(type)) {
                String chatId = (String) payload.get("chatId");
                String userId = (String) payload.get("userId");
                @SuppressWarnings("unchecked")
                List<String> messageIds = (List<String>) payload.get("messageIds");
                broadcastSeenStatus(chatId, userId, messageIds);
            }
        } catch (Exception e) {
            log.error("Error consuming delivery event: {}", e.getMessage(), e);
        }
    }

    private void broadcastNewMessage(MessageResponse message) {
        String destination = "/topic/chat." + message.getChatId() + ".messages";
        messagingTemplate.convertAndSend(destination, message);
        log.debug("Broadcast message {} to {}", message.getId(), destination);
    }

    private void broadcastMessageEdit(MessageResponse message) {
        messagingTemplate.convertAndSend(
            "/topic/chat." + message.getChatId() + ".messages.edit", message);
    }

    private void broadcastMessageDelete(String chatId, String messageId, boolean forEveryone) {
        Map<String, Object> payload = Map.of(
            "messageId", messageId, "forEveryone", forEveryone, "chatId", chatId);
        messagingTemplate.convertAndSend("/topic/chat." + chatId + ".messages.delete", payload);
    }

    private void broadcastReactionUpdate(MessageResponse message) {
        messagingTemplate.convertAndSend(
            "/topic/chat." + message.getChatId() + ".reactions", message);
    }

    private void broadcastPinUpdate(String chatId, String messageId, boolean pinned) {
        Map<String, Object> payload = Map.of(
            "messageId", messageId, "pinned", pinned, "chatId", chatId);
        messagingTemplate.convertAndSend("/topic/chat." + chatId + ".pins", payload);
    }

    private void broadcastSeenStatus(String chatId, String userId, List<String> messageIds) {
        Map<String, Object> payload = Map.of(
            "userId", userId, "messageIds", messageIds, "chatId", chatId);
        messagingTemplate.convertAndSend("/topic/chat." + chatId + ".seen", payload);
    }
}
