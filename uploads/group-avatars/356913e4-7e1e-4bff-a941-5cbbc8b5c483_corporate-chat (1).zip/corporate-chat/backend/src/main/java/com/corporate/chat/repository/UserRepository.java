package com.corporate.chat.repository;

import com.corporate.chat.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    Optional<User> findByUsernameOrEmail(String username, String email);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.active = true " +
           "AND (LOWER(u.displayName) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(u.username) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(u.email) LIKE LOWER(CONCAT('%', :query, '%')))")
    Page<User> searchActiveUsers(@Param("query") String query, Pageable pageable);

    @Query("SELECT u FROM User u WHERE " +
           "LOWER(u.displayName) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(u.username) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(u.email) LIKE LOWER(CONCAT('%', :query, '%'))")
    Page<User> searchAllUsers(@Param("query") String query, Pageable pageable);

    @Query("SELECT u FROM User u WHERE u.active = true ORDER BY u.displayName")
    List<User> findAllActiveUsers();

    @Query("SELECT u FROM User u ORDER BY u.createdAt DESC")
    Page<User> findAllUsersAdmin(Pageable pageable);

    @Modifying
    @Query("UPDATE User u SET u.presenceStatus = :status, u.lastSeenAt = :lastSeen WHERE u.id = :userId")
    void updatePresence(@Param("userId") String userId,
                        @Param("status") User.PresenceStatus status,
                        @Param("lastSeen") Instant lastSeen);

    @Modifying
    @Query("UPDATE User u SET u.active = false, u.deactivatedAt = :now, u.deactivatedBy = :adminId WHERE u.id = :userId")
    void deactivateUser(@Param("userId") String userId,
                        @Param("adminId") String adminId,
                        @Param("now") Instant now);

    List<User> findByIdIn(List<String> ids);
}
