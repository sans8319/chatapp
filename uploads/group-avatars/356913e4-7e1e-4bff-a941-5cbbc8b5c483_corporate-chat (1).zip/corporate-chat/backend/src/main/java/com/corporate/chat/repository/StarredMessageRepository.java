package com.corporate.chat.repository;

import com.corporate.chat.model.StarredMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StarredMessageRepository extends JpaRepository<StarredMessage, String> {

    List<StarredMessage> findByUserIdOrderByStarredAtDesc(String userId);

    Optional<StarredMessage> findByUserIdAndMessageId(String userId, String messageId);

    void deleteByUserIdAndMessageId(String userId, String messageId);

    boolean existsByUserIdAndMessageId(String userId, String messageId);
}
