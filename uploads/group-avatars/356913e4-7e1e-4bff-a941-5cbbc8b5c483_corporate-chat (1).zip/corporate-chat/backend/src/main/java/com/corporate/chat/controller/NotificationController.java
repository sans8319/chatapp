package com.corporate.chat.controller;

import com.corporate.chat.dto.request.TypingRequest;
import com.corporate.chat.dto.response.*;
import com.corporate.chat.service.NotificationService;
import com.corporate.chat.service.PresenceService;
import com.corporate.chat.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;
    private final PresenceService presenceService;
    private final SimpMessagingTemplate messagingTemplate;

    // ---- REST endpoints ----
    @GetMapping("/api/notifications")
    public ResponseEntity<ApiResponse<PageResponse<NotificationResponse>>> getNotifications(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(
            notificationService.getNotifications(userId, page, size)));
    }

    @GetMapping("/api/notifications/unread-count")
    public ResponseEntity<ApiResponse<Long>> getUnreadCount() {
        String userId = SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.success(notificationService.getUnreadCount(userId)));
    }

    @PostMapping("/api/notifications/read-all")
    public ResponseEntity<ApiResponse<Void>> markAllRead() {
        String userId = SecurityUtils.getCurrentUserId();
        notificationService.markAllAsRead(userId);
        return ResponseEntity.ok(ApiResponse.success("All notifications marked as read", null));
    }

    @PostMapping("/api/notifications/{id}/read")
    public ResponseEntity<ApiResponse<Void>> markRead(@PathVariable String id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok(ApiResponse.success("Notification marked as read", null));
    }

    // ---- WebSocket STOMP message handlers ----
    @MessageMapping("/typing")
    public void handleTyping(@Payload TypingRequest request, Principal principal) {
        if (principal == null) return;
        try {
            String userId = SecurityUtils.getCurrentUserId();
            String username = principal.getName();
            presenceService.setTyping(request.getChatId(), userId, username, request.isTyping());

            TypingResponse response = TypingResponse.builder()
                .chatId(request.getChatId())
                .userId(userId)
                .userName(username)
                .typing(request.isTyping())
                .build();
            messagingTemplate.convertAndSend(
                "/topic/chat." + request.getChatId() + ".typing", response);
        } catch (Exception e) {
            // ignore
        }
    }

    @MessageMapping("/presence.heartbeat")
    public void handleHeartbeat(Principal principal) {
        if (principal == null) return;
        try {
            String userId = SecurityUtils.getCurrentUserId();
            presenceService.setOnline(userId);
        } catch (Exception e) {
            // ignore
        }
    }
}
