package com.corporate.chat.repository;

import com.corporate.chat.model.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface MessageRepository extends JpaRepository<Message, String> {

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId AND m.deleted = false " +
           "ORDER BY m.createdAt ASC")
    Page<Message> findByChatId(@Param("chatId") String chatId, Pageable pageable);

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId AND m.deleted = false " +
           "AND m.createdAt < :before ORDER BY m.createdAt DESC")
    Page<Message> findByChatIdBefore(@Param("chatId") String chatId,
                                      @Param("before") Instant before,
                                      Pageable pageable);

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId " +
           "ORDER BY m.createdAt DESC")
    Optional<Message> findLastMessage(@Param("chatId") String chatId, Pageable pageable);

    @Query("SELECT COUNT(m) FROM Message m " +
           "JOIN MessageStatus ms ON ms.message.id = m.id " +
           "WHERE m.chat.id = :chatId AND ms.userId = :userId " +
           "AND ms.status != 'SEEN' AND m.sender.id != :userId AND m.deleted = false")
    long countUnreadMessages(@Param("chatId") String chatId, @Param("userId") String userId);

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId AND m.deleted = false " +
           "AND (LOWER(m.content) LIKE LOWER(CONCAT('%', :query, '%')))")
    Page<Message> searchMessages(@Param("chatId") String chatId,
                                  @Param("query") String query,
                                  Pageable pageable);

    @Query("SELECT m FROM Message m WHERE m.parentMessageId = :parentId AND m.deleted = false " +
           "ORDER BY m.createdAt ASC")
    List<Message> findThreadMessages(@Param("parentId") String parentId);

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId " +
           "AND m.deleted = false AND m.messageType IN ('IMAGE','VIDEO','DOCUMENT') " +
           "ORDER BY m.createdAt DESC")
    Page<Message> findMediaMessages(@Param("chatId") String chatId, Pageable pageable);

    @Modifying
    @Query("UPDATE Message m SET m.deleted = true, m.deletedAt = :now, " +
           "m.deletedForEveryone = true, m.content = '[Deleted]' WHERE m.id = :messageId")
    void deleteForEveryone(@Param("messageId") String messageId, @Param("now") Instant now);

    @Query("SELECT MAX(m.sequenceNumber) FROM Message m WHERE m.chat.id = :chatId")
    Optional<Long> findMaxSequenceNumber(@Param("chatId") String chatId);

    @Query("SELECT m FROM Message m WHERE m.chat.id = :chatId AND m.deleted = false " +
           "AND m.createdAt BETWEEN :from AND :to ORDER BY m.createdAt ASC")
    Page<Message> findByDateRange(@Param("chatId") String chatId,
                                   @Param("from") Instant from,
                                   @Param("to") Instant to,
                                   Pageable pageable);
}
